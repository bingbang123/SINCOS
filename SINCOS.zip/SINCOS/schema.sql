-- ============================================================
-- 高校实验室研究生管理系统 - 数据库 Schema
-- ============================================================

CREATE DATABASE IF NOT EXISTS `lab_management`
  DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `lab_management`;

-- ============================================================
-- 1. 用户表
-- ============================================================
CREATE TABLE `users` (
    `id`            BIGINT AUTO_INCREMENT PRIMARY KEY,
    `name`          VARCHAR(64)  NOT NULL              COMMENT '姓名',
    `email`         VARCHAR(128) NOT NULL              COMMENT '邮箱',
    `phone`         VARCHAR(32)  DEFAULT NULL          COMMENT '手机号',
    `student_no`    VARCHAR(32)  DEFAULT NULL          COMMENT '学号',
    `employee_no`   VARCHAR(32)  DEFAULT NULL          COMMENT '工号',
    `password_hash` VARCHAR(256) NOT NULL              COMMENT 'bcrypt哈希',
    `role`          VARCHAR(32)  NOT NULL DEFAULT 'student'
                    COMMENT 'student/phd/teacher/research_assistant/admin/super_admin',
    `research_direction` VARCHAR(256) DEFAULT NULL     COMMENT '研究方向',
    `enrollment_year`    INT          DEFAULT NULL     COMMENT '入学年份',
    `avatar_url`    VARCHAR(512) DEFAULT NULL          COMMENT '头像',
    `status`        VARCHAR(16)  NOT NULL DEFAULT 'active'
                    COMMENT 'active/graduated/suspended/left',
    `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_email`       (`email`),
    UNIQUE KEY `uk_student_no`  (`student_no`),
    UNIQUE KEY `uk_employee_no` (`employee_no`),
    INDEX `idx_role`   (`role`),
    INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- ============================================================
-- 2. 角色表
-- ============================================================
CREATE TABLE `roles` (
    `id`          BIGINT AUTO_INCREMENT PRIMARY KEY,
    `code`        VARCHAR(32)  NOT NULL              COMMENT '角色编码',
    `name`        VARCHAR(64)  NOT NULL              COMMENT '角色名称',
    `description` TEXT         DEFAULT NULL          COMMENT '角色说明',
    `is_system`   TINYINT(1)   NOT NULL DEFAULT 0    COMMENT '系统内置',
    `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='角色表';

-- ============================================================
-- 3. 用户角色关联表 (RBAC)
-- ============================================================
CREATE TABLE `user_roles` (
    `id`         BIGINT AUTO_INCREMENT PRIMARY KEY,
    `user_id`    BIGINT      NOT NULL,
    `role_id`    BIGINT      NOT NULL,
    `scope_type` VARCHAR(16) NOT NULL DEFAULT 'global'
                 COMMENT 'global/lab/project_group',
    `scope_id`   BIGINT      DEFAULT NULL,
    `created_at` DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_user_role_scope` (`user_id`,`role_id`,`scope_type`,`scope_id`),
    INDEX `idx_user` (`user_id`),
    INDEX `idx_role` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户角色关联表';

-- ============================================================
-- 4. 项目组表
-- ============================================================
CREATE TABLE `project_groups` (
    `id`            BIGINT AUTO_INCREMENT PRIMARY KEY,
    `code`          VARCHAR(32)  NOT NULL,
    `name`          VARCHAR(128) NOT NULL,
    `description`   TEXT         DEFAULT NULL,
    `teacher_id`    BIGINT       DEFAULT NULL          COMMENT '导师ID',
    `phd_owner_id`  BIGINT       DEFAULT NULL          COMMENT '博士负责人ID',
    `status`        VARCHAR(16)  NOT NULL DEFAULT 'active',
    `start_date`    DATE         DEFAULT NULL,
    `end_date`      DATE         DEFAULT NULL,
    `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_code` (`code`),
    INDEX `idx_teacher`   (`teacher_id`),
    INDEX `idx_phd_owner` (`phd_owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='项目组表';

-- ============================================================
-- 5. 项目组成员表
-- ============================================================
CREATE TABLE `project_members` (
    `id`               BIGINT AUTO_INCREMENT PRIMARY KEY,
    `project_group_id` BIGINT      NOT NULL,
    `user_id`          BIGINT      NOT NULL,
    `member_role`      VARCHAR(16) NOT NULL DEFAULT 'student',
    `joined_at`        DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_project_user` (`project_group_id`,`user_id`),
    INDEX `idx_user`    (`user_id`),
    INDEX `idx_project` (`project_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='项目组成员表';

-- ============================================================
-- 6. 到场记录表
-- ============================================================
CREATE TABLE `attendance_records` (
    `id`              BIGINT AUTO_INCREMENT PRIMARY KEY,
    `student_id`      BIGINT      NOT NULL,
    `project_group_id` BIGINT     DEFAULT NULL,
    `attendance_date` DATE        NOT NULL,
    `presence_status` VARCHAR(16) NOT NULL DEFAULT 'unknown'
                      COMMENT 'present/absent/unknown',
    `recorder_id`     BIGINT      NOT NULL,
    `recorded_at`     DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `remark`          TEXT        DEFAULT NULL
                      COMMENT '请假/出差/线上参会/外出实验',
    `created_at`      DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_student_date` (`student_id`,`attendance_date`),
    INDEX `idx_date`     (`attendance_date`),
    INDEX `idx_project`  (`project_group_id`),
    INDEX `idx_status`   (`presence_status`),
    INDEX `idx_recorder` (`recorder_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='到场记录表';

-- ============================================================
-- 7. 课表上传表
-- ============================================================
CREATE TABLE `student_schedules` (
    `id`               BIGINT AUTO_INCREMENT PRIMARY KEY,
    `student_id`       BIGINT       NOT NULL,
    `semester`         VARCHAR(32)  NOT NULL,
    `source_file_name` VARCHAR(256) NOT NULL,
    `source_file_url`  VARCHAR(512) DEFAULT NULL,
    `file_type`        VARCHAR(8)   NOT NULL DEFAULT 'doc',
    `parse_status`     VARCHAR(16)  NOT NULL DEFAULT 'pending'
                       COMMENT 'pending/success/failed/manually_fixed',
    `parse_message`    TEXT         DEFAULT NULL,
    `uploaded_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `confirmed_at`     DATETIME     DEFAULT NULL,
    `created_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_student`      (`student_id`),
    INDEX `idx_semester`     (`semester`),
    INDEX `idx_parse_status` (`parse_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='课表上传表';

-- ============================================================
-- 8. 课程明细表
-- ============================================================
CREATE TABLE `student_schedule_items` (
    `id`            BIGINT AUTO_INCREMENT PRIMARY KEY,
    `schedule_id`   BIGINT       NOT NULL,
    `student_id`    BIGINT       NOT NULL,
    `weekday`       INT          NOT NULL COMMENT '1-7 周一到周日',
    `section_label` VARCHAR(16)  NOT NULL COMMENT '上午1/下午5/晚上9',
    `section_no`    INT          NOT NULL COMMENT '节次 1-11',
    `start_time`    TIME         NOT NULL,
    `end_time`      TIME         NOT NULL,
    `course_name`   VARCHAR(256) NOT NULL,
    `class_name`    VARCHAR(256) DEFAULT NULL,
    `weeks_text`    VARCHAR(64)  DEFAULT NULL COMMENT '10-17周',
    `teacher_name`  VARCHAR(64)  DEFAULT NULL,
    `location`      VARCHAR(256) DEFAULT NULL,
    `raw_text`      TEXT         DEFAULT NULL,
    `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_schedule` (`schedule_id`),
    INDEX `idx_student`  (`student_id`),
    INDEX `idx_weekday`  (`weekday`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='课程明细表';

-- ============================================================
-- 9. 日报表
-- ============================================================
CREATE TABLE `daily_reports` (
    `id`                    BIGINT AUTO_INCREMENT PRIMARY KEY,
    `student_id`            BIGINT      NOT NULL,
    `project_group_id`      BIGINT      DEFAULT NULL,
    `attendance_record_id`  BIGINT      DEFAULT NULL,
    `report_date`           DATE        NOT NULL,
    `completed_work`        TEXT        DEFAULT NULL        COMMENT '今日完成(富文本)',
    `problems`              TEXT        DEFAULT NULL        COMMENT '遇到问题(富文本)',
    `next_plan`             TEXT        DEFAULT NULL        COMMENT '明日计划(富文本)',
    `work_hours`            DECIMAL(4,1) DEFAULT NULL,
    `tags`                  JSON        DEFAULT NULL        COMMENT '["论文","实验"]',
    `mentioned_users`       JSON        DEFAULT NULL        COMMENT '@提醒用户ID列表',
    `status`                VARCHAR(16) NOT NULL DEFAULT 'draft'
                            COMMENT 'draft/submitted/viewed/feedback/need_followup',
    `visibility`            VARCHAR(16) NOT NULL DEFAULT 'project',
    `submitted_at`          DATETIME    DEFAULT NULL,
    `created_at`            DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`            DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_student_date` (`student_id`,`report_date`),
    INDEX `idx_project` (`project_group_id`),
    INDEX `idx_date`    (`report_date`),
    INDEX `idx_status`  (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='日报表';

-- ============================================================
-- 10. 周报表
-- ============================================================
CREATE TABLE `weekly_reports` (
    `id`                BIGINT AUTO_INCREMENT PRIMARY KEY,
    `student_id`        BIGINT      NOT NULL,
    `project_group_id`  BIGINT      DEFAULT NULL,
    `week_start`        DATE        NOT NULL,
    `week_end`          DATE        NOT NULL,
    `week_label`        VARCHAR(16) DEFAULT NULL,
    `weekly_goal`       TEXT        DEFAULT NULL           COMMENT '本周目标(富文本)',
    `completed_work`    TEXT        DEFAULT NULL           COMMENT '本周完成(富文本)',
    `key_results`       TEXT        DEFAULT NULL           COMMENT '关键成果(富文本)',
    `unfinished_work`   TEXT        DEFAULT NULL           COMMENT '未完成事项(富文本)',
    `reason_analysis`   TEXT        DEFAULT NULL,
    `next_week_plan`    TEXT        DEFAULT NULL           COMMENT '下周计划(富文本)',
    `help_needed`       TEXT        DEFAULT NULL,
    `mentioned_users`   JSON        DEFAULT NULL,
    `self_score`        INT         DEFAULT NULL           COMMENT '自评1-10',
    `status`            VARCHAR(16) NOT NULL DEFAULT 'draft'
                        COMMENT 'draft/submitted/viewed/approved/need_revision/risk',
    `submitted_at`      DATETIME    DEFAULT NULL,
    `created_at`        DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`        DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_student`  (`student_id`),
    INDEX `idx_project`  (`project_group_id`),
    INDEX `idx_week`     (`week_start`),
    INDEX `idx_status`   (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='周报表';

-- ============================================================
-- 11. 任务表
-- ============================================================
CREATE TABLE `tasks` (
    `id`               BIGINT AUTO_INCREMENT PRIMARY KEY,
    `title`            VARCHAR(256) NOT NULL,
    `description`      TEXT         DEFAULT NULL,
    `project_group_id` BIGINT       NOT NULL,
    `assignee_id`      BIGINT       NOT NULL              COMMENT '负责人',
    `creator_id`       BIGINT       NOT NULL,
    `priority`         VARCHAR(8)   NOT NULL DEFAULT 'medium'
                       COMMENT 'low/medium/high/urgent',
    `status`           VARCHAR(16)  NOT NULL DEFAULT 'todo'
                       COMMENT 'todo/doing/blocked/review/done/overdue',
    `start_date`       DATE         DEFAULT NULL,
    `deadline`         DATETIME     DEFAULT NULL,
    `milestone`        VARCHAR(256) DEFAULT NULL,
    `completed_at`     DATETIME     DEFAULT NULL,
    `created_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_assignee` (`assignee_id`),
    INDEX `idx_project`  (`project_group_id`),
    INDEX `idx_status`   (`status`),
    INDEX `idx_deadline` (`deadline`),
    INDEX `idx_creator`  (`creator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='任务表';

-- ============================================================
-- 12. 任务协作者表
-- ============================================================
CREATE TABLE `task_collaborators` (
    `id`         BIGINT AUTO_INCREMENT PRIMARY KEY,
    `task_id`    BIGINT   NOT NULL,
    `user_id`    BIGINT   NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_task_user` (`task_id`,`user_id`),
    INDEX `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='任务协作者表';

-- ============================================================
-- 13. 任务-报告关联表
-- ============================================================
CREATE TABLE `task_report_links` (
    `id`          BIGINT AUTO_INCREMENT PRIMARY KEY,
    `task_id`     BIGINT      NOT NULL,
    `report_type` VARCHAR(16) NOT NULL COMMENT 'daily_report/weekly_report',
    `report_id`   BIGINT      NOT NULL,
    `created_at`  DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_task_report` (`task_id`,`report_type`,`report_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='任务报告关联表';

-- ============================================================
-- 14. 评论反馈表
-- ============================================================
CREATE TABLE `comments` (
    `id`          BIGINT AUTO_INCREMENT PRIMARY KEY,
    `target_type` VARCHAR(16) NOT NULL COMMENT 'daily_report/weekly_report/task',
    `target_id`   BIGINT      NOT NULL,
    `author_id`   BIGINT      NOT NULL,
    `content`     TEXT        NOT NULL,
    `action_type` VARCHAR(16) NOT NULL DEFAULT 'comment'
                  COMMENT 'comment/request_change/approve/mark_risk',
    `parent_id`   BIGINT      DEFAULT NULL,
    `resolved`    TINYINT(1)  NOT NULL DEFAULT 0,
    `resolved_by` BIGINT      DEFAULT NULL,
    `resolved_at` DATETIME    DEFAULT NULL,
    `created_at`  DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_target` (`target_type`,`target_id`),
    INDEX `idx_author` (`author_id`),
    INDEX `idx_parent` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='评论反馈表';

-- ============================================================
-- 15. 附件表
-- ============================================================
CREATE TABLE `attachments` (
    `id`          BIGINT AUTO_INCREMENT PRIMARY KEY,
    `target_type` VARCHAR(16)  NOT NULL,
    `target_id`   BIGINT       NOT NULL,
    `file_name`   VARCHAR(256) NOT NULL,
    `file_url`    VARCHAR(512) NOT NULL,
    `file_type`   VARCHAR(32)  DEFAULT NULL COMMENT 'image/pdf/code/link',
    `file_size`   BIGINT       DEFAULT NULL,
    `uploader_id` BIGINT       NOT NULL,
    `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_target`   (`target_type`,`target_id`),
    INDEX `idx_uploader` (`uploader_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='附件表';

-- ============================================================
-- 16. 报告模板表
-- ============================================================
CREATE TABLE `report_templates` (
    `id`               BIGINT AUTO_INCREMENT PRIMARY KEY,
    `name`             VARCHAR(128) NOT NULL,
    `report_type`      VARCHAR(16)  NOT NULL COMMENT 'daily/weekly',
    `project_group_id` BIGINT       DEFAULT NULL,
    `content_schema`   JSON         DEFAULT NULL,
    `default_content`  TEXT         DEFAULT NULL,
    `creator_id`       BIGINT       NOT NULL,
    `status`           VARCHAR(16)  NOT NULL DEFAULT 'enabled',
    `created_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_type`    (`report_type`),
    INDEX `idx_project` (`project_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='报告模板表';

-- ============================================================
-- 17. 报告版本表
-- ============================================================
CREATE TABLE `report_versions` (
    `id`               BIGINT AUTO_INCREMENT PRIMARY KEY,
    `report_type`      VARCHAR(16) NOT NULL,
    `report_id`        BIGINT      NOT NULL,
    `version_no`       INT         NOT NULL,
    `content_snapshot` JSON        NOT NULL,
    `editor_id`        BIGINT      NOT NULL,
    `created_at`       DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_report` (`report_type`,`report_id`),
    INDEX `idx_editor` (`editor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='报告版本表';

-- ============================================================
-- 18. 日历事件表
-- ============================================================
CREATE TABLE `calendar_events` (
    `id`               BIGINT AUTO_INCREMENT PRIMARY KEY,
    `title`            VARCHAR(256) NOT NULL,
    `description`      TEXT         DEFAULT NULL,
    `event_type`       VARCHAR(32)  NOT NULL
                       COMMENT 'task_deadline/meeting/personal/paper/milestone/report_due/ai_suggestion',
    `owner_id`         BIGINT       NOT NULL,
    `project_group_id` BIGINT       DEFAULT NULL,
    `student_id`       BIGINT       DEFAULT NULL,
    `related_type`     VARCHAR(16)  DEFAULT NULL,
    `related_id`       BIGINT       DEFAULT NULL,
    `start_at`         DATETIME     NOT NULL,
    `end_at`           DATETIME     DEFAULT NULL,
    `all_day`          TINYINT(1)   NOT NULL DEFAULT 0,
    `priority`         VARCHAR(8)   NOT NULL DEFAULT 'low',
    `visibility`       VARCHAR(16)  NOT NULL DEFAULT 'lab',
    `repeat_rule`      VARCHAR(64)  DEFAULT NULL,
    `reminder_rule`    JSON         DEFAULT NULL,
    `color`            VARCHAR(16)  DEFAULT NULL,
    `created_by`       BIGINT       NOT NULL,
    `created_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_owner`    (`owner_id`),
    INDEX `idx_project`  (`project_group_id`),
    INDEX `idx_student`  (`student_id`),
    INDEX `idx_start`    (`start_at`),
    INDEX `idx_type`     (`event_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='日历事件表';

-- ============================================================
-- 19. AI 对话表
-- ============================================================
CREATE TABLE `ai_conversations` (
    `id`            BIGINT AUTO_INCREMENT PRIMARY KEY,
    `user_id`       BIGINT       NOT NULL,
    `title`         VARCHAR(256) DEFAULT NULL,
    `model_name`    VARCHAR(64)  NOT NULL,
    `adopted_count` INT          NOT NULL DEFAULT 0,
    `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='AI对话表';

-- ============================================================
-- 20. AI 消息表
-- ============================================================
CREATE TABLE `ai_messages` (
    `id`              BIGINT AUTO_INCREMENT PRIMARY KEY,
    `conversation_id` BIGINT      NOT NULL,
    `role`            VARCHAR(16) NOT NULL COMMENT 'user/assistant/system/tool',
    `content`         TEXT        NOT NULL,
    `source_refs`     JSON        DEFAULT NULL,
    `tool_calls`      JSON        DEFAULT NULL,
    `created_at`      DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_conv` (`conversation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='AI消息表';

-- ============================================================
-- 21. 通知表
-- ============================================================
CREATE TABLE `notifications` (
    `id`                BIGINT AUTO_INCREMENT PRIMARY KEY,
    `user_id`           BIGINT       NOT NULL,
    `title`             VARCHAR(256) NOT NULL,
    `content`           TEXT         DEFAULT NULL,
    `notification_type` VARCHAR(32)  NOT NULL,
    `related_type`      VARCHAR(16)  DEFAULT NULL,
    `related_id`        BIGINT       DEFAULT NULL,
    `is_read`           TINYINT(1)   NOT NULL DEFAULT 0,
    `read_at`           DATETIME     DEFAULT NULL,
    `sent_via`          VARCHAR(16)  NOT NULL DEFAULT 'system',
    `created_at`        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_user_read` (`user_id`,`is_read`),
    INDEX `idx_created`   (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='通知表';

-- ============================================================
-- 22. 审计日志表
-- ============================================================
CREATE TABLE `audit_logs` (
    `id`          BIGINT AUTO_INCREMENT PRIMARY KEY,
    `user_id`     BIGINT       NOT NULL,
    `action`      VARCHAR(64)  NOT NULL,
    `target_type` VARCHAR(32)  DEFAULT NULL,
    `target_id`   BIGINT       DEFAULT NULL,
    `detail`      JSON         DEFAULT NULL,
    `ip_address`  VARCHAR(64)  DEFAULT NULL,
    `user_agent`  VARCHAR(512) DEFAULT NULL,
    `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_user`    (`user_id`),
    INDEX `idx_action`  (`action`),
    INDEX `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='审计日志表';
