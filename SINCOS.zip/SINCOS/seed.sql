-- ============================================================
-- 高校实验室研究生管理系统 - 种子数据
-- ============================================================

USE `lab_management`;

-- 系统内置角色
INSERT INTO `roles` (`code`, `name`, `description`, `is_system`) VALUES
('super_admin',        '超级管理员',   '系统最高权限',               1),
('lab_admin',          '实验室管理员', '管理全实验室成员与项目组',   1),
('project_admin',      '项目管理员',   '管理指定项目组',            1),
('data_admin',         '数据管理员',   '备份/导入导出/审计',        1),
('ai_admin',           'AI管理员',     '配置LLM/Prompt/知识库',    1),
('teacher',            '导师',         '全局数据/AI查询/日历',      1),
('phd',                '博士负责人',   '项目组管理/任务分配',       1),
('student',            '学生',         '日报/周报/任务/课表',       1),
('research_assistant', '科研助理',     '到场记录/到场统计',         1);

-- 四个固定项目组
INSERT INTO `project_groups` (`code`, `name`, `description`, `status`) VALUES
('data',              '数据组',       '数据采集、清洗、标注、管理方向',       'active'),
('multimodal_fusion', '多模态融合组', '多模态数据融合算法研究',               'active'),
('embodied_ai',       '具身智能组',   '具身智能与机器人研究',                 'active'),
('space_network',     '天基网络组',   '天基网络与通信研究',                   'active');

-- 默认报告模板
INSERT INTO `report_templates` (`name`, `report_type`, `content_schema`, `default_content`, `creator_id`, `status`) VALUES
('默认日报模板',     'daily',  '{"blocks":["今日完成","遇到问题","明日计划"]}', '', 1, 'enabled'),
('实验日报模板',     'daily',  '{"blocks":["实验目标","实验方法","实验结果","问题","明日计划"]}', '', 1, 'enabled'),
('论文阅读日报模板', 'daily',  '{"blocks":["论文标题","核心方法","启发点","明日计划"]}', '', 1, 'enabled'),
('默认周报模板',     'weekly', '{"blocks":["本周目标","本周完成","关键成果","未完成","原因","下周计划","需要帮助"]}', '', 1, 'enabled');

-- 创建超级管理员 (默认密码 admin123, 请部署后修改)
INSERT INTO `users` (`name`, `email`, `password_hash`, `role`, `status`) VALUES
('系统管理员', 'admin@lab.edu.cn',
 '$2b$12$LJ3m4ys3Lk0TSwHCpNqr3eOoZ9GM7t1VyQr8qXcB5hYsR5xP8hS2e',
 'super_admin', 'active');

-- 为超管分配超级管理员角色
INSERT INTO `user_roles` (`user_id`, `role_id`, `scope_type`)
SELECT 1, id, 'global' FROM `roles` WHERE `code` = 'super_admin';
