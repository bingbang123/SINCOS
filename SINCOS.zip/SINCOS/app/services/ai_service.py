"""AI 助手服务 — RAG 检索 + LLM 调用"""

import json, re
from datetime import date
from app.database import fetch_one, fetch_all, execute_insert
from app.config import LLM_BASE_URL, LLM_API_KEY, LLM_MODEL, LLM_TEMPERATURE, LLM_MAX_TOKENS
from app.auth import get_user_project_ids

SYSTEM_PROMPT = """你是高校实验室研究生管理系统中的科研进度助手。
你只能基于系统提供的数据回答问题，不允许编造不存在的日报、周报、任务或 deadline。
如果数据不足，请明确说明缺少哪些信息。
回答时请保持简洁、客观、可追溯。
涉及学生评价时，避免主观否定，应基于事实描述进展、风险和建议。
回答必须包含数据来源编号。"""


def chat(user: dict, message: str, conversation_id: int | None) -> dict:
    if not conversation_id:
        conversation_id = _get_or_create_conv(user["id"])
    scope = "all_projects" if user["role"] in ("teacher","admin","super_admin") else \
            "my_project_groups" if user["role"] == "phd" else "self_only"
    auth_ids = get_user_project_ids(user["id"], user["role"])
    retrieved = _retrieve(message, user, auth_ids)

    context = {"current_user": {"name": user["name"], "role": user["role"]},
               "query": message, "authorized_scope": scope, "retrieved_records": retrieved}

    # 保存用户消息
    execute_insert(
        "INSERT INTO ai_messages (conversation_id,role,content,source_refs) VALUES (%s,'user',%s,%s)",
        (conversation_id, message, json.dumps([r.get("source_id","") for r in retrieved], ensure_ascii=False)))

    # 调用 LLM
    answer, refs = _call_llm(context)
    execute_insert(
        "INSERT INTO ai_messages (conversation_id,role,content,source_refs) VALUES (%s,'assistant',%s,%s)",
        (conversation_id, answer, json.dumps(refs, ensure_ascii=False)))

    return {"conversation_id": conversation_id, "answer": answer, "source_refs": refs}


def _get_or_create_conv(user_id: int) -> int:
    c = fetch_one("SELECT id FROM ai_conversations WHERE user_id=%s ORDER BY created_at DESC LIMIT 1", (user_id,))
    if c: return c["id"]
    return execute_insert("INSERT INTO ai_conversations (user_id,title,model_name) VALUES (%s,'新对话',%s)",
                          (user_id, LLM_MODEL))


def _retrieve(query: str, user: dict, auth_ids: list[int]) -> list[dict]:
    records = []
    q = query.lower()
    student_match = re.search(r'(\S+)\s*(?:最近|这周|上周)', query)

    # 日报
    if any(k in q for k in ["日报","今天","最近","在做什么","工作","做了"]):
        rows = _query("daily_reports", user, auth_ids, "report_date", 20, student_match)
        for r in rows:
            records.append({"type":"daily_report","student":r.get("student_name",""),
                            "date":str(r["report_date"]),
                            "content":f"完成:{r.get('completed_work','')}\n问题:{r.get('problems','')}",
                            "source_id":f"DR-{r['report_date']}-{r['id']:04d}"})
    # 周报
    if any(k in q for k in ["周报","本周","上周","总结","进展","成果"]):
        rows = _query("weekly_reports", user, auth_ids, "week_start", 10, student_match)
        for r in rows:
            records.append({"type":"weekly_report","student":r.get("student_name",""),
                            "date":f"{r['week_start']}~{r['week_end']}",
                            "content":f"完成:{r.get('completed_work','')}\n成果:{r.get('key_results','')}",
                            "source_id":f"WR-{r['week_start']}-{r['id']:04d}"})
    # 任务
    if any(k in q for k in ["任务","deadline","截止","延期","逾期","风险"]):
        rows = _query("tasks", user, auth_ids, "deadline", 20, student_match,
                      extra=" AND t.status NOT IN ('done')")
        for r in rows:
            records.append({"type":"task","student":r.get("assignee_name",""),
                            "date":str(r.get("deadline","")),
                            "content":f"任务:{r['title']}\n优先级:{r['priority']}\n状态:{r['status']}",
                            "source_id":f"T-{r['id']:04d}"})
    # 到场
    if any(k in q for k in ["到场","签到","未到","请假","出勤"]):
        today = date.today()
        rows = _query("attendance_records", user, auth_ids, "attendance_date", 50, student_match,
                      extra=f" AND ar.attendance_date='{today}'")
        for r in rows:
            records.append({"type":"attendance","student":r.get("student_name",""),
                            "date":str(r.get("attendance_date","")),
                            "content":f"到场:{r['presence_status']}\n备注:{r.get('remark','')}",
                            "source_id":f"ATT-{r.get('attendance_date','')}-{r['id']:04d}"})
    # 课表
    if any(k in q for k in ["课表","课程","上课","有课","空闲"]):
        rows = _query_schedule(user, auth_ids, student_match)
        for r in rows:
            records.append({"type":"schedule","student":r.get("student_name",""),
                            "date":f"周{r['weekday']} 第{r['section_no']}节",
                            "content":f"课程:{r['course_name']}\n{r['start_time']}-{r['end_time']}\n{r.get('location','')}",
                            "source_id":f"SCH-{r['id']:04d}"})
    return records


def _query(table: str, user: dict, auth_ids: list[int], order_by: str, limit: int,
           student_match, extra: str = "") -> list[dict]:
    if table in ("daily_reports","weekly_reports"):
        name_field = "student_name"
        join = f"JOIN users u ON {table[:2]}r.student_id=u.id"
        select = f"SELECT {table[:2]}r.*, u.name AS student_name"
        col_project = f"{table[:2]}r.project_group_id"
    elif table == "tasks":
        name_field = "assignee_name"
        join = "JOIN users u ON t.assignee_id=u.id"
        select = "SELECT t.*, u.name AS assignee_name"
        col_project = "t.project_group_id"
    else:
        name_field = "student_name"
        join = "JOIN users u ON ar.student_id=u.id"
        select = "SELECT ar.*, u.name AS student_name"
        col_project = "ar.project_group_id"

    base = f"{select} FROM {table} {table[:2]}r {join} WHERE 1=1"
    params: list = []
    if user["role"] == "student":
        base += f" AND {table[:2]}r.student_id=%s"; params.append(user["id"])
    elif user["role"] == "phd" and auth_ids:
        base += f" AND {col_project} IN ({','.join(['%s']*len(auth_ids))})"; params.extend(auth_ids)
    if student_match:
        base += " AND u.name=%s"; params.append(student_match.group(1))
    base += extra
    base += f" ORDER BY {order_by} DESC LIMIT {limit}"
    return fetch_all(base, tuple(params))


def _query_schedule(user: dict, auth_ids: list[int], student_match) -> list[dict]:
    sql = """SELECT ssi.*, u.name AS student_name FROM student_schedule_items ssi
             JOIN users u ON ssi.student_id=u.id
             JOIN student_schedules ss ON ssi.schedule_id=ss.id
             WHERE ss.parse_status IN ('success','manually_fixed')"""
    params: list = []
    if student_match:
        sql += " AND u.name=%s"; params.append(student_match.group(1))
    elif user["role"] == "phd" and auth_ids:
        sql += f" AND ssi.student_id IN (SELECT user_id FROM project_members WHERE project_group_id IN ({','.join(['%s']*len(auth_ids))}))"
        params.extend(auth_ids)
    return fetch_all(sql + " ORDER BY ssi.weekday,ssi.section_no LIMIT 50", tuple(params))


def _call_llm(context: dict) -> tuple[str, list]:
    try:
        from openai import OpenAI
        client = OpenAI(api_key=LLM_API_KEY, base_url=LLM_BASE_URL)
        user_prompt = f"""用户: {context['current_user']['name']} ({context['current_user']['role']})
权限范围: {context['authorized_scope']}
问题: {context['query']}

可用数据 ({len(context['retrieved_records'])} 条):
{json.dumps(context['retrieved_records'], ensure_ascii=False, indent=2)}

请按格式回答: 结论 → 详情(已完成/进行中/存在问题/建议动作) → 数据来源"""
        resp = client.chat.completions.create(
            model=LLM_MODEL,
            messages=[{"role":"system","content":SYSTEM_PROMPT},{"role":"user","content":user_prompt}],
            temperature=LLM_TEMPERATURE, max_tokens=LLM_MAX_TOKENS)
        answer = resp.choices[0].message.content
        refs = [{"source_id":r["source_id"],"type":r["type"]} for r in context["retrieved_records"]]
        return answer, refs
    except Exception:
        return _fallback(context), []


def _fallback(context: dict) -> str:
    records = context["retrieved_records"]
    if not records: return "未找到相关数据。请尝试更具体的问题。"
    lines = ["结论: 基于系统数据，找到以下相关信息：",""]
    by_type = {}
    for r in records:
        by_type.setdefault(r["type"], []).append(r)
    names = {"daily_report":"日报","weekly_report":"周报","task":"任务","attendance":"到场","schedule":"课表"}
    for t, items in by_type.items():
        lines.append(f"## {names.get(t,t)} ({len(items)}条)")
        for it in items[:5]:
            lines.append(f"- [{it['source_id']}] {it.get('student','')}: {it.get('content','')[:120]}")
        lines.append("")
    lines.append("数据来源: " + ", ".join(r["source_id"] for r in records[:10]))
    return "\n".join(lines)


def generate_weekly_draft_ai(user_id: int, week_start, week_end) -> str:
    reports = fetch_all(
        "SELECT * FROM daily_reports WHERE student_id=%s AND report_date BETWEEN %s AND %s ORDER BY report_date",
        (user_id, week_start, week_end))
    if not reports: raise ValueError("该时间段没有日报")
    completed = "\n".join(f"- {r['report_date']}: {r.get('completed_work','')}" for r in reports)
    problems  = "\n".join(f"- {r['report_date']}: {r.get('problems','')}" for r in reports if r.get("problems"))
    try:
        from openai import OpenAI
        client = OpenAI(api_key=LLM_API_KEY, base_url=LLM_BASE_URL)
        resp = client.chat.completions.create(
            model=LLM_MODEL,
            messages=[{"role":"system","content":"你是科研助理，请根据日报生成周报草稿。包含：本周完成、关键成果、未完成事项、下周计划。"},
                      {"role":"user","content":f"日报:\n完成:\n{completed}\n\n问题:\n{problems}\n\n请生成周报草稿。"}],
            temperature=0.3, max_tokens=2048)
        return resp.choices[0].message.content
    except Exception:
        return f"本周完成:\n{completed}\n\n问题:\n{problems}\n\n(请补充关键成果、原因分析和下周计划)"


def list_conversations(user_id: int) -> list[dict]:
    return fetch_all("SELECT * FROM ai_conversations WHERE user_id=%s ORDER BY updated_at DESC LIMIT 50", (user_id,))


def get_conversation(conv_id: int, user_id: int) -> dict | None:
    c = fetch_one("SELECT * FROM ai_conversations WHERE id=%s AND user_id=%s", (conv_id, user_id))
    if c:
        c["messages"] = fetch_all("SELECT * FROM ai_messages WHERE conversation_id=%s ORDER BY created_at", (conv_id,))
    return c
