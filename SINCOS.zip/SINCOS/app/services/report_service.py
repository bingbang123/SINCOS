"""日报/周报服务"""

import json
from datetime import date
from app.database import fetch_one, fetch_all, fetch_page, execute_insert, execute
from app.auth import get_user_project_ids


# ============================================================
# 日报
# ============================================================
def create_daily(user_id: int, **kwargs) -> int:
    report_date = kwargs.pop("report_date", date.today())
    existing = fetch_one("SELECT id FROM daily_reports WHERE student_id=%s AND report_date=%s",
                         (user_id, report_date))
    if existing: raise ValueError("该日期日报已存在")

    att = fetch_one("SELECT id FROM attendance_records WHERE student_id=%s AND attendance_date=%s",
                    (user_id, report_date))
    tags = kwargs.pop("tags", None)
    mentioned = kwargs.pop("mentioned_users", None)
    return execute_insert(
        """INSERT INTO daily_reports
           (student_id,project_group_id,attendance_record_id,report_date,
            completed_work,problems,next_plan,work_hours,tags,mentioned_users,status)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,'draft')""",
        (user_id, kwargs.pop("project_group_id", None), att["id"] if att else None, report_date,
         kwargs.pop("completed_work", None), kwargs.pop("problems", None),
         kwargs.pop("next_plan", None), kwargs.pop("work_hours", None),
         json.dumps(tags, ensure_ascii=False) if tags else None,
         json.dumps(mentioned) if mentioned else None))


def update_daily(report_id: int, user_id: int, **kwargs) -> bool:
    _save_version("daily", report_id, user_id)
    tags = kwargs.pop("tags", None)
    mentioned = kwargs.pop("mentioned_users", None)
    if tags is not None:      kwargs["tags"] = json.dumps(tags, ensure_ascii=False)
    if mentioned is not None: kwargs["mentioned_users"] = json.dumps(mentioned)
    sets = [f"{k}=%s" for k in kwargs if kwargs[k] is not None]
    params = [kwargs[k] for k in kwargs if kwargs[k] is not None] + [report_id]
    if sets:
        execute(f"UPDATE daily_reports SET {','.join(sets)} WHERE id=%s AND student_id=%s",
                tuple(params + [user_id]))
    return True


def submit_daily(report_id: int, user_id: int):
    execute("UPDATE daily_reports SET status='submitted',submitted_at=NOW() WHERE id=%s AND student_id=%s",
            (report_id, user_id))


def list_dailies(user: dict, page: int, page_size: int, **filters) -> tuple[list[dict], int]:
    base = """SELECT dr.*, u.name AS student_name
              FROM daily_reports dr JOIN users u ON dr.student_id=u.id WHERE 1=1"""
    params: list = []
    if user["role"] == "student":
        base += " AND dr.student_id=%s"; params.append(user["id"])
    elif user["role"] == "phd":
        ids = get_user_project_ids(user["id"], "phd")
        if not ids: return [], 0
        base += f" AND dr.project_group_id IN ({','.join(['%s']*len(ids))})"; params.extend(ids)
    for k, v in filters.items():
        if v is None: continue
        if k == "start_date":       base += " AND dr.report_date>=%s"; params.append(v)
        elif k == "end_date":       base += " AND dr.report_date<=%s"; params.append(v)
        elif k == "has_problems":   base += " AND dr.problems IS NOT NULL AND dr.problems!=''"
        elif k == "keyword":
            kw = f"%{v}%"; base += " AND (dr.completed_work LIKE %s OR dr.problems LIKE %s OR dr.next_plan LIKE %s)"
            params.extend([kw, kw, kw])
        else:                       base += f" AND dr.{k}=%s"; params.append(v)
    sql = base + " ORDER BY dr.report_date DESC"
    return fetch_page(sql, tuple(params), page, page_size)


def get_daily(report_id: int) -> dict | None:
    r = fetch_one("SELECT dr.*, u.name AS student_name FROM daily_reports dr JOIN users u ON dr.student_id=u.id WHERE dr.id=%s", (report_id,))
    if r:
        r["attachments"] = fetch_all("SELECT * FROM attachments WHERE target_type='daily_report' AND target_id=%s", (report_id,))
        r["comments"] = fetch_all("""SELECT c.*, u.name AS author_name FROM comments c JOIN users u ON c.author_id=u.id
                                     WHERE c.target_type='daily_report' AND c.target_id=%s ORDER BY c.created_at""", (report_id,))
    return r


# ============================================================
# 周报
# ============================================================
def create_weekly(user_id: int, **kwargs) -> int:
    mentioned = kwargs.pop("mentioned_users", None)
    return execute_insert(
        """INSERT INTO weekly_reports
           (student_id,project_group_id,week_start,week_end,week_label,
            weekly_goal,completed_work,key_results,unfinished_work,
            reason_analysis,next_week_plan,help_needed,mentioned_users,self_score,status)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,'draft')""",
        (user_id, kwargs.pop("project_group_id", None), kwargs.pop("week_start"),
         kwargs.pop("week_end"), kwargs.pop("week_label", None),
         kwargs.pop("weekly_goal", None), kwargs.pop("completed_work", None),
         kwargs.pop("key_results", None), kwargs.pop("unfinished_work", None),
         kwargs.pop("reason_analysis", None), kwargs.pop("next_week_plan", None),
         kwargs.pop("help_needed", None),
         json.dumps(mentioned) if mentioned else None, kwargs.pop("self_score", None)))


def generate_weekly_draft(user_id: int, week_start: date, week_end: date) -> dict:
    reports = fetch_all(
        "SELECT * FROM daily_reports WHERE student_id=%s AND report_date BETWEEN %s AND %s ORDER BY report_date",
        (user_id, week_start, week_end))
    if not reports: raise ValueError("本周没有日报记录")
    completed = "\n\n".join(f"📅 {r['report_date']}\n{r['completed_work'] or ''}" for r in reports)
    problems  = "\n\n".join(f"📅 {r['report_date']}\n{r['problems'] or ''}" for r in reports if r.get("problems"))
    plans     = "\n\n".join(f"📅 {r['report_date']}\n{r['next_plan'] or ''}" for r in reports if r.get("next_plan"))
    return {"completed_work": completed or "（请补充）",
            "unfinished_work": "（请补充）", "reason_analysis": "（请分析）",
            "next_week_plan": plans or "（请补充）", "help_needed": "（请补充）",
            "key_results": "（请补充）", "weekly_goal": "（请补充）",
            "daily_report_count": len(reports)}


def list_weeklies(user: dict, page: int, page_size: int, **filters) -> tuple[list[dict], int]:
    base = "SELECT wr.*, u.name AS student_name FROM weekly_reports wr JOIN users u ON wr.student_id=u.id WHERE 1=1"
    params: list = []
    if user["role"] == "student":
        base += " AND wr.student_id=%s"; params.append(user["id"])
    elif user["role"] == "phd":
        ids = get_user_project_ids(user["id"], "phd")
        if not ids: return [], 0
        base += f" AND wr.project_group_id IN ({','.join(['%s']*len(ids))})"; params.extend(ids)
    for k, v in filters.items():
        if v is None: continue
        if k == "keyword":
            kw = f"%{v}%"; base += " AND (wr.completed_work LIKE %s OR wr.key_results LIKE %s)"
            params.extend([kw, kw])
        else: base += f" AND wr.{k}=%s"; params.append(v)
    sql = base + " ORDER BY wr.week_start DESC"
    return fetch_page(sql, tuple(params), page, page_size)


def get_weekly(report_id: int) -> dict | None:
    r = fetch_one("SELECT wr.*, u.name AS student_name FROM weekly_reports wr JOIN users u ON wr.student_id=u.id WHERE wr.id=%s", (report_id,))
    if r:
        r["attachments"] = fetch_all("SELECT * FROM attachments WHERE target_type='weekly_report' AND target_id=%s", (report_id,))
        r["comments"] = fetch_all("""SELECT c.*, u.name AS author_name FROM comments c JOIN users u ON c.author_id=u.id
                                     WHERE c.target_type='weekly_report' AND c.target_id=%s ORDER BY c.created_at""", (report_id,))
    return r


# ============================================================
# 公共
# ============================================================
def add_comment(target_type: str, target_id: int, author_id: int, content: str, action_type: str = "comment") -> int:
    cid = execute_insert(
        "INSERT INTO comments (target_type,target_id,author_id,content,action_type) VALUES (%s,%s,%s,%s,%s)",
        (target_type, target_id, author_id, content, action_type))
    status_map = {"request_change": "need_followup", "approve": "feedback", "mark_risk": "feedback"}
    new_status = status_map.get(action_type, "feedback")
    tbl = "daily_reports" if target_type == "daily_report" else "weekly_reports"
    execute(f"UPDATE {tbl} SET status=%s WHERE id=%s", (new_status, target_id))
    return cid


def get_versions(report_type: str, report_id: int) -> list[dict]:
    return fetch_all(
        """SELECT rv.*, u.name AS editor_name FROM report_versions rv
           JOIN users u ON rv.editor_id=u.id
           WHERE rv.report_type=%s AND rv.report_id=%s ORDER BY rv.version_no DESC""",
        (report_type, report_id))


def _save_version(report_type: str, report_id: int, editor_id: int):
    tbl = "daily_reports" if report_type == "daily" else "weekly_reports"
    r = fetch_one(f"SELECT * FROM {tbl} WHERE id=%s", (report_id,))
    if not r: return
    last = fetch_one("SELECT MAX(version_no) AS mv FROM report_versions WHERE report_type=%s AND report_id=%s",
                     (report_type, report_id))
    vn = (last["mv"] or 0) + 1
    execute_insert(
        "INSERT INTO report_versions (report_type,report_id,version_no,content_snapshot,editor_id) VALUES (%s,%s,%s,%s,%s)",
        (report_type, report_id, vn, json.dumps(r, default=str), editor_id))
