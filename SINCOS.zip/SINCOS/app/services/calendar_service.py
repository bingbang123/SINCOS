"""日历服务"""

from datetime import date, timedelta
from app.database import fetch_one, fetch_all, execute_insert, execute


def list_events(user: dict, **filters) -> list[dict]:
    base = "WHERE 1=1"
    params: list = []
    if user["role"] not in ("teacher","admin","super_admin"):
        base += " AND (visibility!='private' OR owner_id=%s)"; params.append(user["id"])
    for k, v in filters.items():
        if v is None: continue
        if k == "end_at":
            base += " AND (end_at<=%s OR start_at<=%s)"; params.extend([v, v])
        else:
            base += f" AND {k}=%s"; params.append(v)
    return fetch_all(f"SELECT * FROM calendar_events {base} ORDER BY start_at", tuple(params))


def overview(user: dict) -> dict:
    today = date.today()
    events = fetch_all(
        "SELECT * FROM calendar_events WHERE start_at BETWEEN %s AND %s ORDER BY priority DESC, start_at",
        (today, today + timedelta(days=7)))
    return {"overview": {
        "urgent": [e for e in events if e["priority"]=="urgent"],
        "high": [e for e in events if e["priority"]=="high"],
        "total_events": len(events),
        "deadline_count": sum(1 for e in events if e["event_type"]=="task_deadline"),
        "meeting_count": sum(1 for e in events if e["event_type"]=="meeting"),
    }, "events": events}


def create_event(owner_id: int, **kwargs) -> int:
    return execute_insert(
        """INSERT INTO calendar_events
           (title,description,event_type,owner_id,project_group_id,student_id,
            related_type,related_id,start_at,end_at,all_day,priority,visibility,repeat_rule,color,created_by)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
        (kwargs["title"], kwargs.get("description"), kwargs["event_type"], owner_id,
         kwargs.get("project_group_id"), kwargs.get("student_id"),
         kwargs.get("related_type"), kwargs.get("related_id"),
         kwargs["start_at"], kwargs.get("end_at"), kwargs.get("all_day", False),
         kwargs.get("priority","medium"), kwargs.get("visibility","lab"),
         kwargs.get("repeat_rule"), kwargs.get("color"), owner_id))


def update_event(event_id: int, **kwargs) -> bool:
    sets = [f"{k}=%s" for k in kwargs]
    params = list(kwargs.values()) + [event_id]
    execute(f"UPDATE calendar_events SET {','.join(sets)} WHERE id=%s", tuple(params))
    return True


def delete_event(event_id: int) -> bool:
    return execute("DELETE FROM calendar_events WHERE id=%s", (event_id,)) > 0


def sync_deadlines(creator_id: int) -> int:
    tasks = fetch_all(
        """SELECT t.* FROM tasks t LEFT JOIN calendar_events ce ON ce.related_type='task' AND ce.related_id=t.id
           WHERE t.deadline IS NOT NULL AND t.status NOT IN ('done') AND ce.id IS NULL""")
    count = 0
    for t in tasks:
        execute_insert(
            """INSERT INTO calendar_events
               (title,description,event_type,owner_id,project_group_id,student_id,related_type,related_id,start_at,end_at,priority,visibility,created_by)
               VALUES (%s,%s,'task_deadline',%s,%s,%s,'task',%s,%s,%s,%s,'lab',%s)""",
            (f"[Deadline] {t['title']}", t.get("description",""), t["creator_id"],
             t["project_group_id"], t["assignee_id"], t["id"],
             t["deadline"], t["deadline"], t["priority"], creator_id))
        count += 1
    return count
