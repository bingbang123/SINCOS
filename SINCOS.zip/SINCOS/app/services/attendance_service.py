"""到场记录服务"""

from datetime import date
from app.database import fetch_one, fetch_all, fetch_page, execute_insert, execute
from app.auth import get_user_project_ids


def batch_record(records: list[dict], record_date: date, recorder_id: int) -> list[dict]:
    results = []
    for item in records:
        rid = execute_insert(
            """INSERT INTO attendance_records
               (student_id, project_group_id, attendance_date, presence_status, recorder_id, recorded_at, remark)
               VALUES (%s,%s,%s,%s,%s,NOW(),%s)
               ON DUPLICATE KEY UPDATE presence_status=VALUES(presence_status),
                                       recorder_id=VALUES(recorder_id),
                                       recorded_at=NOW(),
                                       remark=VALUES(remark)""",
            (item["student_id"], item.get("project_group_id"), record_date,
             item["presence_status"], recorder_id, item.get("remark")))
        results.append({"student_id": item["student_id"], "record_id": rid})
    return results


def update_record(record_id: int, **kwargs) -> bool:
    sets = [f"{k}=%s" for k in kwargs]
    params = list(kwargs.values()) + [record_id]
    return execute(f"UPDATE attendance_records SET {','.join(sets)} WHERE id=%s", tuple(params)) > 0


def get_my_records(user_id: int, month: str | None = None) -> list[dict]:
    sql = "SELECT * FROM attendance_records WHERE student_id=%s"
    params = [user_id]
    if month:
        sql += " AND DATE_FORMAT(attendance_date,'%%Y-%%m')=%s"
        params.append(month)
    return fetch_all(sql + " ORDER BY attendance_date DESC", tuple(params))


def list_records(user: dict, page: int, page_size: int,
                 student_id: int | None, project_group_id: int | None,
                 attendance_date: date | None, presence_status: str | None):
    base = """SELECT ar.*, u.name AS student_name
              FROM attendance_records ar JOIN users u ON ar.student_id=u.id WHERE 1=1"""
    params: list = []

    if user["role"] == "phd":
        ids = get_user_project_ids(user["id"], "phd")
        if not ids: return [], 0
        base += f" AND ar.project_group_id IN ({','.join(['%s']*len(ids))})"
        params.extend(ids)

    if student_id:       base += " AND ar.student_id=%s";        params.append(student_id)
    if project_group_id: base += " AND ar.project_group_id=%s";  params.append(project_group_id)
    if attendance_date:  base += " AND ar.attendance_date=%s";   params.append(attendance_date)
    if presence_status:  base += " AND ar.presence_status=%s";    params.append(presence_status)

    sql = base + " ORDER BY ar.attendance_date DESC, u.name"
    return fetch_page(sql, tuple(params), page, page_size)


def statistics(target_date: date | None, project_group_id: int | None, user: dict) -> dict:
    target = target_date or date.today()
    base = "WHERE ar.attendance_date=%s"
    params: list = [target]

    if user["role"] == "phd":
        ids = get_user_project_ids(user["id"], "phd")
        if not ids: return {"total":0,"present":0,"absent":0,"unknown":0}
        base += f" AND ar.project_group_id IN ({','.join(['%s']*len(ids))})"
        params.extend(ids)
    if project_group_id:
        base += " AND ar.project_group_id=%s"; params.append(project_group_id)

    stats = fetch_one(
        f"""SELECT COUNT(*) AS total,
                   SUM(CASE WHEN presence_status='present' THEN 1 ELSE 0 END) AS present,
                   SUM(CASE WHEN presence_status='absent'  THEN 1 ELSE 0 END) AS absent,
                   SUM(CASE WHEN presence_status='unknown' THEN 1 ELSE 0 END) AS unknown
            FROM attendance_records ar {base}""", tuple(params)) or {}

    no_report = fetch_all(
        """SELECT u.id,u.name FROM attendance_records ar
           JOIN users u ON ar.student_id=u.id
           LEFT JOIN daily_reports dr ON dr.student_id=ar.student_id AND dr.report_date=ar.attendance_date
           WHERE ar.presence_status='present' AND ar.attendance_date=%s AND dr.id IS NULL""", (target,))

    return {**stats, "present_no_report": no_report, "present_no_report_count": len(no_report)}
