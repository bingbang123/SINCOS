"""课表服务 — 上传/解析/查询"""

import os, re
from app.database import fetch_one, fetch_all, execute_insert, execute
from app.config import UPLOAD_DIR
from app.auth import get_user_project_ids


def upload(file_name: str, file_content: bytes, student_id: int, semester: str) -> dict:
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    file_path = os.path.join(UPLOAD_DIR, f"schedule_{student_id}_{file_name}")
    with open(file_path, "wb") as f:
        f.write(file_content)
    file_type = "docx" if file_name.endswith(".docx") else "doc"
    sid = execute_insert(
        """INSERT INTO student_schedules (student_id,semester,source_file_name,source_file_url,file_type,parse_status)
           VALUES (%s,%s,%s,%s,%s,'pending')""",
        (student_id, semester, file_name, file_path, file_type))
    return {"schedule_id": sid, "file_name": file_name}


def parse(schedule_id: int) -> dict:
    s = fetch_one("SELECT * FROM student_schedules WHERE id=%s", (schedule_id,))
    if not s: raise ValueError("课表不存在")
    execute("DELETE FROM student_schedule_items WHERE schedule_id=%s", (schedule_id,))
    items = _parse_docx(s["source_file_url"])
    for it in items:
        execute_insert(
            """INSERT INTO student_schedule_items
               (schedule_id,student_id,weekday,section_label,section_no,start_time,end_time,
                course_name,class_name,weeks_text,teacher_name,location,raw_text)
               VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
            (schedule_id, s["student_id"], it["weekday"], it["section_label"],
             it["section_no"], it["start_time"], it["end_time"], it["course_name"],
             it.get("class_name"), it.get("weeks_text"), it.get("teacher_name"),
             it.get("location"), it.get("raw_text")))
    execute("UPDATE student_schedules SET parse_status='success',parse_message=NULL WHERE id=%s", (schedule_id,))
    return {"parsed_count": len(items)}


def _parse_docx(file_path: str) -> list[dict]:
    from docx import Document
    doc = Document(file_path)
    if not doc.tables: raise ValueError("未找到课表")
    table = doc.tables[0]
    SECTION_TIMES = {
        1:("08:00","08:50"),2:("08:55","09:45"),3:("10:00","10:50"),4:("10:55","11:45"),
        5:("14:00","14:50"),6:("14:55","15:45"),7:("16:00","16:50"),8:("16:55","17:45"),
        9:("19:00","19:50"),10:("19:55","20:45"),11:("20:50","21:40")}
    LABELS = {1:"上午1",2:"上午2",3:"上午3",4:"上午4",5:"下午5",6:"下午6",7:"下午7",
              8:"下午8",9:"晚上9",10:"晚上10",11:"晚上11"}
    items = []
    for row in table.rows:
        cells = [c.text.strip() for c in row.cells]
        if not cells or "节次" in cells[0] and "星期一" in "".join(cells): continue
        m = re.match(r'(\d+)', cells[0])
        if not m: continue
        sn = int(m.group(1))
        if sn not in SECTION_TIMES: continue
        st, et = SECTION_TIMES[sn]
        for di in range(1, min(8, len(cells))):
            ct = cells[di].strip()
            if not ct: continue
            raw = ct
            wm = re.search(r'\[([^\]]+)\]', ct)
            weeks = wm.group(1) if wm else ""
            if wm: ct = ct.replace(wm.group(0)," ")
            tl = re.findall(r'([^\s\[\]]+)\[([^\]]+)\]', ct)
            teacher, loc = tl[-1] if tl else ("","")
            if tl: ct = re.sub(re.escape(f"{teacher}[{loc}]")," ",ct).strip()
            parts = ct.split()
            cn = " ".join(parts[:2]) if len(parts)>1 else (parts[0] if parts else "")
            items.append({"weekday":di,"section_label":LABELS[sn],"section_no":sn,
                          "start_time":st,"end_time":et,"course_name":cn,"class_name":"",
                          "weeks_text":weeks,"teacher_name":teacher,"location":loc,"raw_text":raw})
    return items


def my_schedule(user_id: int) -> list[dict]:
    return fetch_all(
        """SELECT ssi.*, ss.semester, ss.parse_status
           FROM student_schedule_items ssi
           JOIN student_schedules ss ON ssi.schedule_id=ss.id
           WHERE ssi.student_id=%s ORDER BY ssi.weekday, ssi.section_no""", (user_id,))


def list_all(user: dict, student_id: int | None,
             project_group_id: int | None, weekday: int | None) -> list[dict]:
    sql = """SELECT ssi.*, u.name AS student_name, ss.semester
             FROM student_schedule_items ssi
             JOIN users u ON ssi.student_id=u.id
             JOIN student_schedules ss ON ssi.schedule_id=ss.id
             WHERE ss.parse_status IN ('success','manually_fixed')"""
    params: list = []
    if user["role"] == "phd":
        ids = get_user_project_ids(user["id"], "phd")
        if not ids: return []
        sql += f" AND ssi.student_id IN (SELECT user_id FROM project_members WHERE project_group_id IN ({','.join(['%s']*len(ids))}))"
        params.extend(ids)
    if student_id:       sql += " AND ssi.student_id=%s";       params.append(student_id)
    if project_group_id: sql += " AND ssi.student_id IN (SELECT user_id FROM project_members WHERE project_group_id=%s)"; params.append(project_group_id)
    if weekday:          sql += " AND ssi.weekday=%s";           params.append(weekday)
    return fetch_all(sql + " ORDER BY ssi.student_id,ssi.weekday,ssi.section_no", tuple(params))


def free_busy(weekday: int, project_group_id: int | None, user: dict) -> list[dict]:
    sql = """SELECT ssi.student_id,u.name,ssi.weekday,ssi.section_no,ssi.start_time,ssi.end_time,ssi.course_name
             FROM student_schedule_items ssi
             JOIN users u ON ssi.student_id=u.id
             JOIN student_schedules ss ON ssi.schedule_id=ss.id
             WHERE ss.parse_status IN ('success','manually_fixed') AND ssi.weekday=%s"""
    params = [weekday]
    if project_group_id:
        sql += " AND ssi.student_id IN (SELECT user_id FROM project_members WHERE project_group_id=%s)"
        params.append(project_group_id)
    return fetch_all(sql + " ORDER BY ssi.student_id,ssi.section_no", tuple(params))


def upload_status(project_group_id: int | None) -> list[dict]:
    sql = """SELECT u.id,u.name,u.student_no,ss.id AS schedule_id,ss.semester,ss.parse_status,ss.uploaded_at
             FROM users u
             LEFT JOIN student_schedules ss ON u.id=ss.student_id
               AND ss.id=(SELECT MAX(id) FROM student_schedules WHERE student_id=u.id)
             WHERE u.role='student'"""
    params = []
    if project_group_id:
        sql += " AND u.id IN (SELECT user_id FROM project_members WHERE project_group_id=%s)"
        params.append(project_group_id)
    return fetch_all(sql, tuple(params) if params else None)


def confirm(schedule_id: int, student_id: int, semester: str):
    execute("UPDATE student_schedules SET parse_status='manually_fixed',confirmed_at=NOW(),semester=%s WHERE id=%s AND student_id=%s",
            (semester, schedule_id, student_id))


def update_item(item_id: int, **kwargs):
    sets = [f"{k}=%s" for k in kwargs]
    params = list(kwargs.values()) + [item_id]
    execute(f"UPDATE student_schedule_items SET {','.join(sets)} WHERE id=%s", tuple(params))
