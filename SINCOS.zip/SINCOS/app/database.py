"""数据库层 — pymysql 连接管理 + 查询工具"""

import pymysql
from pymysql.cursors import DictCursor
from contextlib import contextmanager
from typing import Optional
from app.config import DB_CONFIG


def get_connection():
    return pymysql.connect(**DB_CONFIG, cursorclass=DictCursor)


@contextmanager
def get_db():
    conn = get_connection()
    cur = conn.cursor()
    try:
        yield conn, cur
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        cur.close()
        conn.close()


# ---- 便捷查询 ----

def execute(sql: str, params: Optional[tuple] = None) -> int:
    """写操作, 返回影响行数"""
    with get_db() as (_, cur):
        return cur.execute(sql, params)


def execute_insert(sql: str, params: Optional[tuple] = None) -> int:
    """INSERT, 返回自增ID"""
    with get_db() as (_, cur):
        cur.execute(sql, params)
        return cur.lastrowid


def fetch_one(sql: str, params: Optional[tuple] = None) -> Optional[dict]:
    with get_db() as (_, cur):
        cur.execute(sql, params)
        return cur.fetchone()


def fetch_all(sql: str, params: Optional[tuple] = None) -> list[dict]:
    with get_db() as (_, cur):
        cur.execute(sql, params)
        return cur.fetchall()


def fetch_page(sql: str, params: Optional[tuple] = None,
               page: int = 1, page_size: int = 20) -> tuple[list[dict], int]:
    total_row = fetch_one(f"SELECT COUNT(*) AS total FROM ({sql}) AS _c", params)
    total = total_row["total"] if total_row else 0
    offset = (page - 1) * page_size
    rows = fetch_all(f"{sql} LIMIT {page_size} OFFSET {offset}", params)
    return rows, total
