"""审计中间件 — 记录写操作到 audit_logs"""

from fastapi import Request
from app.database import execute_insert


async def audit_middleware(request: Request, call_next):
    response = await call_next(request)
    if request.method in ("GET","OPTIONS","HEAD"): return response
    try:
        token = request.headers.get("Authorization","").replace("Bearer ","")
        if token:
            import jwt
            from app.config import JWT_SECRET, JWT_ALGORITHM
            payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
            execute_insert(
                "INSERT INTO audit_logs (user_id,action,target_type,detail,ip_address,user_agent) VALUES (%s,%s,%s,%s,%s,%s)",
                (payload["user_id"], f"{request.method}:{request.url.path}",
                 request.url.path.split("/")[3] if len(request.url.path.split("/"))>3 else None,
                 f"status={response.status_code}",
                 request.client.host if request.client else None,
                 (request.headers.get("user-agent","") or "")[:500]))
    except Exception:
        pass
    return response
