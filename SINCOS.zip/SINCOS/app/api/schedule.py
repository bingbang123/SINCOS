"""课表路由"""

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Query
from app.schemas import UpdateScheduleItemReq, ConfirmScheduleReq
from app.auth import get_current_user, require_roles
from app.services import schedule_service

router = APIRouter(prefix="/api/schedules", tags=["课表"])


@router.post("/upload")
async def upload(file: UploadFile = File(...), semester: str = "2026春季学期",
                 u=Depends(require_roles("student"))):
    if not file.filename or not file.filename.endswith((".doc",".docx")):
        raise HTTPException(400, "仅支持 .doc/.docx")
    content = await file.read()
    return schedule_service.upload(file.filename, content, u["id"], semester)


@router.post("/{schedule_id}/parse")
def parse(schedule_id: int, u=Depends(require_roles("research_assistant","admin","super_admin"))):
    try:
        return schedule_service.parse(schedule_id)
    except ValueError as e:
        raise HTTPException(404, str(e))
    except Exception as e:
        raise HTTPException(500, f"解析失败: {e}")


@router.get("/me")
def my_schedule(u=Depends(get_current_user)):
    rows = schedule_service.my_schedule(u["id"])
    return {"list": rows, "total": len(rows)}


@router.put("/{schedule_id}")
def update_item(schedule_id: int, item_id: int, req: UpdateScheduleItemReq,
                u=Depends(require_roles("student"))):
    updates = {k: v for k, v in req.dict().items() if v is not None}
    if not updates: return {"message": "无变更"}
    schedule_service.update_item(item_id, **updates)
    return {"message": "更新成功"}


@router.post("/{schedule_id}/confirm")
def confirm(schedule_id: int, req: ConfirmScheduleReq, u=Depends(require_roles("student"))):
    schedule_service.confirm(schedule_id, u["id"], req.semester)
    return {"message": "课表已确认"}


@router.get("")
def list_all(student_id: int | None = None, project_group_id: int | None = None,
             weekday: int | None = None, u=Depends(get_current_user)):
    if u["role"] == "student": raise HTTPException(403, "请使用 /api/schedules/me")
    rows = schedule_service.list_all(u, student_id, project_group_id, weekday)
    return {"list": rows, "total": len(rows)}


@router.get("/free-busy")
def free_busy(weekday: int = Query(..., ge=1, le=7), project_group_id: int | None = None,
              u=Depends(get_current_user)):
    if u["role"] == "student": raise HTTPException(403, "权限不足")
    rows = schedule_service.free_busy(weekday, project_group_id, u)
    return {"list": rows, "total": len(rows)}


@router.get("/upload-status")
def upload_status(project_group_id: int | None = None,
                  u=Depends(require_roles("research_assistant","admin","super_admin"))):
    return {"list": schedule_service.upload_status(project_group_id)}
