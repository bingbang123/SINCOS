"""日历路由"""

from fastapi import APIRouter, Depends, HTTPException, Query
from datetime import datetime
from app.schemas import CreateEventReq, UpdateEventReq
from app.auth import get_current_user, require_roles
from app.services import calendar_service

router = APIRouter(prefix="/api/calendar", tags=["日历"])


@router.get("/events")
def list_events(start_at: datetime | None = None, end_at: datetime | None = None,
                event_type: str | None = None, project_group_id: int | None = None,
                student_id: int | None = None, priority: str | None = None,
                u=Depends(get_current_user)):
    events = calendar_service.list_events(u, start_at=start_at, end_at=end_at,
        event_type=event_type, project_group_id=project_group_id,
        student_id=student_id, priority=priority)
    return {"events": events}


@router.get("/overview")
def overview(u=Depends(require_roles("teacher","admin","super_admin"))):
    return calendar_service.overview(u)


@router.post("/events")
def create(req: CreateEventReq, u=Depends(get_current_user)):
    eid = calendar_service.create_event(u["id"], **req.model_dump())
    return {"id": eid, "message": "事件已创建"}


@router.put("/events/{event_id}")
def update(event_id: int, req: UpdateEventReq, u=Depends(get_current_user)):
    from app.database import fetch_one
    ev = fetch_one("SELECT * FROM calendar_events WHERE id=%s", (event_id,))
    if not ev: raise HTTPException(404, "事件不存在")
    if ev["owner_id"] != u["id"] and u["role"] not in ("admin","super_admin"):
        raise HTTPException(403, "只能编辑自己的事件")
    updates = {k: v for k, v in req.dict().items() if v is not None}
    calendar_service.update_event(event_id, **updates)
    return {"message": "更新成功"}


@router.delete("/events/{event_id}")
def delete(event_id: int, u=Depends(get_current_user)):
    from app.database import fetch_one
    ev = fetch_one("SELECT * FROM calendar_events WHERE id=%s", (event_id,))
    if not ev: raise HTTPException(404, "事件不存在")
    if ev["owner_id"] != u["id"] and u["role"] not in ("admin","super_admin"):
        raise HTTPException(403, "只能删除自己的事件")
    calendar_service.delete_event(event_id)
    return {"message": "已删除"}


@router.post("/sync-task-deadlines")
def sync_deadlines(u=Depends(require_roles("teacher","admin","super_admin"))):
    n = calendar_service.sync_deadlines(u["id"])
    return {"synced_count": n, "message": f"已同步 {n} 个 deadline"}
