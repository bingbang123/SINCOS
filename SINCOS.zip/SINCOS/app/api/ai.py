"""AI 助手路由"""

from fastapi import APIRouter, Depends, HTTPException
from app.schemas import ChatReq, WeeklyDraftReq, ProjectSummaryReq
from app.auth import get_current_user
from app.services import ai_service

router = APIRouter(prefix="/api/ai", tags=["AI助手"])


@router.post("/chat")
def chat(req: ChatReq, u=Depends(get_current_user)):
    return ai_service.chat(u, req.message, req.conversation_id)


@router.get("/conversations")
def list_conversations(u=Depends(get_current_user)):
    return {"conversations": ai_service.list_conversations(u["id"])}


@router.get("/conversations/{conv_id}")
def get_conversation(conv_id: int, u=Depends(get_current_user)):
    c = ai_service.get_conversation(conv_id, u["id"])
    if not c: raise HTTPException(404, "对话不存在")
    return {"conversation": c}


@router.post("/weekly-draft")
def weekly_draft(req: WeeklyDraftReq, u=Depends(get_current_user)):
    try:
        draft = ai_service.generate_weekly_draft_ai(u["id"], req.week_start, req.week_end)
        return {"draft": draft}
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.post("/project-summary")
def project_summary(req: ProjectSummaryReq, u=Depends(get_current_user)):
    from datetime import date, timedelta
    from app.database import fetch_all
    week_ago = date.today() - timedelta(days=7)
    tasks = fetch_all("SELECT * FROM tasks WHERE project_group_id=%s ORDER BY FIELD(priority,'urgent','high','medium','low'),deadline", (req.project_group_id,))
    reports = fetch_all("""SELECT wr.*, u.name AS student_name FROM weekly_reports wr
                           JOIN users u ON wr.student_id=u.id
                           WHERE wr.project_group_id=%s AND wr.week_start>=%s""", (req.project_group_id, week_ago))
    return {"summary": {"task_count": len(tasks), "done": sum(1 for t in tasks if t["status"]=="done"),
                        "overdue": sum(1 for t in tasks if t["status"]=="overdue"),
                        "high_priority": sum(1 for t in tasks if t["priority"] in ("high","urgent")),
                        "weekly_report_count": len(reports)},
            "tasks": tasks, "reports": reports}
