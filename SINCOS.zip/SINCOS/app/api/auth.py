"""认证路由 — 登录/注册/Token"""

from fastapi import APIRouter, HTTPException, Depends
from app.schemas import LoginReq, RegisterReq, TokenResp
from app.database import fetch_one, execute_insert
from app.auth import hash_password, verify_password, create_token, get_current_user

router = APIRouter(prefix="/api/auth", tags=["认证"])


@router.post("/login")
def login(req: LoginReq):
    user = fetch_one(
        "SELECT id,name,email,role,status,password_hash FROM users WHERE email=%s OR student_no=%s OR employee_no=%s",
        (req.account, req.account, req.account))
    if not user:                       raise HTTPException(401, "账号不存在")
    if user["status"] != "active":     raise HTTPException(403, "账号已禁用")
    if not verify_password(req.password, user["password_hash"]):
        raise HTTPException(401, "密码错误")
    token = create_token(user["id"], user["role"])
    return TokenResp(token=token, user={"id":user["id"],"name":user["name"],"email":user["email"],"role":user["role"]})


@router.post("/register")
def register(req: RegisterReq):
    if fetch_one("SELECT id FROM users WHERE email=%s", (req.email,)):
        raise HTTPException(400, "邮箱已注册")
    uid = execute_insert(
        "INSERT INTO users (name,email,phone,student_no,password_hash,role) VALUES (%s,%s,%s,%s,%s,%s)",
        (req.name, req.email, req.phone, req.student_no, hash_password(req.password), req.role))
    token = create_token(uid, req.role)
    return TokenResp(token=token, user={"id":uid,"name":req.name,"email":req.email,"role":req.role})


@router.post("/logout")
def logout(_u=Depends(get_current_user)):
    return {"message": "已退出"}


@router.get("/me")
def me(u=Depends(get_current_user)):
    return {"user": u}
