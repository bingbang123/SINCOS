"""项目组路由"""

from fastapi import APIRouter, Depends, HTTPException
from datetime import date, timedelta
from app.schemas import CreateProjectReq, UpdateProjectReq, AddMemberReq
from app.database import fetch_one, fetch_all, execute_insert, execute
from app.auth import get_current_user, require_roles, get_user_project_ids

router = APIRouter(prefix="/api/project-groups", tags=["项目组"])


@router.get("")
def list_all(u=Depends(get_current_user)):
    if u["role"] in ("admin","super_admin","teacher","research_assistant"):
        rows = fetch_all(
            """SELECT pg.*, u.name AS teacher_name, u2.name AS phd_owner_name
               FROM project_groups pg LEFT JOIN users u ON pg.teacher_id=u.id
               LEFT JOIN users u2 ON pg.phd_owner_id=u2.id ORDER BY pg.id""")
    else:
        ids = get_user_project_ids(u["id"], u["role"])
        if not ids: return {"list": [], "total": 0}
        ph = ",".join(["%s"]*len(ids))
        rows = fetch_all(
            f"""SELECT pg.*, u.name AS teacher_name, u2.name AS phd_owner_name
                FROM project_groups pg LEFT JOIN users u ON pg.teacher_id=u.id
                LEFT JOIN users u2 ON pg.phd_owner_id=u2.id WHERE pg.id IN ({ph})""", tuple(ids))
    return {"list": rows, "total": len(rows)}


@router.post("")
def create(req: CreateProjectReq, u=Depends(require_roles("admin","super_admin"))):
    gid = execute_insert(
        "INSERT INTO project_groups (code,name,description,teacher_id,phd_owner_id,start_date,end_date) VALUES (%s,%s,%s,%s,%s,%s,%s)",
        (req.code, req.name, req.description, req.teacher_id, req.phd_owner_id, req.start_date, req.end_date))
    return {"id": gid, "message": "已创建"}


@router.put("/{group_id}")
def update(group_id: int, req: UpdateProjectReq, u=Depends(require_roles("admin","super_admin"))):
    updates = {k: v for k, v in req.dict().items() if v is not None}
    if updates:
        sets = [f"{k}=%s" for k in updates]
        execute(f"UPDATE project_groups SET {','.join(sets)} WHERE id=%s", tuple(updates.values()) + (group_id,))
    return {"message": "已更新"}


@router.get("/{group_id}")
def get(group_id: int, u=Depends(get_current_user)):
    p = fetch_one(
        """SELECT pg.*, u.name AS teacher_name, u2.name AS phd_owner_name
           FROM project_groups pg LEFT JOIN users u ON pg.teacher_id=u.id
           LEFT JOIN users u2 ON pg.phd_owner_id=u2.id WHERE pg.id=%s""", (group_id,))
    if not p: raise HTTPException(404, "不存在")
    p["members"] = fetch_all(
        """SELECT pm.*, u.name, u.role FROM project_members pm
           JOIN users u ON pm.user_id=u.id WHERE pm.project_group_id=%s""", (group_id,))
    return {"project": p}


@router.get("/{group_id}/summary")
def summary(group_id: int, u=Depends(get_current_user)):
    today = date.today()
    stats = fetch_one(
        """SELECT COUNT(DISTINCT u.id) AS total_members,
                  COUNT(DISTINCT dr.student_id) AS submitted_today
           FROM project_members pm JOIN users u ON pm.user_id=u.id AND u.role='student'
           LEFT JOIN daily_reports dr ON dr.student_id=pm.user_id AND dr.report_date=%s
           WHERE pm.project_group_id=%s""", (today, group_id))
    task_stats = fetch_one(
        """SELECT COUNT(*) AS total, SUM(CASE WHEN status='done' THEN 1 ELSE 0 END) AS done,
                  SUM(CASE WHEN (status='overdue' OR (deadline<NOW() AND status!='done')) THEN 1 ELSE 0 END) AS overdue,
                  SUM(CASE WHEN priority IN ('high','urgent') AND status!='done' THEN 1 ELSE 0 END) AS high_risk
           FROM tasks WHERE project_group_id=%s""", (group_id,))
    return {"report_stats": stats, "task_stats": task_stats}


@router.post("/{group_id}/members")
def add_member(group_id: int, req: AddMemberReq, u=Depends(require_roles("admin","super_admin"))):
    execute_insert(
        "INSERT INTO project_members (project_group_id,user_id,member_role) VALUES (%s,%s,%s) ON DUPLICATE KEY UPDATE member_role=VALUES(member_role)",
        (group_id, req.user_id, req.member_role))
    return {"message": "已添加"}


@router.delete("/{group_id}/members/{user_id}")
def remove_member(group_id: int, user_id: int, u=Depends(require_roles("admin","super_admin"))):
    execute("DELETE FROM project_members WHERE project_group_id=%s AND user_id=%s", (group_id, user_id))
    return {"message": "已移除"}
