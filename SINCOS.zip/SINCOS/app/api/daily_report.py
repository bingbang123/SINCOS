"""日报路由"""

from fastapi import APIRouter, Depends, HTTPException, Query
from datetime import date
from app.schemas import CreateDailyReportReq, UpdateDailyReportReq, CreateCommentReq
from app.auth import get_current_user, require_roles
from app.services import report_service

router = APIRouter(prefix="/api/daily-reports", tags=["日报"])


@router.post("")
def create(req: CreateDailyReportReq, u=Depends(require_roles("student"))):
    try:
        rid = report_service.create_daily(u["id"], **req.model_dump())
        return {"id": rid, "message": "草稿已创建"}
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.put("/{report_id}")
def update(report_id: int, req: UpdateDailyReportReq, u=Depends(require_roles("student"))):
    r = report_service.get_daily(report_id)
    if not r or r["student_id"] != u["id"]: raise HTTPException(404, "日报不存在")
    if r["status"] not in ("draft","need_followup"): raise HTTPException(400, "已提交,不能编辑")
    report_service.update_daily(report_id, u["id"], **req.model_dump())
    return {"message": "更新成功"}


@router.post("/{report_id}/submit")
def submit(report_id: int, u=Depends(require_roles("student"))):
    report_service.submit_daily(report_id, u["id"])
    return {"message": "已提交"}


@router.get("")
def list_all(page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100),
             student_id: int | None = None, project_group_id: int | None = None,
             start_date: date | None = None, end_date: date | None = None,
             status: str | None = None, has_problems: bool | None = None,
             keyword: str | None = None, u=Depends(get_current_user)):
    rows, total = report_service.list_dailies(u, page, page_size,
        student_id=student_id, project_group_id=project_group_id,
        start_date=start_date, end_date=end_date, status=status,
        has_problems=has_problems, keyword=keyword)
    return {"list": rows, "total": total, "page": page, "page_size": page_size}


@router.get("/{report_id}")
def get(report_id: int, u=Depends(get_current_user)):
    r = report_service.get_daily(report_id)
    if not r: raise HTTPException(404, "不存在")
    if u["role"] == "student" and r["student_id"] != u["id"]: raise HTTPException(403, "无权查看")
    return {"report": r}


@router.post("/{report_id}/comments")
def comment(report_id: int, req: CreateCommentReq, u=Depends(require_roles("phd","teacher","admin","super_admin"))):
    cid = report_service.add_comment("daily_report", report_id, u["id"], req.content, req.action_type)
    return {"comment_id": cid, "message": "评论成功"}


@router.get("/{report_id}/versions")
def versions(report_id: int, u=Depends(get_current_user)):
    return {"versions": report_service.get_versions("daily", report_id)}
