"""到场记录路由"""

from fastapi import APIRouter, Depends, HTTPException, Query
from datetime import date
from app.schemas import BatchAttendanceReq, UpdateAttendanceReq
from app.auth import get_current_user, require_roles
from app.services import attendance_service

router = APIRouter(prefix="/api/attendance", tags=["到场记录"])


@router.post("/daily-records")
def batch_record(req: BatchAttendanceReq, u=Depends(require_roles("research_assistant","admin","super_admin"))):
    records = [r.model_dump() for r in req.records]
    results = attendance_service.batch_record(records, req.attendance_date or date.today(), u["id"])
    return {"message": f"已记录 {len(results)} 名", "results": results}


@router.put("/daily-records/{record_id}")
def update_record(record_id: int, req: UpdateAttendanceReq, u=Depends(require_roles("research_assistant","admin","super_admin"))):
    updates = {k: v for k, v in req.dict().items() if v is not None}
    if not updates: return {"message": "无变更"}
    if not attendance_service.update_record(record_id, **updates):
        raise HTTPException(404, "记录不存在")
    return {"message": "更新成功"}


@router.get("/me")
def my_attendance(month: str | None = None, u=Depends(get_current_user)):
    rows = attendance_service.get_my_records(u["id"], month)
    return {"list": rows, "total": len(rows)}


@router.get("")
def list_attendance(page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100),
                    student_id: int | None = None, project_group_id: int | None = None,
                    attendance_date: date | None = None, presence_status: str | None = None,
                    u=Depends(get_current_user)):
    if u["role"] == "student": raise HTTPException(403, "请使用 /api/attendance/me")
    rows, total = attendance_service.list_records(u, page, page_size, student_id, project_group_id, attendance_date, presence_status)
    return {"list": rows, "total": total, "page": page, "page_size": page_size}


@router.get("/statistics")
def statistics(target_date: date | None = None, project_group_id: int | None = None, u=Depends(get_current_user)):
    if u["role"] == "student": raise HTTPException(403, "权限不足")
    return attendance_service.statistics(target_date, project_group_id, u)
