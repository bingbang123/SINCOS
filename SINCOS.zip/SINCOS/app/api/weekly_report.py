"""周报路由"""

from fastapi import APIRouter, Depends, HTTPException, Query
from datetime import date
from app.schemas import CreateWeeklyReportReq, UpdateWeeklyReportReq, CreateCommentReq, WeeklyDraftReq
from app.auth import get_current_user, require_roles
from app.services import report_service

router = APIRouter(prefix="/api/weekly-reports", tags=["周报"])


@router.post("")
def create(req: CreateWeeklyReportReq, u=Depends(require_roles("student"))):
    rid = report_service.create_weekly(u["id"], **req.model_dump())
    return {"id": rid, "message": "草稿已创建"}


@router.put("/{report_id}")
def update(report_id: int, req: UpdateWeeklyReportReq, u=Depends(require_roles("student"))):
    updates = {k: v for k, v in req.dict().items() if v is not None}
    if updates:
        report_service.update_daily(report_id, u["id"], **updates)
    return {"message": "更新成功"}


@router.post("/{report_id}/submit")
def submit(report_id: int, u=Depends(require_roles("student"))):
    from app.database import execute
    execute("UPDATE weekly_reports SET status='submitted',submitted_at=NOW() WHERE id=%s AND student_id=%s",
            (report_id, u["id"]))
    return {"message": "已提交"}


@router.post("/generate-draft")
def generate_draft(req: WeeklyDraftReq, u=Depends(require_roles("student"))):
    try:
        return report_service.generate_weekly_draft(u["id"], req.week_start, req.week_end)
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.get("")
def list_all(page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100),
             student_id: int | None = None, project_group_id: int | None = None,
             week_start: date | None = None, status: str | None = None,
             keyword: str | None = None, u=Depends(get_current_user)):
    rows, total = report_service.list_weeklies(u, page, page_size,
        student_id=student_id, project_group_id=project_group_id,
        week_start=week_start, status=status, keyword=keyword)
    return {"list": rows, "total": total, "page": page, "page_size": page_size}


@router.get("/{report_id}")
def get(report_id: int, u=Depends(get_current_user)):
    r = report_service.get_weekly(report_id)
    if not r: raise HTTPException(404, "不存在")
    if u["role"] == "student" and r["student_id"] != u["id"]: raise HTTPException(403, "无权查看")
    return {"report": r}


@router.post("/{report_id}/comments")
def comment(report_id: int, req: CreateCommentReq, u=Depends(require_roles("phd","teacher","admin","super_admin"))):
    cid = report_service.add_comment("weekly_report", report_id, u["id"], req.content, req.action_type)
    return {"comment_id": cid, "message": "评论成功"}


@router.get("/{report_id}/versions")
def versions(report_id: int, u=Depends(get_current_user)):
    return {"versions": report_service.get_versions("weekly", report_id)}
