"""任务路由"""

from fastapi import APIRouter, Depends, HTTPException, Query
from datetime import date, datetime
from app.schemas import CreateTaskReq, UpdateTaskReq, CreateCommentReq
from app.auth import get_current_user, require_roles
from app.services import task_service, report_service

router = APIRouter(prefix="/api/tasks", tags=["任务"])


@router.post("")
def create(req: CreateTaskReq, u=Depends(require_roles("phd","teacher","admin","super_admin"))):
    tid = task_service.create_task(u["id"], **req.model_dump())
    return {"id": tid, "message": "任务已创建"}


@router.put("/{task_id}")
def update(task_id: int, req: UpdateTaskReq, u=Depends(get_current_user)):
    t = task_service.get_task(task_id)
    if not t: raise HTTPException(404, "任务不存在")
    if u["role"] == "student":
        if t["assignee_id"] != u["id"]: raise HTTPException(403, "只能更新自己的任务")
        allowed = {"status"}
        for f, v in req.dict().items():
            if v is not None and f not in allowed: raise HTTPException(403, f"学生不能修改 {f}")
    updates = {k: v for k, v in req.dict().items() if v is not None}
    task_service.update_task(task_id, **updates)
    return {"message": "更新成功"}


@router.get("")
def list_all(page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100),
             project_group_id: int | None = None, assignee_id: int | None = None,
             status: str | None = None, priority: str | None = None,
             overdue_only: bool = False, u=Depends(get_current_user)):
    rows, total = task_service.list_tasks(u, page, page_size,
        project_group_id=project_group_id, assignee_id=assignee_id,
        status=status, priority=priority, overdue_only=overdue_only)
    return {"list": rows, "total": total, "page": page, "page_size": page_size}


@router.get("/kanban")
def kanban(project_group_id: int | None = None, u=Depends(get_current_user)):
    return task_service.kanban(u, project_group_id)


@router.get("/{task_id}")
def get(task_id: int, u=Depends(get_current_user)):
    t = task_service.get_task(task_id)
    if not t: raise HTTPException(404, "不存在")
    return {"task": t}


@router.post("/{task_id}/comments")
def comment(task_id: int, req: CreateCommentReq, u=Depends(get_current_user)):
    cid = report_service.add_comment("task", task_id, u["id"], req.content, req.action_type)
    return {"comment_id": cid, "message": "评论成功"}


@router.post("/{task_id}/complete")
def complete(task_id: int, u=Depends(get_current_user)):
    task_service.update_task(task_id, status="done")
    return {"message": "任务已完成"}
