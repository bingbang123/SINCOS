"""管理员路由 — 用户/角色/审计"""

from fastapi import APIRouter, Depends, HTTPException, Query
from app.schemas import CreateUserReq, UpdateUserReq, AssignRoleReq
from app.database import fetch_one, fetch_all, fetch_page, execute_insert, execute
from app.auth import hash_password, get_current_user, require_roles

router = APIRouter(prefix="/api/admin", tags=["管理员"])


@router.get("/users")
def list_users(page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100),
               role: str | None = None, status: str | None = None, keyword: str | None = None,
               _u=Depends(require_roles("admin","super_admin"))):
    base = "FROM users WHERE 1=1"
    params: list = []
    if role:    base += " AND role=%s";     params.append(role)
    if status:  base += " AND status=%s";   params.append(status)
    if keyword:
        base += " AND (name LIKE %s OR email LIKE %s OR student_no LIKE %s)"
        params.extend([f"%{keyword}%"]*3)
    sql = f"SELECT id,name,email,phone,student_no,employee_no,role,research_direction,enrollment_year,status,created_at {base} ORDER BY id DESC"
    rows, total = fetch_page(sql, tuple(params), page, page_size)
    return {"list": rows, "total": total, "page": page, "page_size": page_size}


@router.post("/users")
def create_user(req: CreateUserReq, _u=Depends(require_roles("admin","super_admin"))):
    if fetch_one("SELECT id FROM users WHERE email=%s", (req.email,)):
        raise HTTPException(400, "邮箱已存在")
    uid = execute_insert(
        """INSERT INTO users (name,email,phone,student_no,employee_no,password_hash,role,research_direction,enrollment_year)
           VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
        (req.name, req.email, req.phone, req.student_no, req.employee_no,
         hash_password(req.password), req.role, req.research_direction, req.enrollment_year))
    return {"id": uid, "message": "创建成功"}


@router.put("/users/{user_id}")
def update_user(user_id: int, req: UpdateUserReq, _u=Depends(require_roles("admin","super_admin"))):
    updates = {k: v for k, v in req.dict().items() if v is not None}
    if not updates: return {"message": "无变更"}
    sets = [f"{k}=%s" for k in updates]
    execute(f"UPDATE users SET {','.join(sets)} WHERE id=%s", tuple(updates.values()) + (user_id,))
    return {"message": "更新成功"}


@router.get("/roles")
def list_roles(_u=Depends(require_roles("admin","super_admin"))):
    return {"roles": fetch_all("SELECT * FROM roles ORDER BY id")}


@router.post("/users/{user_id}/roles")
def assign_role(user_id: int, req: AssignRoleReq, _u=Depends(require_roles("super_admin"))):
    role = fetch_one("SELECT id FROM roles WHERE code=%s", (req.role_code,))
    if not role: raise HTTPException(404, "角色不存在")
    execute_insert(
        """INSERT INTO user_roles (user_id,role_id,scope_type,scope_id) VALUES (%s,%s,%s,%s)
           ON DUPLICATE KEY UPDATE scope_type=VALUES(scope_type),scope_id=VALUES(scope_id)""",
        (user_id, role["id"], req.scope_type, req.scope_id))
    return {"message": "角色分配成功"}


@router.get("/audit-logs")
def audit_logs(page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100),
               user_id: int | None = None, action: str | None = None,
               _u=Depends(require_roles("admin","super_admin"))):
    base = "FROM audit_logs WHERE 1=1"
    params: list = []
    if user_id: base += " AND user_id=%s"; params.append(user_id)
    if action:  base += " AND action LIKE %s"; params.append(f"%{action}%")
    rows, total = fetch_page(f"SELECT * {base} ORDER BY created_at DESC", tuple(params), page, page_size)
    return {"list": rows, "total": total, "page": page, "page_size": page_size}
