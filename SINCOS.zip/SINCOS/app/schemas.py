"""Pydantic 请求/响应模型 — 集中定义所有数据结构"""

from pydantic import BaseModel, Field, EmailStr
from datetime import date, datetime
from typing import Optional


# ============================================================
# 认证
# ============================================================
class LoginReq(BaseModel):
    account:  str  # 邮箱/学号/工号
    password: str

class RegisterReq(BaseModel):
    name:         str
    email:        str
    password:     str
    role:         str           = "student"
    student_no:   Optional[str] = None
    employee_no:  Optional[str] = None
    phone:        Optional[str] = None

class TokenResp(BaseModel):
    token: str
    user:  dict


# ============================================================
# 用户管理
# ============================================================
class CreateUserReq(BaseModel):
    name:               str
    email:              str
    password:           str
    role:               str = "student"
    student_no:         Optional[str] = None
    employee_no:        Optional[str] = None
    phone:              Optional[str] = None
    research_direction: Optional[str] = None
    enrollment_year:    Optional[int] = None

class UpdateUserReq(BaseModel):
    name:               Optional[str]  = None
    email:              Optional[str]  = None
    phone:              Optional[str]  = None
    role:               Optional[str]  = None
    status:             Optional[str]  = None
    research_direction: Optional[str]  = None
    enrollment_year:    Optional[int]  = None

class AssignRoleReq(BaseModel):
    role_code:  str = Field(..., description="角色编码")
    scope_type: str = "global"
    scope_id:   Optional[int] = None


# ============================================================
# 到场记录
# ============================================================
class AttendanceItem(BaseModel):
    student_id:       int
    presence_status:  str            # present/absent/unknown
    remark:           Optional[str]  = None
    project_group_id: Optional[int]  = None

class BatchAttendanceReq(BaseModel):
    records:         list[AttendanceItem]
    attendance_date: Optional[date] = None

class UpdateAttendanceReq(BaseModel):
    presence_status: Optional[str] = None
    remark:          Optional[str] = None


# ============================================================
# 课表
# ============================================================
class UpdateScheduleItemReq(BaseModel):
    course_name:  Optional[str] = None
    class_name:   Optional[str] = None
    weeks_text:   Optional[str] = None
    teacher_name: Optional[str] = None
    location:     Optional[str] = None
    weekday:      Optional[int] = None
    section_no:   Optional[int] = None
    start_time:   Optional[str] = None
    end_time:     Optional[str] = None

class ConfirmScheduleReq(BaseModel):
    semester: str


# ============================================================
# 日报
# ============================================================
class CreateDailyReportReq(BaseModel):
    report_date:       Optional[date]  = None
    completed_work:    Optional[str]   = None
    problems:          Optional[str]   = None
    next_plan:         Optional[str]   = None
    work_hours:        Optional[float] = None
    tags:              Optional[list[str]] = None
    mentioned_users:   Optional[list[int]] = None
    project_group_id:  Optional[int]   = None

class UpdateDailyReportReq(BaseModel):
    completed_work:   Optional[str]  = None
    problems:         Optional[str]  = None
    next_plan:        Optional[str]  = None
    work_hours:       Optional[float] = None
    tags:             Optional[list[str]] = None
    mentioned_users:  Optional[list[int]] = None


# ============================================================
# 周报
# ============================================================
class CreateWeeklyReportReq(BaseModel):
    week_start:        date
    week_end:          date
    week_label:        Optional[str]  = None
    weekly_goal:       Optional[str]  = None
    completed_work:    Optional[str]  = None
    key_results:       Optional[str]  = None
    unfinished_work:   Optional[str]  = None
    reason_analysis:   Optional[str]  = None
    next_week_plan:    Optional[str]  = None
    help_needed:       Optional[str]  = None
    mentioned_users:   Optional[list[int]] = None
    self_score:        Optional[int]  = None
    project_group_id:  Optional[int]  = None

class UpdateWeeklyReportReq(BaseModel):
    weekly_goal:      Optional[str]  = None
    completed_work:   Optional[str]  = None
    key_results:      Optional[str]  = None
    unfinished_work:  Optional[str]  = None
    reason_analysis:  Optional[str]  = None
    next_week_plan:   Optional[str]  = None
    help_needed:      Optional[str]  = None
    mentioned_users:  Optional[list[int]] = None
    self_score:       Optional[int]  = None

class WeeklyDraftReq(BaseModel):
    week_start: date
    week_end:   date


# ============================================================
# 任务
# ============================================================
class CreateTaskReq(BaseModel):
    title:            str
    description:      Optional[str]  = None
    project_group_id: int
    assignee_id:      int
    collaborator_ids: Optional[list[int]] = None
    priority:         str = "medium"
    start_date:       Optional[date]     = None
    deadline:         Optional[datetime] = None
    milestone:        Optional[str]      = None

class UpdateTaskReq(BaseModel):
    title:       Optional[str]      = None
    description: Optional[str]      = None
    assignee_id: Optional[int]      = None
    priority:    Optional[str]      = None
    status:      Optional[str]      = None
    start_date:  Optional[date]     = None
    deadline:    Optional[datetime] = None
    milestone:   Optional[str]      = None


# ============================================================
# 日历
# ============================================================
class CreateEventReq(BaseModel):
    title:            str
    description:      Optional[str]      = None
    event_type:       str
    project_group_id: Optional[int]      = None
    student_id:       Optional[int]      = None
    related_type:     Optional[str]      = None
    related_id:       Optional[int]      = None
    start_at:         datetime
    end_at:           Optional[datetime] = None
    all_day:          bool = False
    priority:         str  = "medium"
    visibility:       str  = "lab"
    repeat_rule:      Optional[str]  = None
    color:            Optional[str]  = None

class UpdateEventReq(BaseModel):
    title:       Optional[str]      = None
    description: Optional[str]      = None
    start_at:    Optional[datetime] = None
    end_at:      Optional[datetime] = None
    all_day:     Optional[bool]     = None
    priority:    Optional[str]      = None
    visibility:  Optional[str]      = None
    color:       Optional[str]      = None


# ============================================================
# 项目组
# ============================================================
class CreateProjectReq(BaseModel):
    code:          str
    name:          str
    description:   Optional[str]  = None
    teacher_id:    Optional[int]  = None
    phd_owner_id:  Optional[int]  = None
    start_date:    Optional[date] = None
    end_date:      Optional[date] = None

class UpdateProjectReq(BaseModel):
    name:          Optional[str]  = None
    description:   Optional[str]  = None
    teacher_id:    Optional[int]  = None
    phd_owner_id:  Optional[int]  = None
    status:        Optional[str]  = None
    start_date:    Optional[date] = None
    end_date:      Optional[date] = None

class AddMemberReq(BaseModel):
    user_id:     int
    member_role: str = "student"


# ============================================================
# 评论
# ============================================================
class CreateCommentReq(BaseModel):
    content:     str
    action_type: str = "comment"  # comment/request_change/approve/mark_risk


# ============================================================
# AI
# ============================================================
class ChatReq(BaseModel):
    conversation_id: Optional[int] = None
    message:         str

class ProjectSummaryReq(BaseModel):
    project_group_id: int
