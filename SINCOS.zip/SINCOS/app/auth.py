"""认证与授权 — JWT + bcrypt + RBAC 权限"""

import bcrypt, jwt
from datetime import datetime, timedelta
from functools import wraps
from typing import Optional

from fastapi import HTTPException, Request, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

from app.config import JWT_SECRET, JWT_ALGORITHM, JWT_EXPIRE_HOURS
from app.database import fetch_one, fetch_all

security = HTTPBearer()


# ============================================================
# 密码
# ============================================================
def hash_password(pw: str) -> str:
    return bcrypt.hashpw(pw.encode(), bcrypt.gensalt()).decode()

def verify_password(pw: str, hashed: str) -> bool:
    return bcrypt.checkpw(pw.encode(), hashed.encode())


# ============================================================
# JWT
# ============================================================
def create_token(user_id: int, role: str) -> str:
    payload = {
        "user_id": user_id, "role": role,
        "exp": datetime.utcnow() + timedelta(hours=JWT_EXPIRE_HOURS),
        "iat": datetime.utcnow(),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

def decode_token(token: str) -> dict:
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
    except jwt.ExpiredSignatureError:
        raise HTTPException(401, "Token已过期")
    except jwt.InvalidTokenError:
        raise HTTPException(401, "Token无效")


# ============================================================
# 当前用户
# ============================================================
def get_current_user(cred: HTTPAuthorizationCredentials = Depends(security)) -> dict:
    payload = decode_token(cred.credentials)
    user = fetch_one(
        "SELECT id,name,email,role,status FROM users WHERE id=%s",
        (payload["user_id"],))
    if not user:        raise HTTPException(401, "用户不存在")
    if user["status"] != "active": raise HTTPException(403, "账号已禁用")
    return user


# ============================================================
# 角色守卫
# ============================================================
def require_roles(*roles: str):
    """依赖注入工厂: 校验当前用户角色"""
    def checker(u=Depends(get_current_user)):
        if u["role"] not in roles:
            raise HTTPException(403, "权限不足")
        return u
    return checker


# ============================================================
# 项目组数据权限
# ============================================================
def get_user_project_ids(user_id: int, role: str) -> list[int]:
    """用户在项目维度的可访问ID列表"""
    if role in ("teacher","super_admin","admin","research_assistant"):
        return [r["id"] for r in fetch_all("SELECT id FROM project_groups")]
    if role == "phd":
        return [r["id"] for r in fetch_all(
            "SELECT id FROM project_groups WHERE phd_owner_id=%s", (user_id,))]
    return [r["project_group_id"] for r in fetch_all(
        "SELECT project_group_id FROM project_members WHERE user_id=%s", (user_id,))]
