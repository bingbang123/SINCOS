import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { authAPI } from '../api'

export const useUserStore = defineStore('user', () => {
  const user = ref(null)
  const token = ref(localStorage.getItem('token') || '')
  const isLoggedIn = computed(() => !!token.value && !!user.value)
  const role = computed(() => user.value?.role || '')

  const roleLabels = {
    super_admin: '超级管理员', admin: '管理员', teacher: '导师',
    phd: '博士', student: '学生', research_assistant: '科研助理'
  }

  async function login(account, password) {
    const res = await authAPI.login({ account, password })
    token.value = res.token
    user.value = res.user
    localStorage.setItem('token', res.token)
    return res
  }

  async function register(data) {
    const res = await authAPI.register(data)
    token.value = res.token
    user.value = res.user
    localStorage.setItem('token', res.token)
    return res
  }

  async function restoreSession() {
    if (!token.value) return
    try {
      const res = await authAPI.me()
      user.value = res.user
    } catch { logout() }
  }

  function logout() {
    token.value = ''
    user.value = null
    localStorage.clear()
  }

  function hasRole(...roles) { return roles.includes(role.value) }

  return { user, token, isLoggedIn, role, roleLabels, login, register, restoreSession, logout, hasRole }
})
