import axios from 'axios'
import { ElMessage } from 'element-plus'

const api = axios.create({ baseURL: '/api', timeout: 15000 })

api.interceptors.request.use(config => {
  const token = localStorage.getItem('token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

api.interceptors.response.use(
  res => res.data,
  err => {
    const msg = err.response?.data?.detail || err.message || '请求失败'
    ElMessage.error(msg)
    if (err.response?.status === 401) {
      localStorage.clear()
      window.location.href = '/login'
    }
    return Promise.reject(err)
  }
)

export default api

// ---- 认证 ----
export const authAPI = {
  login:       data => api.post('/auth/login', data),
  register:    data => api.post('/auth/register', data),
  me:          ()    => api.get('/auth/me'),
}

// ---- 管理员 ----
export const adminAPI = {
  listUsers:   params => api.get('/admin/users', { params }),
  createUser:  data   => api.post('/admin/users', data),
  updateUser:  (id, data) => api.put(`/admin/users/${id}`, data),
  listRoles:   ()     => api.get('/admin/roles'),
  assignRole:  (uid, data) => api.post(`/admin/users/${uid}/roles`, data),
}

// ---- 到场记录 ----
export const attendanceAPI = {
  batchRecord: data => api.post('/attendance/daily-records', data),
  updateRecord:(id, data) => api.put(`/attendance/daily-records/${id}`, data),
  myRecords:   params => api.get('/attendance/me', { params }),
  list:        params => api.get('/attendance', { params }),
  statistics:  params => api.get('/attendance/statistics', { params }),
}

// ---- 课表 ----
export const scheduleAPI = {
  upload:      (form) => api.post('/schedules/upload', form, { headers: { 'Content-Type': 'multipart/form-data' } }),
  parse:       id     => api.post(`/schedules/${id}/parse`),
  mySchedule:  ()     => api.get('/schedules/me'),
  updateItem:  (sid, iid, data) => api.put(`/schedules/${sid}?item_id=${iid}`, data),
  confirm:     (id, data) => api.post(`/schedules/${id}/confirm`, data),
  listAll:     params => api.get('/schedules', { params }),
  freeBusy:    params => api.get('/schedules/free-busy', { params }),
  uploadStatus:params => api.get('/schedules/upload-status', { params }),
}

// ---- 日报 ----
export const dailyReportAPI = {
  create:   data => api.post('/daily-reports', data),
  update:   (id, data) => api.put(`/daily-reports/${id}`, data),
  submit:   id   => api.post(`/daily-reports/${id}/submit`),
  list:     params => api.get('/daily-reports', { params }),
  get:      id   => api.get(`/daily-reports/${id}`),
  comment:  (id, data) => api.post(`/daily-reports/${id}/comments`, data),
  versions: id   => api.get(`/daily-reports/${id}/versions`),
}

// ---- 周报 ----
export const weeklyReportAPI = {
  create:      data => api.post('/weekly-reports', data),
  update:      (id, data) => api.put(`/weekly-reports/${id}`, data),
  submit:      id   => api.post(`/weekly-reports/${id}/submit`),
  generateDraft: data => api.post('/weekly-reports/generate-draft', data),
  list:        params => api.get('/weekly-reports', { params }),
  get:         id   => api.get(`/weekly-reports/${id}`),
  comment:     (id, data) => api.post(`/weekly-reports/${id}/comments`, data),
}

// ---- 任务 ----
export const taskAPI = {
  create:   data => api.post('/tasks', data),
  update:   (id, data) => api.put(`/tasks/${id}`, data),
  list:     params => api.get('/tasks', { params }),
  kanban:   params => api.get('/tasks/kanban', { params }),
  get:      id   => api.get(`/tasks/${id}`),
  comment:  (id, data) => api.post(`/tasks/${id}/comments`, data),
  complete: id   => api.post(`/tasks/${id}/complete`),
}

// ---- 日历 ----
export const calendarAPI = {
  listEvents: params => api.get('/calendar/events', { params }),
  overview:   ()     => api.get('/calendar/overview'),
  createEvent:data   => api.post('/calendar/events', data),
  updateEvent:(id, data) => api.put(`/calendar/events/${id}`, data),
  deleteEvent:id     => api.delete(`/calendar/events/${id}`),
  syncDeadlines: ()  => api.post('/calendar/sync-task-deadlines'),
}

// ---- 项目组 ----
export const projectAPI = {
  list:       ()     => api.get('/project-groups'),
  create:     data   => api.post('/project-groups', data),
  update:     (id, data) => api.put(`/project-groups/${id}`, data),
  get:        id     => api.get(`/project-groups/${id}`),
  summary:    id     => api.get(`/project-groups/${id}/summary`),
  addMember:  (id, data) => api.post(`/project-groups/${id}/members`, data),
  removeMember:(gid, uid) => api.delete(`/project-groups/${gid}/members/${uid}`),
}

// ---- AI ----
export const aiAPI = {
  chat:           data => api.post('/ai/chat', data),
  conversations:  ()   => api.get('/ai/conversations'),
  getConv:        id   => api.get(`/ai/conversations/${id}`),
  weeklyDraft:    data => api.post('/ai/weekly-draft', data),
  projectSummary: data => api.post('/ai/project-summary', data),
}
