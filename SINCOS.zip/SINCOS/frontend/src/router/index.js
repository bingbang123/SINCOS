import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  { path: '/login', name: 'Login', component: () => import('../views/Login.vue'), meta: { guest: true } },

  {
    path: '/', component: () => import('../views/Layout.vue'),
    children: [
      // ---- 通用 ----
      { path: '', name: 'Dashboard', component: () => import('../views/Dashboard.vue') },

      // ---- 学生 ----
      { path: 'my-daily',  name: 'MyDaily',  component: () => import('../views/student/DailyReport.vue') },
      { path: 'my-weekly', name: 'MyWeekly', component: () => import('../views/student/WeeklyReport.vue') },
      { path: 'my-schedule', name: 'MySchedule', component: () => import('../views/student/MySchedule.vue') },
      { path: 'my-attendance', name: 'MyAttendance', component: () => import('../views/student/MyAttendance.vue') },
      { path: 'my-tasks', name: 'MyTasks', component: () => import('../views/student/MyTasks.vue') },

      // ---- 博士/导师 ----
      { path: 'reports',  name: 'Reports',  component: () => import('../views/shared/ReportList.vue') },
      { path: 'tasks',    name: 'Tasks',    component: () => import('../views/shared/TaskKanban.vue') },
      { path: 'schedules', name: 'Schedules', component: () => import('../views/shared/ScheduleView.vue') },

      // ---- 科研助理/管理员 ----
      { path: 'attendance', name: 'Attendance', component: () => import('../views/admin/AttendanceManage.vue') },

      // ---- 导师 ----
      { path: 'calendar', name: 'Calendar', component: () => import('../views/teacher/CalendarCenter.vue') },

      // ---- 管理员 ----
      { path: 'users',   name: 'Users',   component: () => import('../views/admin/UserManage.vue') },
      { path: 'projects',name: 'Projects',component: () => import('../views/admin/ProjectManage.vue') },

      // ---- AI ----
      { path: 'ai-chat', name: 'AIChat', component: () => import('../views/shared/AIChat.vue') },
    ],
  },
]

const router = createRouter({ history: createWebHistory(), routes })

router.beforeEach((to, _from, next) => {
  const token = localStorage.getItem('token')
  if (to.meta.guest) return next()
  if (!token) return next('/login')
  next()
})

export default router
