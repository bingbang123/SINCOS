<template>
  <div>
    <h3>📅 日历中心</h3>
    <el-row :gutter="16">
      <el-col :span="16">
        <el-card header="" shadow="hover">
          <template #header>
            <span>日历事件</span>
            <el-button type="primary" size="small" @click="createVisible=true" style="float:right">+ 新建</el-button>
            <el-button size="small" @click="syncDeadlines" style="float:right;margin-right:8px">同步 deadlines</el-button>
          </template>
          <el-timeline>
            <el-timeline-item v-for="e in events" :key="e.id" :timestamp="e.start_at?.slice(0,16)" placement="top">
              <el-card>
                <h4>{{ e.title }}
                  <el-tag :type="priorityType(e.priority)" size="small" style="margin-left:8px">{{ e.priority }}</el-tag>
                  <el-tag size="small" style="margin-left:4px">{{ e.event_type }}</el-tag>
                </h4>
                <p v-if="e.description">{{ e.description }}</p>
                <el-button size="small" type="danger" @click="deleteEvent(e.id)">删除</el-button>
              </el-card>
            </el-timeline-item>
          </el-timeline>
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card header="📊 本周概览" shadow="hover">
          <div v-if="overview">
            <el-statistic title="本周事件" :value="overview.total_events" />
            <el-statistic title="Deadlines" :value="overview.deadline_count" />
            <el-statistic title="会议" :value="overview.meeting_count" />
            <p style="margin-top:8px"><el-tag type="danger">{{ overview.urgent?.length || 0 }} 紧急</el-tag> <el-tag type="warning">{{ overview.high?.length || 0 }} 高优</el-tag></p>
          </div>
        </el-card>
      </el-col>
    </el-row>
    <el-dialog v-model="createVisible" title="新建日历事件" width="500px">
      <el-form :model="newEvent" label-width="80px">
        <el-form-item label="标题"><el-input v-model="newEvent.title" /></el-form-item>
        <el-form-item label="描述"><el-input v-model="newEvent.description" type="textarea" /></el-form-item>
        <el-form-item label="类型"><el-select v-model="newEvent.event_type"><el-option v-for="t in ['task_deadline','meeting','personal','paper','milestone','report_due','ai_suggestion']" :key="t" :label="t" :value="t" /></el-select></el-form-item>
        <el-form-item label="开始"><el-date-picker v-model="newEvent.start_at" type="datetime" value-format="YYYY-MM-DD HH:mm:ss" /></el-form-item>
        <el-form-item label="结束"><el-date-picker v-model="newEvent.end_at" type="datetime" value-format="YYYY-MM-DD HH:mm:ss" /></el-form-item>
        <el-form-item label="优先级"><el-select v-model="newEvent.priority"><el-option v-for="p in ['low','medium','high','urgent']" :key="p" :label="p" :value="p" /></el-select></el-form-item>
        <el-form-item label="颜色"><el-color-picker v-model="newEvent.color" /></el-form-item>
      </el-form>
      <template #footer><el-button type="primary" @click="doCreate">创建</el-button></template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { calendarAPI } from '../../api'

const events = ref([])
const overview = ref(null)
const createVisible = ref(false)
const newEvent = reactive({ title:'', description:'', event_type:'meeting', start_at:'', end_at:'', priority:'medium', color:'#409eff' })
const priorityType = p => ({ urgent:'danger', high:'warning', medium:'info', low:'' }[p] || '')

async function load() {
  try { const r = await calendarAPI.listEvents({}); events.value = r.events }
  catch {}
  try { overview.value = (await calendarAPI.overview()).overview }
  catch {}
}

async function doCreate() {
  try { await calendarAPI.createEvent(newEvent); createVisible.value = false; load() }
  catch {}
}

async function deleteEvent(id) {
  try { await calendarAPI.deleteEvent(id); load() }
  catch {}
}

async function syncDeadlines() {
  try { const r = await calendarAPI.syncDeadlines(); ElMessage.success(r.message); load() }
  catch {}
}

onMounted(load)
</script>
