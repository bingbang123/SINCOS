<template>
  <el-container style="height:100vh">
    <el-aside width="220px" style="background:#1d1e2c; color:#fff; overflow-y:auto">
      <div style="padding:20px 16px; font-size:18px; font-weight:bold; text-align:center; border-bottom:1px solid #333">
        🏛️ 实验室管理
      </div>
      <el-menu :default-active="route.path" router :collapse="false"
               background-color="#1d1e2c" text-color="#a6a7b3" active-text-color="#fff"
               style="border-right:none">
        <el-menu-item index="/"><el-icon><HomeFilled /></el-icon> 首页</el-menu-item>

        <!-- 学生 -->
        <template v-if="userStore.hasRole('student')">
          <el-menu-item index="/my-daily"><el-icon><Edit /></el-icon> 我的日报</el-menu-item>
          <el-menu-item index="/my-weekly"><el-icon><Document /></el-icon> 我的周报</el-menu-item>
          <el-menu-item index="/my-schedule"><el-icon><Calendar /></el-icon> 我的课表</el-menu-item>
          <el-menu-item index="/my-attendance"><el-icon><Check /></el-icon> 到场记录</el-menu-item>
          <el-menu-item index="/my-tasks"><el-icon><List /></el-icon> 我的任务</el-menu-item>
        </template>

        <!-- 博士 -->
        <template v-if="userStore.hasRole('phd')">
          <el-menu-item index="/reports"><el-icon><DataAnalysis /></el-icon> 学生报告</el-menu-item>
          <el-menu-item index="/tasks"><el-icon><Grid /></el-icon> 任务看板</el-menu-item>
          <el-menu-item index="/schedules"><el-icon><Calendar /></el-icon> 学生课表</el-menu-item>
        </template>

        <!-- 导师 -->
        <template v-if="userStore.hasRole('teacher')">
          <el-menu-item index="/reports"><el-icon><DataAnalysis /></el-icon> 全实验室报告</el-menu-item>
          <el-menu-item index="/tasks"><el-icon><Grid /></el-icon> 任务看板</el-menu-item>
          <el-menu-item index="/schedules"><el-icon><Calendar /></el-icon> 学生课表</el-menu-item>
          <el-menu-item index="/calendar"><el-icon><Clock /></el-icon> 日历中心</el-menu-item>
        </template>

        <!-- 科研助理 -->
        <template v-if="userStore.hasRole('research_assistant')">
          <el-menu-item index="/attendance"><el-icon><Check /></el-icon> 到场记录</el-menu-item>
          <el-menu-item index="/schedules"><el-icon><Calendar /></el-icon> 课表上传情况</el-menu-item>
        </template>

        <!-- 管理员 -->
        <template v-if="userStore.hasRole('admin','super_admin')">
          <el-menu-item index="/users"><el-icon><User /></el-icon> 用户管理</el-menu-item>
          <el-menu-item index="/projects"><el-icon><Folder /></el-icon> 项目组管理</el-menu-item>
          <el-menu-item index="/attendance"><el-icon><Check /></el-icon> 到场管理</el-menu-item>
          <el-menu-item index="/reports"><el-icon><DataAnalysis /></el-icon> 全局报告</el-menu-item>
        </template>

        <el-menu-item index="/ai-chat"><el-icon><ChatDotRound /></el-icon> AI 助手</el-menu-item>
      </el-menu>
    </el-aside>

    <el-container>
      <el-header style="height:56px; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #eee; padding:0 20px">
        <span style="font-size:16px; font-weight:500">{{ pageTitle }}</span>
        <el-dropdown @command="handleCommand">
          <span style="cursor:pointer">
            {{ userStore.user?.name || '' }} ({{ userStore.roleLabels[userStore.role] || userStore.role }})
            <el-icon><ArrowDown /></el-icon>
          </span>
          <template #dropdown>
            <el-dropdown-menu>
              <el-dropdown-item command="logout">退出登录</el-dropdown-item>
            </el-dropdown-menu>
          </template>
        </el-dropdown>
      </el-header>
      <el-main style="background:#f5f7fa; overflow-y:auto">
        <router-view />
      </el-main>
    </el-container>
  </el-container>
</template>

<script setup>
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useUserStore } from '../stores/user'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const pageTitle = computed(() => route.meta?.title || route.name || '首页')

function handleCommand(cmd) {
  if (cmd === 'logout') { userStore.logout(); router.push('/login') }
}
</script>
