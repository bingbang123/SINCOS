<template>
  <div>
    <h3>📁 项目组管理</h3>
    <el-row :gutter="16">
      <el-col :span="8" v-for="p in projects" :key="p.id">
        <el-card shadow="hover" style="margin-bottom:16px">
          <template #header>
            <span><b>{{ p.name }}</b></span>
            <el-tag size="small" style="float:right">{{ p.status }}</el-tag>
          </template>
          <p><b>导师:</b> {{ p.teacher_name || '-' }}</p>
          <p><b>博士负责人:</b> {{ p.phd_owner_name || '-' }}</p>
          <p><b>成员数:</b> {{ p.members?.length || 0 }}</p>
          <el-button size="small" @click="viewProject(p)">详情</el-button>
        </el-card>
      </el-col>
    </el-row>
    <el-dialog v-model="detailVisible" :title="currentProject?.name" width="600px">
      <div v-if="currentProject">
        <p>{{ currentProject.description || '无描述' }}</p>
        <h4>成员</h4>
        <el-table :data="currentProject.members" stripe>
          <el-table-column prop="name" label="姓名" />
          <el-table-column prop="role" label="角色" />
          <el-table-column prop="member_role" label="项目组角色" />
        </el-table>
        <h4>汇总</h4>
        <el-row :gutter="16">
          <el-col :span="8"><el-statistic title="成员总数" :value="summary.report_stats?.total_members||0" /></el-col>
          <el-col :span="8"><el-statistic title="任务完成" :value="summary.task_stats?.done||0" /></el-col>
          <el-col :span="8"><el-statistic title="逾期任务" :value="summary.task_stats?.overdue||0" /></el-col>
        </el-row>
        <el-button type="primary" size="small" style="margin-top:12px" @click="addMemberVisible=true">+ 添加成员</el-button>
        <el-dialog v-model="addMemberVisible" title="添加成员" width="300px" append-to-body>
          <el-form><el-form-item label="用户ID"><el-input-number v-model="newMember.user_id" :min="1" /></el-form-item>
            <el-form-item label="角色"><el-select v-model="newMember.member_role"><el-option v-for="r in ['student','phd','teacher']" :key="r" :label="r" :value="r" /></el-select></el-form-item></el-form>
          <template #footer><el-button type="primary" @click="doAddMember">添加</el-button></template>
        </el-dialog>
      </div>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { projectAPI } from '../../api'

const projects = ref([])
const detailVisible = ref(false)
const currentProject = ref(null)
const summary = ref({})
const addMemberVisible = ref(false)
const newMember = reactive({ user_id: null, member_role: 'student' })

async function load() {
  try { const r = await projectAPI.list(); projects.value = r.list }
  catch {}
}

async function viewProject(p) {
  try {
    const r = await projectAPI.get(p.id); currentProject.value = r.project; detailVisible.value = true
    const s = await projectAPI.summary(p.id); summary.value = s
  } catch {}
}

async function doAddMember() {
  try {
    await projectAPI.addMember(currentProject.value.id, newMember)
    addMemberVisible.value = false; viewProject(currentProject.value)
  } catch {}
}

onMounted(load)
</script>
