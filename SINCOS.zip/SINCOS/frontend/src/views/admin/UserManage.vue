<template>
  <div>
    <h3>👥 用户管理</h3>
    <el-row :gutter="16" style="margin-bottom:16px">
      <el-col :span="4"><el-input v-model="filters.keyword" placeholder="搜索" @change="load" /></el-col>
      <el-col :span="3"><el-select v-model="filters.role" placeholder="角色" clearable @change="load">
        <el-option v-for="r in roles" :key="r" :label="r" :value="r" /></el-select></el-col>
      <el-col :span="3"><el-select v-model="filters.status" placeholder="状态" clearable @change="load">
        <el-option v-for="s in ['active','graduated','suspended','left']" :key="s" :label="s" :value="s" /></el-select></el-col>
      <el-col :span="4"><el-button type="primary" @click="createVisible=true">+ 新建用户</el-button></el-col>
    </el-row>
    <el-table :data="list" stripe>
      <el-table-column prop="name" label="姓名" width="100" />
      <el-table-column prop="email" label="邮箱" width="180" />
      <el-table-column prop="student_no" label="学号" width="100" />
      <el-table-column prop="role" label="角色" width="120"><template #default="{row}"><el-tag>{{ row.role }}</el-tag></template></el-table-column>
      <el-table-column prop="status" label="状态" width="80" />
      <el-table-column prop="enrollment_year" label="年份" width="60" />
      <el-table-column prop="research_direction" label="研究方向" show-overflow-tooltip />
      <el-table-column label="操作" width="100">
        <template #default="{row}"><el-button size="small" @click="editUser(row)">编辑</el-button></template>
      </el-table-column>
    </el-table>
    <el-pagination v-if="total>pageSize" layout="prev,next" :total="total" :page-size="pageSize" v-model:current-page="page" @current-change="load" style="margin-top:12px" />

    <el-dialog v-model="createVisible" title="新建用户" width="450px">
      <el-form :model="newUser" label-width="80px">
        <el-form-item label="姓名"><el-input v-model="newUser.name" /></el-form-item>
        <el-form-item label="邮箱"><el-input v-model="newUser.email" /></el-form-item>
        <el-form-item label="密码"><el-input v-model="newUser.password" type="password" /></el-form-item>
        <el-form-item label="角色"><el-select v-model="newUser.role"><el-option v-for="r in roles" :key="r" :label="r" :value="r" /></el-select></el-form-item>
        <el-form-item label="学号"><el-input v-model="newUser.student_no" /></el-form-item>
        <el-form-item label="手机号"><el-input v-model="newUser.phone" /></el-form-item>
      </el-form>
      <template #footer><el-button type="primary" @click="doCreate">创建</el-button></template>
    </el-dialog>

    <el-dialog v-model="editVisible" title="编辑用户" width="450px">
      <el-form :model="editForm" label-width="80px">
        <el-form-item label="姓名"><el-input v-model="editForm.name" /></el-form-item>
        <el-form-item label="角色"><el-select v-model="editForm.role"><el-option v-for="r in roles" :key="r" :label="r" :value="r" /></el-select></el-form-item>
        <el-form-item label="状态"><el-select v-model="editForm.status"><el-option v-for="s in ['active','graduated','suspended','left']" :key="s" :label="s" :value="s" /></el-select></el-form-item>
      </el-form>
      <template #footer><el-button type="primary" @click="doEdit">保存</el-button></template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { adminAPI } from '../../api'

const roles = ['student','phd','teacher','research_assistant','admin','super_admin']
const list = ref([])
const total = ref(0)
const page = ref(1)
const pageSize = ref(20)
const filters = reactive({ keyword: '', role: '', status: '' })
const createVisible = ref(false)
const editVisible = ref(false)
const newUser = reactive({ name:'',email:'',password:'',role:'student',student_no:'',phone:'' })
const editForm = reactive({ id:null,name:'',role:'',status:'' })

async function load() {
  try {
    const r = await adminAPI.listUsers({ page: page.value, page_size: pageSize.value, role: filters.role||undefined, status: filters.status||undefined, keyword: filters.keyword||undefined })
    list.value = r.list; total.value = r.total
  } catch {}
}

async function doCreate() {
  try { await adminAPI.createUser(newUser); createVisible.value = false; load() }
  catch {}
}

function editUser(u) {
  editForm.id = u.id; editForm.name = u.name; editForm.role = u.role; editForm.status = u.status
  editVisible.value = true
}

async function doEdit() {
  try { await adminAPI.updateUser(editForm.id, editForm); editVisible.value = false; load() }
  catch {}
}

onMounted(load)
</script>
