<template>
  <div>
    <h3>📋 到场记录管理</h3>
    <el-card shadow="hover">
      <template #header><span>今日到场记录 ({{ today }})</span></template>
      <el-table :data="students" stripe @selection-change="handleSelect">
        <el-table-column type="selection" width="55" />
        <el-table-column prop="name" label="姓名" width="120" />
        <el-table-column prop="student_no" label="学号" width="120" />
        <el-table-column label="到场状态" width="180">
          <template #default="{row}">
            <el-radio-group v-model="row.presence_status" size="small">
              <el-radio-button value="present">已到</el-radio-button>
              <el-radio-button value="absent">未到</el-radio-button>
              <el-radio-button value="unknown">未知</el-radio-button>
            </el-radio-group>
          </template>
        </el-table-column>
        <el-table-column label="备注" min-width="200">
          <template #default="{row}"><el-input v-model="row.remark" placeholder="请假/出差/线上参会..." size="small" /></template>
        </el-table-column>
      </el-table>
      <el-button type="primary" @click="batchRecord" style="margin-top:12px">💾 批量保存</el-button>
    </el-card>
    <el-card header="📊 今日统计" shadow="hover" style="margin-top:16px">
      <el-row :gutter="16">
        <el-col :span="6"><el-statistic title="已到" :value="stats.present||0" /></el-col>
        <el-col :span="6"><el-statistic title="未到" :value="stats.absent||0" /></el-col>
        <el-col :span="6"><el-statistic title="未知" :value="stats.unknown||0" /></el-col>
        <el-col :span="6"><el-statistic title="已到未提交日报" :value="stats.present_no_report_count||0" /></el-col>
      </el-row>
      <div v-if="stats.present_no_report?.length" style="margin-top:12px">
        <h4>⚠️ 已到但未提交日报:</h4>
        <el-tag v-for="s in stats.present_no_report" :key="s.id" style="margin:2px">{{ s.name }}</el-tag>
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { attendanceAPI, adminAPI } from '../../api'
import dayjs from 'dayjs'

const today = dayjs().format('YYYY-MM-DD')
const students = ref([])
const stats = ref({})
const selected = ref([])

function handleSelect(rows) { selected.value = rows }

async function loadStudents() {
  try {
    const r = await adminAPI.listUsers({ role: 'student', status: 'active', page_size: 200 })
    students.value = (r.list || []).map(s => ({ ...s, presence_status: 'unknown', remark: '' }))
  } catch {}
}

async function batchRecord() {
  const records = students.value.map(s => ({
    student_id: s.id, presence_status: s.presence_status, remark: s.remark || null,
  }))
  try {
    await attendanceAPI.batchRecord({ records, attendance_date: today })
    ElMessage.success(`已保存 ${records.length} 条记录`)
    loadStats()
  } catch {}
}

async function loadStats() {
  try { stats.value = await attendanceAPI.statistics({}) }
  catch {}
}

onMounted(async () => { await loadStudents(); loadStats() })
</script>
