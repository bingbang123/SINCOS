<template>
  <div>
    <h3>📋 任务看板</h3>
    <el-button type="primary" @click="createVisible=true" style="margin-bottom:16px">+ 新建任务</el-button>
    <div style="display:flex; gap:12px; overflow-x:auto">
      <div v-for="col in columns" :key="col.key" style="min-width:260px; background:#f5f7fa; border-radius:8px; padding:12px">
        <h4 style="margin-top:0">{{ col.label }} <el-tag size="small">{{ col.items.length }}</el-tag></h4>
        <div v-for="t in col.items" :key="t.id">
          <el-card shadow="hover" style="margin-bottom:8px; cursor:pointer" @click="viewTask(t)">
            <template #header>
              <span style="font-size:14px">{{ t.title }}</span>
              <el-tag :type="priorityType(t.priority)" size="small" style="float:right">{{ t.priority }}</el-tag>
            </template>
            <p style="font-size:12px; color:#909399">{{ t.assignee_name }} | 📅 {{ t.deadline?.slice(0,10) || '-' }}</p>
          </el-card>
        </div>
      </div>
    </div>
    <el-dialog v-model="createVisible" title="新建任务" width="500px">
      <el-form :model="newTask" label-width="80px">
        <el-form-item label="标题"><el-input v-model="newTask.title" /></el-form-item>
        <el-form-item label="描述"><el-input v-model="newTask.description" type="textarea" /></el-form-item>
        <el-form-item label="项目组"><el-select v-model="newTask.project_group_id" placeholder="选择项目组"><el-option v-for="p in projects" :key="p.id" :label="p.name" :value="p.id" /></el-select></el-form-item>
        <el-form-item label="负责人"><el-input-number v-model="newTask.assignee_id" :min="1" placeholder="用户ID" /></el-form-item>
        <el-form-item label="优先级"><el-select v-model="newTask.priority"><el-option v-for="p in ['low','medium','high','urgent']" :key="p" :label="p" :value="p" /></el-select></el-form-item>
        <el-form-item label="截止日期"><el-date-picker v-model="newTask.deadline" type="datetime" value-format="YYYY-MM-DD HH:mm:ss" /></el-form-item>
      </el-form>
      <template #footer><el-button @click="createTask" type="primary">创建</el-button></template>
    </el-dialog>
    <el-dialog v-model="taskVisible" title="任务详情" width="500px">
      <div v-if="currentTask">
        <p><b>标题:</b> {{ currentTask.title }}</p>
        <p><b>状态:</b> <el-select v-model="currentTask.status" @change="updateStatus"><el-option v-for="s in ['todo','doing','blocked','review','done','overdue']" :key="s" :label="s" :value="s" /></el-select></p>
        <p><b>负责人:</b> {{ currentTask.assignee_name }}</p>
        <p><b>截止:</b> {{ currentTask.deadline?.slice(0,10) }}</p>
        <el-button type="success" size="small" @click="completeTask(currentTask.id)">标记完成</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { taskAPI, projectAPI } from '../../api'

const columns = ref([
  { key:'todo', label:'未开始', items:[] }, { key:'doing', label:'进行中', items:[] },
  { key:'blocked', label:'已阻塞', items:[] }, { key:'review', label:'待确认', items:[] },
  { key:'done', label:'已完成', items:[] }, { key:'overdue', label:'已延期', items:[] },
])
const projects = ref([])
const createVisible = ref(false)
const taskVisible = ref(false)
const currentTask = ref(null)
const newTask = reactive({ title:'', description:'', project_group_id:null, assignee_id:null, priority:'medium', deadline:null })
const priorityType = p => ({ urgent:'danger', high:'warning', medium:'info', low:'' }[p] || '')

async function load() {
  try {
    const r = await taskAPI.kanban()
    columns.value.forEach(c => { c.items = r.columns[c.key] || [] })
  } catch {}
  try { const r = await projectAPI.list(); projects.value = r.list }
  catch {}
}

async function createTask() {
  try { await taskAPI.create(newTask); createVisible.value = false; load() }
  catch {}
}

function viewTask(t) { currentTask.value = t; taskVisible.value = true }

async function updateStatus() {
  await taskAPI.update(currentTask.value.id, { status: currentTask.value.status })
  load()
}

async function completeTask(id) {
  await taskAPI.complete(id); taskVisible.value = false; load()
}

onMounted(load)
</script>
