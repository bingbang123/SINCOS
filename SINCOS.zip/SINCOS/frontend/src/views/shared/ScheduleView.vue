<template>
  <div>
    <h3>📅 学生课表</h3>
    <el-form :inline="true">
      <el-form-item><el-input v-model="filters.student_id" placeholder="学生ID" @change="load" /></el-form-item>
      <el-form-item><el-select v-model="filters.weekday" placeholder="星期" clearable @change="load">
        <el-option v-for="(v,k) in weekMap" :key="k" :label="v" :value="k" />
      </el-select></el-form-item>
      <el-form-item><el-select v-model="filters.project_group_id" placeholder="项目组" clearable @change="load">
        <el-option v-for="p in projects" :key="p.id" :label="p.name" :value="p.id" />
      </el-select></el-form-item>
    </el-form>
    <el-table :data="list" stripe>
      <el-table-column prop="student_name" label="学生" width="100" />
      <el-table-column prop="weekday" label="星期" width="80"><template #default="{row}">{{ weekLabel(row.weekday) }}</template></el-table-column>
      <el-table-column prop="section_label" label="节次" width="80" />
      <el-table-column prop="start_time" label="开始" width="80" />
      <el-table-column prop="end_time" label="结束" width="80" />
      <el-table-column prop="course_name" label="课程" />
      <el-table-column prop="teacher_name" label="教师" width="120" />
      <el-table-column prop="location" label="地点" width="180" />
    </el-table>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { scheduleAPI, projectAPI } from '../../api'

const list = ref([])
const projects = ref([])
const filters = ref({ student_id: null, weekday: null, project_group_id: null })
const weekMap = { 1:'周一',2:'周二',3:'周三',4:'周四',5:'周五',6:'周六',7:'周日' }
const weekLabel = w => weekMap[w] || ''

async function load() {
  try {
    const r = await scheduleAPI.listAll({
      student_id: filters.value.student_id || undefined,
      weekday: filters.value.weekday || undefined,
      project_group_id: filters.value.project_group_id || undefined,
    })
    list.value = r.list
  } catch {}
}

onMounted(async () => {
  try { const r = await projectAPI.list(); projects.value = r.list }
  catch {}
  load()
})
</script>
