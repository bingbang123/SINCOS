<template>
  <div style="display:flex;height:calc(100vh - 140px)">
    <div style="width:250px;border-right:1px solid #eee;padding:12px">
      <h4>💬 对话历史</h4>
      <el-button type="primary" size="small" @click="newChat" style="width:100%;margin-bottom:12px">+ 新对话</el-button>
      <div v-for="c in conversations" :key="c.id" @click="selectConv(c.id)" style="padding:8px;cursor:pointer;border-radius:4px" :style="{background: convId===c.id?'#e8f4ff':''}">{{ c.title || '新对话' }}</div>
    </div>
    <div style="flex:1;display:flex;flex-direction:column;padding:12px">
      <div style="flex:1;overflow-y:auto;margin-bottom:12px">
        <div v-for="(m,i) in messages" :key="i" style="margin-bottom:12px">
          <div v-if="m.role==='user'" style="text-align:right"><el-tag type="primary" effect="plain" style="max-width:70%;text-align:left;white-space:pre-wrap">{{ m.content }}</el-tag></div>
          <div v-else style="background:#f5f7fa;padding:12px;border-radius:8px;white-space:pre-wrap">{{ m.content }}</div>
        </div>
        <div v-if="loading">🤔 思考中...</div>
      </div>
      <div style="display:flex;gap:8px">
        <el-input v-model="input" placeholder="输入问题, 如: 张三最近两周在做什么？" @keyup.enter="send" />
        <el-button type="primary" @click="send" :loading="loading">发送</el-button>
      </div>
      <div style="margin-top:8px">
        <el-tag v-for="q in quickQuestions" :key="q" @click="input=q;send()" style="cursor:pointer;margin:2px">{{ q }}</el-tag>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { aiAPI } from '../../api'

const convId = ref(null)
const conversations = ref([])
const messages = ref([])
const input = ref('')
const loading = ref(false)
const quickQuestions = ['今天哪些学生未提交日报？', '本周有无延期风险？', '具身智能组进展如何？']

async function loadConvs() {
  try { const r = await aiAPI.conversations(); conversations.value = r.conversations }
  catch {}
}

async function selectConv(id) {
  convId.value = id
  try {
    const r = await aiAPI.getConv(id)
    messages.value = r.conversation.messages || []
  } catch {}
}

function newChat() { convId.value = null; messages.value = [] }

async function send() {
  if (!input.value.trim()) return
  loading.value = true
  try {
    const r = await aiAPI.chat({ conversation_id: convId.value, message: input.value })
    convId.value = r.conversation_id
    messages.value.push({ role: 'user', content: input.value })
    messages.value.push({ role: 'assistant', content: r.answer })
    input.value = ''
    loadConvs()
  } finally { loading.value = false }
}

onMounted(loadConvs)
</script>
