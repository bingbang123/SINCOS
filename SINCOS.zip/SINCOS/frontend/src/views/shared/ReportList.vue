<template>
  <div>
    <h3>📊 学生报告</h3>
    <el-tabs v-model="reportType" @tabChange="load">
      <el-tab-pane label="日报" name="daily" />
      <el-tab-pane label="周报" name="weekly" />
    </el-tabs>
    <el-form :inline="true">
      <el-form-item><el-input v-model="filters.keyword" placeholder="关键词搜索" clearable @change="load" /></el-form-item>
      <el-form-item><el-select v-model="filters.status" placeholder="状态" clearable @change="load">
        <template v-if="reportType==='daily'">
          <el-option label="草稿" value="draft" /><el-option label="已提交" value="submitted" />
          <el-option label="已查看" value="viewed" /><el-option label="需跟进" value="need_followup" />
        </template>
        <template v-else>
          <el-option label="草稿" value="draft" /><el-option label="已提交" value="submitted" />
          <el-option label="已批准" value="approved" /><el-option label="有风险" value="risk" />
        </template>
      </el-select></el-form-item>
    </el-form>
    <el-table :data="list" stripe @row-click="viewDetail" style="cursor:pointer">
      <el-table-column prop="student_name" label="学生" width="100" />
      <el-table-column :prop="reportType==='daily'?'report_date':'week_start'" :label="reportType==='daily'?'日期':'周开始'" width="120" />
      <el-table-column :prop="reportType==='daily'?'completed_work':'completed_work'" label="内容摘要" show-overflow-tooltip />
      <el-table-column prop="status" label="状态" width="100"><template #default="{row}"><el-tag :type="statusType(row.status)">{{ row.status }}</el-tag></template></el-table-column>
    </el-table>
    <el-pagination v-if="total > pageSize" layout="prev,next" :total="total" :page-size="pageSize" v-model:current-page="page" @current-change="load" style="margin-top:12px" />
    <el-dialog v-model="detailVisible" :title="`${reportType==='daily'?'日报':'周报'}详情`" width="700px">
      <div v-if="detail" style="max-height:500px;overflow-y:auto">
        <p><b>学生:</b> {{ detail.student_name }}</p>
        <p><b>日期:</b> {{ detail.report_date || detail.week_start }}</p>
        <div v-if="reportType==='daily'">
          <h4>今日完成</h4><div v-html="detail.completed_work || '-'" style="white-space:pre-wrap" />
          <h4>遇到问题</h4><div v-html="detail.problems || '-'" style="white-space:pre-wrap" />
          <h4>明日计划</h4><div v-html="detail.next_plan || '-'" style="white-space:pre-wrap" />
        </div>
        <div v-else>
          <h4>本周完成</h4><div v-html="detail.completed_work || '-'" style="white-space:pre-wrap" />
          <h4>关键成果</h4><div v-html="detail.key_results || '-'" style="white-space:pre-wrap" />
          <h4>下周计划</h4><div v-html="detail.next_week_plan || '-'" style="white-space:pre-wrap" />
          <h4>需要帮助</h4><div v-html="detail.help_needed || '-'" style="white-space:pre-wrap" />
        </div>
        <h4>反馈 ({{ detail.comments?.length || 0 }})</h4>
        <div v-for="c in detail.comments" :key="c.id" style="background:#f5f7fa;padding:8px;margin-bottom:4px;border-radius:4px">
          <b>{{ c.author_name }}</b>: {{ c.content }}
        </div>
        <el-input v-model="commentText" type="textarea" :rows="2" placeholder="添加评论..." style="margin-top:12px" />
        <el-button type="primary" size="small" @click="addComment" style="margin-top:8px">提交评论</el-button>
        <el-button type="warning" size="small" @click="markRisk" style="margin-top:8px">标记风险</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { dailyReportAPI, weeklyReportAPI } from '../../api'

const reportType = ref('daily')
const list = ref([])
const total = ref(0)
const page = ref(1)
const pageSize = ref(20)
const filters = reactive({ keyword: '', status: '' })
const detailVisible = ref(false)
const detail = ref(null)
const commentText = ref('')

function statusType(s) { return { approved:'success',need_followup:'danger',risk:'danger',draft:'warning' }[s] || '' }

async function load() {
  const api = reportType.value === 'daily' ? dailyReportAPI : weeklyReportAPI
  try {
    const r = await api.list({ page: page.value, page_size: pageSize.value, keyword: filters.keyword || undefined, status: filters.status || undefined })
    list.value = r.list; total.value = r.total
  } catch {}
}

async function viewDetail(row) {
  const api = reportType.value === 'daily' ? dailyReportAPI : weeklyReportAPI
  try {
    const r = await api.get(row.id); detail.value = r.report || r.report; detailVisible.value = true
  } catch {}
}

async function addComment() {
  if (!commentText.value) return
  const api = reportType.value === 'daily' ? dailyReportAPI : weeklyReportAPI
  const targetId = detail.value.id
  try {
    await api.comment(targetId, { content: commentText.value, action_type: 'comment' })
    ElMessage.success('评论已提交'); commentText.value = ''
    await viewDetail({ id: targetId })
  } catch {}
}

async function markRisk() {
  const api = reportType.value === 'daily' ? dailyReportAPI : weeklyReportAPI
  await api.comment(detail.value.id, { content: '标记为风险', action_type: 'mark_risk' })
  ElMessage.success('已标记')
}

onMounted(load)
</script>
