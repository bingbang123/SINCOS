<template>
  <div>
    <h3>📄 我的周报</h3>
    <el-tabs>
      <el-tab-pane label="新建周报">
        <el-card shadow="hover">
          <template #header>
            <span>新建周报</span>
            <el-button type="primary" size="small" @click="generateDraft" style="float:right;margin-left:8px">📋 从日报生成</el-button>
            <el-button type="success" size="small" @click="save" style="float:right" :loading="saving">提交</el-button>
          </template>
          <el-form label-width="80px">
            <el-form-item label="周范围">
              <el-date-picker v-model="weekRange" type="daterange" range-separator="~" start-placeholder="周一" end-placeholder="周日" value-format="YYYY-MM-DD" />
            </el-form-item>
            <el-form-item label="本周目标"><el-input v-model="form.weekly_goal" type="textarea" :rows="2" /></el-form-item>
            <el-form-item label="本周完成"><el-input v-model="form.completed_work" type="textarea" :rows="4" /></el-form-item>
            <el-form-item label="关键成果"><el-input v-model="form.key_results" type="textarea" :rows="2" /></el-form-item>
            <el-form-item label="未完成事项"><el-input v-model="form.unfinished_work" type="textarea" :rows="2" /></el-form-item>
            <el-form-item label="原因分析"><el-input v-model="form.reason_analysis" type="textarea" :rows="2" /></el-form-item>
            <el-form-item label="下周计划"><el-input v-model="form.next_week_plan" type="textarea" :rows="2" /></el-form-item>
            <el-form-item label="需要帮助"><el-input v-model="form.help_needed" type="textarea" :rows="2" /></el-form-item>
            <el-form-item label="自评分"><el-rate v-model="form.self_score" :max="10" show-score /></el-form-item>
          </el-form>
        </el-card>
      </el-tab-pane>
      <el-tab-pane label="历史周报">
        <el-table :data="history" stripe>
          <el-table-column prop="week_start" label="周开始" width="120" />
          <el-table-column prop="week_end" label="周结束" width="120" />
          <el-table-column prop="self_score" label="自评" width="60" />
          <el-table-column prop="status" label="状态" width="100"><template #default="{row}"><el-tag :type="row.status==='approved'?'success':row.status==='risk'?'danger':''">{{ row.status }}</el-tag></template></el-table-column>
          <el-table-column prop="key_results" label="关键成果" show-overflow-tooltip />
        </el-table>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { weeklyReportAPI } from '../../api'
import { ElMessage } from 'element-plus'

const weekRange = ref([])
const form = reactive({ weekly_goal:'', completed_work:'', key_results:'', unfinished_work:'', reason_analysis:'', next_week_plan:'', help_needed:'', self_score:null, project_group_id:null })
const saving = ref(false)
const history = ref([])

async function save() {
  saving.value = true
  try {
    await weeklyReportAPI.create({ ...form, week_start: weekRange.value[0], week_end: weekRange.value[1] })
    ElMessage.success('周报已提交')
    loadHistory()
  } finally { saving.value = false }
}

async function generateDraft() {
  if (!weekRange.value?.length) { ElMessage.warning('请先选择周范围'); return }
  try {
    const r = await weeklyReportAPI.generateDraft({ week_start: weekRange.value[0], week_end: weekRange.value[1] })
    Object.assign(form, r)
    ElMessage.success(`已从 ${r.daily_report_count} 篇日报生成草稿`)
  } catch {}
}

async function loadHistory() {
  try { const r = await weeklyReportAPI.list({ page_size: 50 }); history.value = r.list }
  catch {}
}

onMounted(loadHistory)
</script>
