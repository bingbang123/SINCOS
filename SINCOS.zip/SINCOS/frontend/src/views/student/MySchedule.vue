<template>
  <div>
    <h3>📅 我的课表</h3>
    <el-upload :http-request="uploadFile" accept=".doc,.docx" :show-file-list="false">
      <el-button type="primary">上传 Word 课表 (.doc/.docx)</el-button>
    </el-upload>
    <el-table :data="items" stripe style="margin-top:16px">
      <el-table-column prop="weekday" label="星期" width="80"><template #default="{row}">{{ weekLabel(row.weekday) }}</template></el-table-column>
      <el-table-column prop="section_label" label="节次" width="80" />
      <el-table-column prop="start_time" label="开始" width="80" />
      <el-table-column prop="end_time" label="结束" width="80" />
      <el-table-column prop="course_name" label="课程" />
      <el-table-column prop="teacher_name" label="教师" width="120" />
      <el-table-column prop="location" label="地点" width="180" />
      <el-table-column prop="weeks_text" label="周次" width="100" />
    </el-table>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { scheduleAPI } from '../../api'

const items = ref([])
const weekLabel = w => ['','周一','周二','周三','周四','周五','周六','周日'][w] || ''

async function uploadFile({ file }) {
  const fd = new FormData(); fd.append('file', file)
  try {
    await scheduleAPI.upload(fd)
    ElMessage.success('上传成功, 请联系管理员解析')
    load()
  } catch {}
}

async function load() {
  try { const r = await scheduleAPI.mySchedule(); items.value = r.list }
  catch {}
}

onMounted(load)
</script>
