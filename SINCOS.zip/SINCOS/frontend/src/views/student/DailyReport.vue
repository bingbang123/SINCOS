<template>
  <div>
    <h3>📝 我的日报</h3>
    <el-row :gutter="16">
      <el-col :span="14">
        <el-card shadow="hover">
          <template #header>
            <span>新建日报 ({{ today }})</span>
            <el-button type="primary" size="small" @click="save" style="float:right" :loading="saving">保存草稿</el-button>
            <el-button type="success" size="small" @click="submit" style="float:right;margin-right:8px" :disabled="!draftId">提交</el-button>
          </template>
          <el-form label-width="80px">
            <el-form-item label="今日完成"><el-input v-model="form.completed_work" type="textarea" :rows="4" placeholder="今天做了哪些科研工作？" /></el-form-item>
            <el-form-item label="遇到问题"><el-input v-model="form.problems" type="textarea" :rows="2" placeholder="实验/代码/论文遇到了什么阻塞？" /></el-form-item>
            <el-form-item label="明日计划"><el-input v-model="form.next_plan" type="textarea" :rows="2" placeholder="明天的计划安排" /></el-form-item>
            <el-form-item label="工作时长"><el-input-number v-model="form.work_hours" :min="0" :max="16" :step="0.5" /> 小时</el-form-item>
            <el-form-item label="标签"><el-input v-model="tagInput" placeholder="输入标签后回车" @keyup.enter="addTag"><template #append><el-button @click="addTag">+</el-button></template></el-input></el-form-item>
            <el-form-item><el-tag v-for="(t,i) in form.tags" :key="i" closable @close="form.tags.splice(i,1)" style="margin-right:4px">{{ t }}</el-tag></el-form-item>
          </el-form>
        </el-card>
      </el-col>
      <el-col :span="10">
        <el-card header="📋 历史日报" shadow="hover">
          <div v-for="d in history" :key="d.id" style="padding:8px 0; border-bottom:1px solid #f0f0f0; cursor:pointer" @click="viewDetail(d)">
            <el-tag size="small" :type="statusType(d.status)">{{ statusLabel(d.status) }}</el-tag>
            <span style="margin-left:8px;color:#606266">{{ d.report_date }}</span>
          </div>
          <el-pagination v-if="total > pageSize" layout="prev,next" :total="total" :page-size="pageSize" v-model:current-page="page" small style="margin-top:12px" />
        </el-card>
      </el-col>
    </el-row>
    <el-dialog v-model="detailVisible" title="日报详情" width="600px">
      <div v-if="detail">
        <p><b>日期:</b> {{ detail.report_date }}</p>
        <p><b>今日完成:</b> {{ detail.completed_work || '-' }}</p>
        <p><b>遇到问题:</b> {{ detail.problems || '-' }}</p>
        <p><b>明日计划:</b> {{ detail.next_plan || '-' }}</p>
        <p><b>状态:</b> <el-tag :type="statusType(detail.status)">{{ statusLabel(detail.status) }}</el-tag></p>
        <div v-if="detail.comments?.length">
          <h4>反馈</h4>
          <div v-for="c in detail.comments" :key="c.id" style="background:#f5f7fa;padding:8px;margin-bottom:4px;border-radius:4px">
            <b>{{ c.author_name }}</b> ({{ c.action_type }}): {{ c.content }}
          </div>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue'
import { dailyReportAPI } from '../../api'
import dayjs from 'dayjs'

const today = dayjs().format('YYYY-MM-DD')
const form = reactive({ completed_work: '', problems: '', next_plan: '', work_hours: null, tags: [], project_group_id: null })
const tagInput = ref('')
const draftId = ref(null)
const saving = ref(false)
const history = ref([])
const total = ref(0)
const page = ref(1)
const pageSize = ref(10)
const detailVisible = ref(false)
const detail = ref(null)

function addTag() {
  if (tagInput.value && !form.tags.includes(tagInput.value)) { form.tags.push(tagInput.value); tagInput.value = '' }
}
function statusType(s) { return { submitted:'', viewed:'info', feedback:'success', need_followup:'danger', draft:'warning' }[s] || '' }
function statusLabel(s) { return { draft:'草稿', submitted:'已提交', viewed:'已查看', feedback:'已反馈', need_followup:'需跟进' }[s] || s }

async function save() {
  saving.value = true
  try {
    if (draftId.value) {
      await dailyReportAPI.update(draftId.value, form)
    } else {
      const r = await dailyReportAPI.create(form)
      draftId.value = r.id
    }
    ElMessage.success('已保存')
  } finally { saving.value = false }
}

async function submit() {
  await save()
  await dailyReportAPI.submit(draftId.value)
  draftId.value = null
  ElMessage.success('日报已提交')
  loadHistory()
}

async function loadHistory() {
  try {
    const r = await dailyReportAPI.list({ page: page.value, page_size: pageSize.value })
    history.value = r.list; total.value = r.total
  } catch {}
}

async function viewDetail(d) {
  try {
    const r = await dailyReportAPI.get(d.id)
    detail.value = r.report; detailVisible.value = true
  } catch {}
}

onMounted(loadHistory)
</script>
