<template>
  <div>
    <h3>📋 我的任务</h3>
    <div v-for="col in ['todo','doing','blocked','review','done','overdue']" :key="col" style="margin-bottom:24px">
      <h4>{{ {todo:'未开始',doing:'进行中',blocked:'已阻塞',review:'待确认',done:'已完成',overdue:'已延期'}[col] }}</h4>
      <el-row :gutter="16">
        <el-col :span="8" v-for="t in byStatus[col]" :key="t.id">
          <el-card shadow="hover" style="margin-bottom:8px">
            <template #header>
              <span>{{ t.title }}</span>
              <el-tag :type="priorityType(t.priority)" size="small" style="float:right">{{ t.priority }}</el-tag>
            </template>
            <p style="color:#909399; font-size:13px">{{ t.description || '无描述' }}</p>
            <p style="font-size:12px">📅 {{ t.deadline?.slice(0,10) || '无截止日期' }}</p>
            <el-button v-if="col==='doing'" type="success" size="small" @click="complete(t.id)">完成</el-button>
          </el-card>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { taskAPI } from '../../api'

const tasks = ref([])
const priorityType = p => ({ urgent:'danger', high:'warning', medium:'info', low:'' }[p] || '')

const byStatus = computed(() => {
  const m = { todo:[], doing:[], blocked:[], review:[], done:[], overdue:[] }
  tasks.value.forEach(t => { if (m[t.status]) m[t.status].push(t) })
  return m
})

async function complete(id) {
  await taskAPI.complete(id)
  load()
}

async function load() {
  try { const r = await taskAPI.kanban(); tasks.value = Object.values(r.columns).flat() }
  catch {}
}

onMounted(load)
</script>
