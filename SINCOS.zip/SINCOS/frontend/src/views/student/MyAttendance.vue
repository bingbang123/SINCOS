<template>
  <div>
    <h3>✅ 我的到场记录</h3>
    <el-date-picker v-model="month" type="month" placeholder="选择月份" @change="load" value-format="YYYY-MM" style="margin-bottom:16px" />
    <el-table :data="records" stripe>
      <el-table-column prop="attendance_date" label="日期" width="120" />
      <el-table-column prop="presence_status" label="状态" width="100">
        <template #default="{row}">
          <el-tag :type="row.presence_status==='present'?'success':row.presence_status==='absent'?'danger':'info'">
            {{ {present:'已到',absent:'未到',unknown:'未知'}[row.presence_status] }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="remark" label="备注" show-overflow-tooltip />
      <el-table-column prop="recorded_at" label="记录时间" width="160" />
    </el-table>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { attendanceAPI } from '../../api'
import dayjs from 'dayjs'

const records = ref([])
const month = ref(dayjs().format('YYYY-MM'))

async function load() {
  try { const r = await attendanceAPI.myRecords({ month: month.value }); records.value = r.list }
  catch {}
}

onMounted(load)
</script>
