<template>
  <div class="login-wrap">
    <el-card class="login-card">
      <h2>🏛️ 实验室管理系统</h2>
      <el-form :model="form" label-width="0" @submit.prevent="handleLogin">
        <el-form-item><el-input v-model="form.account" placeholder="邮箱 / 学号 / 工号" size="large" /></el-form-item>
        <el-form-item><el-input v-model="form.password" type="password" placeholder="密码" size="large" show-password /></el-form-item>
        <el-form-item><el-button type="primary" size="large" :loading="loading" @click="handleLogin" style="width:100%">登 录</el-button></el-form-item>
      </el-form>
      <p class="tip">初始超管: admin@lab.edu.cn / admin123</p>
    </el-card>
  </div>
</template>

<script setup>
import { reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '../stores/user'

const router = useRouter()
const userStore = useUserStore()
const form = reactive({ account: '', password: '' })
const loading = ref(false)

async function handleLogin() {
  if (!form.account || !form.password) return
  loading.value = true
  try { await userStore.login(form.account, form.password); router.push('/') }
  catch {} finally { loading.value = false }
}
</script>

<style scoped>
.login-wrap { display:flex; justify-content:center; align-items:center; height:100vh; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
.login-card { width: 420px; text-align: center; }
.login-card h2 { margin-bottom: 24px; color: #303133; }
.tip { color: #909399; font-size: 13px; margin-top: 8px; }
</style>
