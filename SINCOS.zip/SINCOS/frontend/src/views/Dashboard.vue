<template>
  <div>
    <h3>📊 工作台</h3>
    <el-row :gutter="16">
      <el-col :span="6" v-for="card in cards" :key="card.label">
        <el-card shadow="hover" style="margin-bottom:16px; text-align:center">
          <div style="font-size:28px; color:#409eff; font-weight:bold">{{ card.value }}</div>
          <div style="color:#909399; margin-top:8px">{{ card.label }}</div>
        </el-card>
      </el-col>
    </el-row>
    <el-row :gutter="16">
      <el-col :span="12">
        <el-card header="📝 最近日报" shadow="hover">
          <el-empty v-if="!dailies.length" description="暂无日报" />
          <div v-for="d in dailies" :key="d.id" style="padding:8px 0; border-bottom:1px solid #f0f0f0">
            <el-tag size="small">{{ d.student_name }}</el-tag>
            <span style="margin-left:8px; color:#606266">{{ d.report_date }}</span>
            <el-tag size="small" :type="statusType(d.status)" style="float:right">{{ d.status }}</el-tag>
          </div>
        </el-card>
      </el-col>
      <el-col :span="12">
        <el-card header="⏰ 即将到期任务" shadow="hover">
          <el-empty v-if="!tasks.length" description="暂无到期任务" />
          <div v-for="t in tasks" :key="t.id" style="padding:8px 0; border-bottom:1px solid #f0f0f0">
            <el-tag :type="priorityType(t.priority)" size="small">{{ t.priority }}</el-tag>
            <span style="margin-left:8px">{{ t.title }}</span>
            <span style="float:right; color:#909399">{{ t.deadline?.slice(0,10) }}</span>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useUserStore } from '../stores/user'
import { dailyReportAPI, taskAPI } from '../api'

const userStore = useUserStore()
const dailies = ref([])
const tasks = ref([])
const cards = ref([])

function statusType(s) { return { submitted:'', viewed:'info', feedback:'success', need_followup:'danger', draft:'warning' }[s] || '' }
function priorityType(p) { return { urgent:'danger', high:'warning', medium:'info', low:'' }[p] || '' }

onMounted(async () => {
  try { const r = await dailyReportAPI.list({ page_size: 5 }); dailies.value = r.list }
  catch {}
  try { const r = await taskAPI.list({ page_size: 5, overdue_only: true }); tasks.value = r.list }
  catch {}
  cards.value = [
    { label: '在线身份', value: userStore.roleLabels[userStore.role] || userStore.role },
    { label: '今日日报', value: dailies.value.length },
    { label: '到期任务', value: tasks.value.length },
    { label: '系统版本', value: '2.0.0' },
  ]
})
</script>
