<template>
  <router-view />
</template>

<script setup>
import { useUserStore } from './stores/user'
import { onMounted } from 'vue'

const userStore = useUserStore()
onMounted(() => userStore.restoreSession())
</script>

<style>
body { margin: 0; font-family: "Helvetica Neue", Helvetica, "PingFang SC", "Microsoft YaHei", sans-serif; }
#app { height: 100vh; }
</style>
