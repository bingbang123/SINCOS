"""
高校实验室研究生管理系统 — FastAPI 入口
启动: uvicorn main:app --host 0.0.0.0 --port 8000 --reload
文档: http://localhost:8000/docs
"""

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from app.api.auth import router as auth_router
from app.api.admin import router as admin_router
from app.api.attendance import router as attendance_router
from app.api.schedule import router as schedule_router
from app.api.daily_report import router as daily_report_router
from app.api.weekly_report import router as weekly_report_router
from app.api.task import router as task_router
from app.api.calendar import router as calendar_router
from app.api.project import router as project_router
from app.api.ai import router as ai_router

app = FastAPI(
    title="高校实验室研究生管理系统",
    description="""
## 研究生实验室科研管理平台

基于设计方案 **MVP 第一阶段** 的完整后端 API。

| 模块 | 前缀 | 说明 |
|------|------|------|
| 认证 | `/api/auth` | 登录/注册/Token |
| 管理员 | `/api/admin` | 用户/角色/审计 |
| 到场记录 | `/api/attendance` | 批量记录/统计 |
| 课表 | `/api/schedules` | Word上传/解析/查看 |
| 日报 | `/api/daily-reports` | CRUD/评论/版本 |
| 周报 | `/api/weekly-reports` | CRUD/草稿/导出 |
| 任务 | `/api/tasks` | 看板/CRUD/deadline |
| 日历 | `/api/calendar` | 事件/同步/总览 |
| 项目组 | `/api/project-groups` | 总览/成员/汇总 |
| AI助手 | `/api/ai` | 对话/总结/草稿 |
    """,
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 注册路由
app.include_router(auth_router)
app.include_router(admin_router)
app.include_router(attendance_router)
app.include_router(schedule_router)
app.include_router(daily_report_router)
app.include_router(weekly_report_router)
app.include_router(task_router)
app.include_router(calendar_router)
app.include_router(project_router)
app.include_router(ai_router)


@app.get("/")
def root():
    return {"name": "高校实验室研究生管理系统", "version": "2.0.0",
            "docs": "/docs", "api_prefix": "/api"}


@app.exception_handler(Exception)
async def global_exc(_req: Request, exc: Exception):
    return JSONResponse(status_code=500, content={"detail": str(exc)})
