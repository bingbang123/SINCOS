"""任务服务"""

from app.database import fetch_one, fetch_all, fetch_page, execute_insert, execute
from app.auth import get_user_project_ids


def create_task(creator_id: int, **kwargs) -> int:
    collab = kwargs.pop("collaborator_ids", None)
    tid = execute_insert(
        """INSERT INTO tasks (title,description,project_group_id,assignee_id,creator_id,priority,status,start_date,deadline,milestone)
           VALUES (%s,%s,%s,%s,%s,%s,'todo',%s,%s,%s)""",
        (kwargs["title"], kwargs.get("description"), kwargs["project_group_id"],
         kwargs["assignee_id"], creator_id, kwargs.get("priority","medium"),
         kwargs.get("start_date"), kwargs.get("deadline"), kwargs.get("milestone")))
    if collab:
        for uid in collab:
            execute_insert("INSERT INTO task_collaborators (task_id,user_id) VALUES (%s,%s)", (tid, uid))
    return tid


def update_task(task_id: int, **kwargs) -> bool:
    if kwargs.get("status") == "done":
        kwargs["completed_at"] = "NOW()"  # handled specially
    sets = []
    params = []
    for k, v in kwargs.items():
        if v is None: continue
        if k == "completed_at":
            sets.append("completed_at=NOW()")
        else:
            sets.append(f"{k}=%s")
            params.append(v)
    if sets:
        params.append(task_id)
        execute(f"UPDATE tasks SET {','.join(sets)} WHERE id=%s", tuple(params))
    return True


def list_tasks(user: dict, page: int, page_size: int, **filters) -> tuple[list[dict], int]:
    base = """SELECT t.*, u.name AS assignee_name, c.name AS creator_name
              FROM tasks t JOIN users u ON t.assignee_id=u.id JOIN users c ON t.creator_id=c.id WHERE 1=1"""
    params: list = []
    if user["role"] == "student":
        base += " AND t.assignee_id=%s"; params.append(user["id"])
    elif user["role"] == "phd":
        ids = get_user_project_ids(user["id"], "phd")
        if not ids: return [], 0
        base += f" AND t.project_group_id IN ({','.join(['%s']*len(ids))})"; params.extend(ids)
    for k, v in filters.items():
        if v is None: continue
        if k == "overdue_only":
            if v:
                base += " AND t.deadline<NOW() AND t.status NOT IN ('done','overdue')"
        else:
            base += f" AND t.{k}=%s"; params.append(v)
    sql = base + " ORDER BY FIELD(t.priority,'urgent','high','medium','low'), t.deadline ASC"
    return fetch_page(sql, tuple(params), page, page_size)


def kanban(user: dict, project_group_id: int | None) -> dict:
    fsql = "WHERE 1=1"
    params: list = []
    if user["role"] == "student":
        fsql += " AND t.assignee_id=%s"; params.append(user["id"])
    elif user["role"] == "phd":
        ids = get_user_project_ids(user["id"], "phd")
        if not ids: return {"columns": {}}
        fsql += f" AND t.project_group_id IN ({','.join(['%s']*len(ids))})"; params.extend(ids)
    if project_group_id: fsql += " AND t.project_group_id=%s"; params.append(project_group_id)

    columns = {}
    for s in ["todo","doing","blocked","review","done","overdue"]:
        columns[s] = fetch_all(
            f"""SELECT t.*, u.name AS assignee_name FROM tasks t JOIN users u ON t.assignee_id=u.id
                {fsql} AND t.status=%s ORDER BY FIELD(t.priority,'urgent','high','medium','low')""",
            tuple(params + [s]))
    return {"columns": columns}


def get_task(task_id: int) -> dict | None:
    t = fetch_one(
        """SELECT t.*, u.name AS assignee_name, c.name AS creator_name
           FROM tasks t JOIN users u ON t.assignee_id=u.id JOIN users c ON t.creator_id=c.id WHERE t.id=%s""",
        (task_id,))
    if t:
        t["collaborators"] = fetch_all(
            "SELECT u.id,u.name FROM task_collaborators tc JOIN users u ON tc.user_id=u.id WHERE tc.task_id=%s", (task_id,))
        t["comments"] = fetch_all(
            """SELECT c.*, u.name AS author_name FROM comments c JOIN users u ON c.author_id=u.id
               WHERE c.target_type='task' AND c.target_id=%s ORDER BY c.created_at""", (task_id,))
    return t
