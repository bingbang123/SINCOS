"""应用配置"""

import os

# ---- 数据库 ----
DB_CONFIG = {
    "host":     os.getenv("DB_HOST",     "localhost"),
    "port":     int(os.getenv("DB_PORT", "3306")),
    "user":     os.getenv("DB_USER",     "root"),
    "password": os.getenv("DB_PASSWORD", "s.030501"),
    "database": os.getenv("DB_NAME",     "lab_management"),
    "charset":  "utf8mb4",
    "autocommit": False,
}

# ---- JWT ----
JWT_SECRET       = os.getenv("JWT_SECRET", "lab-secret-change-in-production")
JWT_ALGORITHM    = "HS256"
JWT_EXPIRE_HOURS = 24

# ---- 文件上传 ----
UPLOAD_DIR            = os.getenv("UPLOAD_DIR", "./uploads")
MAX_UPLOAD_SIZE_MB    = 50
ALLOWED_SCHEDULE_EXTS = {".doc", ".docx"}

# ---- 大模型 (DeepSeek / OpenAI 兼容) ----
LLM_PROVIDER    = os.getenv("LLM_PROVIDER",    "deepseek")
LLM_BASE_URL    = os.getenv("LLM_BASE_URL",    "https://api.deepseek.com")
LLM_API_KEY     = os.getenv("LLM_API_KEY",     "sk-d47c581bcbbb479b9e917e655d5b54d4")
LLM_MODEL       = os.getenv("LLM_MODEL",       "deepseek-chat")
LLM_TEMPERATURE = float(os.getenv("LLM_TEMPERATURE", "0.2"))
LLM_MAX_TOKENS  = int(os.getenv("LLM_MAX_TOKENS", "4096"))

# ---- 提醒规则 ----
REMINDER_DEADLINE_DAYS = [3, 1]     # 到期前 N 天提醒
REMINDER_OVERDUE_DAILY = True       # 逾期每日提醒
REMINDER_WEEKLY_DAY    = 5          # 周五提醒周报

# ---- 业务常量 ----
PROJECT_GROUP_CODES = ["data", "multimodal_fusion", "embodied_ai", "space_network"]
ROLES               = ["student","phd","teacher","research_assistant","admin","super_admin"]
TASK_STATUSES       = ["todo","doing","blocked","review","done","overdue"]
TASK_PRIORITIES     = ["low","medium","high","urgent"]
REPORT_STATUS_DAILY  = ["draft","submitted","viewed","feedback","need_followup"]
REPORT_STATUS_WEEKLY = ["draft","submitted","viewed","approved","need_revision","risk"]
PRESENCE_STATUSES    = ["present","absent","unknown"]
