-- ============================================================
-- 高校实验室研究生管理系统 - 测试样本数据
-- 执行方式: mysql -u root -p < sample_data.sql
-- 注意: 执行前请确保已运行 schema.sql 和 seed.sql
-- ============================================================

USE `lab_management`;

-- 所有测试用户密码均为 password123 (bcrypt hash)
-- hash = $2b$12$LJ3m4ys3Lk0TSwHCpNqr3eOoZ9GM7t1VyQr8qXcB5hYsR5xP8hS2e

-- ============================================================
-- 1. 用户表 (users)
-- 已有 seed.sql: id=1 系统管理员 super_admin
-- 新增 17 名用户，涵盖所有角色
-- ============================================================
INSERT INTO `users` (`id`, `name`, `email`, `phone`, `student_no`, `employee_no`, `password_hash`, `role`, `research_direction`, `enrollment_year`, `status`) VALUES
-- 导师 (2人)
(2,  '张明远', 'zhangmy@lab.edu.cn',  '13800001001', NULL, 'T2020001', '$2b$12$LJ3m4ys3Lk0TSwHCpNqr3eOoZ9GM7t1VyQr8qXcB5hYsR5xP8hS2e', 'teacher',  '多模态融合与计算机视觉',  NULL, 'active'),
(3,  '李教授', 'lijs@lab.edu.cn',    '13800001002', NULL, 'T2021002', '$2b$12$LJ3m4ys3Lk0TSwHCpNqr3eOoZ9GM7t1VyQr8qXcB5hYsR5xP8hS2e', 'teacher',  '天基网络与空间通信',      NULL, 'active'),

-- 博士负责人 (2人)
(4,  '王博文', 'wangbw@lab.edu.cn',  '13800002001', 'B20230001', NULL, '$2b$12$LJ3m4ys3Lk0TSwHCpNqr3eOoZ9GM7t1VyQr8qXcB5hYsR5xP8hS2e', 'phd',     '多模态数据融合算法',      2023, 'active'),
(5,  '赵思远', 'zhaosy@lab.edu.cn',  '13800002002', 'B20230002', NULL, '$2b$12$LJ3m4ys3Lk0TSwHCpNqr3eOoZ9GM7t1VyQr8qXcB5hYsR5xP8hS2e', 'phd',     '机器人运动规划',          2023, 'active'),

-- 科研助理 (1人)
(6,  '陈助理', 'chenzl@lab.edu.cn',  '13800003001', NULL, 'A2024001', '$2b$12$LJ3m4ys3Lk0TSwHCpNqr3eOoZ9GM7t1VyQr8qXcB5hYsR5xP8hS2e', 'research_assistant', NULL, NULL, 'active'),

-- 硕士研究生 (11人)
(7,  '刘子轩', 'liuzx@lab.edu.cn',   '13900010001', 'S20240101', NULL, '$2b$12$LJ3m4ys3Lk0TSwHCpNqr3eOoZ9GM7t1VyQr8qXcB5hYsR5xP8hS2e', 'student', '计算机视觉-目标检测',     2024, 'active'),
(8,  '孙雨桐', 'sunyt@lab.edu.cn',   '13900010002', 'S20240102', NULL, '$2b$12$LJ3m4ys3Lk0TSwHCpNqr3eOoZ9GM7t1VyQr8qXcB5hYsR5xP8hS2e', 'student', '多模态大模型微调',        2024, 'active'),
(9,  '周一帆', 'zhouyf@lab.edu.cn',  '13900010003', 'S20240103', NULL, '$2b$12$LJ3m4ys3Lk0TSwHCpNqr3eOoZ9GM7t1VyQr8qXcB5hYsR5xP8hS2e', 'student', '联邦学习与隐私计算',      2024, 'active'),
(10, '吴思琪', 'wusq@lab.edu.cn',   '13900010004', 'S20240104', NULL, '$2b$12$LJ3m4ys3Lk0TSwHCpNqr3eOoZ9GM7t1VyQr8qXcB5hYsR5xP8hS2e', 'student', '自然语言处理',            2024, 'active'),
(11, '郑浩然', 'zhenghr@lab.edu.cn', '13900010005', 'S20240105', NULL, '$2b$12$LJ3m4ys3Lk0TSwHCpNqr3eOoZ9GM7t1VyQr8qXcB5hYsR5xP8hS2e', 'student', 'SLAM与三维重建',          2024, 'active'),
(12, '林小雨', 'linxy@lab.edu.cn',   '13900010006', 'S20240106', NULL, '$2b$12$LJ3m4ys3Lk0TSwHCpNqr3eOoZ9GM7t1VyQr8qXcB5hYsR5xP8hS2e', 'student', '知识图谱与推理',          2024, 'active'),
(13, '黄志强', 'huangzq@lab.edu.cn', '13900020001', 'S20230101', NULL, '$2b$12$LJ3m4ys3Lk0TSwHCpNqr3eOoZ9GM7t1VyQr8qXcB5hYsR5xP8hS2e', 'student', '卫星通信与组网',          2023, 'active'),
(14, '杨雪琳', 'yangxl@lab.edu.cn',  '13900020002', 'S20230102', NULL, '$2b$12$LJ3m4ys3Lk0TSwHCpNqr3eOoZ9GM7t1VyQr8qXcB5hYsR5xP8hS2e', 'student', '空间网络拓扑优化',        2023, 'active'),
(15, '马晓东', 'maxd@lab.edu.cn',   '13900020003', 'S20230103', NULL, '$2b$12$LJ3m4ys3Lk0TSwHCpNqr3eOoZ9GM7t1VyQr8qXcB5hYsR5xP8hS2e', 'student', '强化学习与机器人控制',    2023, 'active'),
(16, '何佳慧', 'hejh@lab.edu.cn',   '13900020004', 'S20230104', NULL, '$2b$12$LJ3m4ys3Lk0TSwHCpNqr3eOoZ9GM7t1VyQr8qXcB5hYsR5xP8hS2e', 'student', '数据标注与质量评估',      2023, 'active'),
(17, '朱伟杰', 'zhuwj@lab.edu.cn',  '13900020005', 'S20230105', NULL, '$2b$12$LJ3m4ys3Lk0TSwHCpNqr3eOoZ9GM7t1VyQr8qXcB5hYsR5xP8hS2e', 'student', '图神经网络',             2023, 'graduated');


-- ============================================================
-- 2. 用户角色关联表 (user_roles)
-- 已有 seed.sql: user_id=1 -> super_admin
-- ============================================================
INSERT INTO `user_roles` (`user_id`, `role_id`, `scope_type`, `scope_id`) VALUES
(2,  6, 'global', NULL),   -- 张明远 -> teacher
(3,  6, 'global', NULL),   -- 李教授 -> teacher
(4,  7, 'project_group', 2), -- 王博文 -> phd (多模态融合组)
(5,  7, 'project_group', 3), -- 赵思远 -> phd (具身智能组)
(6,  9, 'global', NULL),   -- 陈助理 -> research_assistant
(7,  8, 'project_group', 2), -- 刘子轩 -> student (多模态融合组)
(8,  8, 'project_group', 2), -- 孙雨桐 -> student (多模态融合组)
(9,  8, 'project_group', 1), -- 周一帆 -> student (数据组)
(10, 8, 'project_group', 1), -- 吴思琪 -> student (数据组)
(11, 8, 'project_group', 4), -- 郑浩然 -> student (天基网络组)
(12, 8, 'project_group', 4), -- 林小雨 -> student (天基网络组)
(13, 8, 'project_group', 3), -- 黄志强 -> student (具身智能组)
(14, 8, 'project_group', 3), -- 杨雪琳 -> student (具身智能组)
(15, 8, 'project_group', 3), -- 马晓东 -> student (具身智能组)
(16, 8, 'project_group', 1); -- 何佳慧 -> student (数据组)


-- ============================================================
-- 3. 项目组成员表 (project_members)
-- 已有 seed.sql: 4个固定项目组 (id 1-4)
-- ============================================================
INSERT INTO `project_members` (`project_group_id`, `user_id`, `member_role`) VALUES
-- 数据组 (group_id=1): 导师 李教授, 成员 周一帆/吴思琪/何佳慧
(1, 3,  'teacher'),
(1, 9,  'student'),
(1, 10, 'student'),
(1, 16, 'student'),

-- 多模态融合组 (group_id=2): 导师 张明远, phd 王博文, 成员 刘子轩/孙雨桐
(2, 2, 'teacher'),
(2, 4, 'phd'),
(2, 7, 'student'),
(2, 8, 'student'),

-- 具身智能组 (group_id=3): phd 赵思远, 成员 黄志强/杨雪琳/马晓东
(3, 5, 'phd'),
(3, 13, 'student'),
(3, 14, 'student'),
(3, 15, 'student'),

-- 天基网络组 (group_id=4): 导师 张明远, 成员 郑浩然/林小雨
(4, 2, 'teacher'),
(4, 11, 'student'),
(4, 12, 'student');


-- ============================================================
-- 4. 到场记录表 (attendance_records)
-- 最近5个工作日 (2026-06-24 ~ 2026-06-30，跳过周末)
-- ============================================================
INSERT INTO `attendance_records` (`student_id`, `project_group_id`, `attendance_date`, `presence_status`, `recorder_id`, `remark`) VALUES
-- 2026-06-24 星期三
(7,  2, '2026-06-24', 'present', 6, NULL),
(8,  2, '2026-06-24', 'present', 6, NULL),
(9,  1, '2026-06-24', 'present', 6, NULL),
(10, 1, '2026-06-24', 'absent',  6, '请假-身体不适'),
(11, 4, '2026-06-24', 'present', 6, NULL),
(12, 4, '2026-06-24', 'present', 6, NULL),
(13, 3, '2026-06-24', 'present', 6, NULL),
(14, 3, '2026-06-24', 'present', 6, NULL),
(15, 3, '2026-06-24', 'present', 6, NULL),
(16, 1, '2026-06-24', 'present', 6, NULL),

-- 2026-06-25 星期四
(7,  2, '2026-06-25', 'present', 6, NULL),
(8,  2, '2026-06-25', 'present', 6, '线上参会-ACM-MM'),
(9,  1, '2026-06-25', 'present', 6, NULL),
(10, 1, '2026-06-25', 'present', 6, NULL),
(11, 4, '2026-06-25', 'present', 6, NULL),
(12, 4, '2026-06-25', 'absent',  6, '外出实验'),
(13, 3, '2026-06-25', 'present', 6, NULL),
(14, 3, '2026-06-25', 'present', 6, NULL),
(15, 3, '2026-06-25', 'present', 6, NULL),
(16, 1, '2026-06-25', 'present', 6, NULL),

-- 2026-06-26 星期五
(7,  2, '2026-06-26', 'present', 6, NULL),
(8,  2, '2026-06-26', 'present', 6, NULL),
(9,  1, '2026-06-26', 'present', 6, NULL),
(10, 1, '2026-06-26', 'present', 6, NULL),
(11, 4, '2026-06-26', 'present', 6, NULL),
(12, 4, '2026-06-26', 'present', 6, NULL),
(13, 3, '2026-06-26', 'absent',  6, '请假-家中有事'),
(14, 3, '2026-06-26', 'present', 6, NULL),
(15, 3, '2026-06-26', 'present', 6, NULL),
(16, 1, '2026-06-26', 'present', 6, NULL),

-- 2026-06-29 星期一
(7,  2, '2026-06-29', 'present', 6, NULL),
(8,  2, '2026-06-29', 'present', 6, NULL),
(9,  1, '2026-06-29', 'present', 6, NULL),
(10, 1, '2026-06-29', 'present', 6, NULL),
(11, 4, '2026-06-29', 'present', 6, NULL),
(12, 4, '2026-06-29', 'present', 6, NULL),
(13, 3, '2026-06-29', 'present', 6, NULL),
(14, 3, '2026-06-29', 'present', 6, NULL),
(15, 3, '2026-06-29', 'unknown', 6, '未签到'),
(16, 1, '2026-06-29', 'present', 6, NULL),

-- 2026-06-30 星期二 (今天)
(7,  2, '2026-06-30', 'present', 6, NULL),
(8,  2, '2026-06-30', 'present', 6, NULL),
(9,  1, '2026-06-30', 'present', 6, NULL),
(10, 1, '2026-06-30', 'present', 6, NULL),
(11, 4, '2026-06-30', 'present', 6, NULL),
(12, 4, '2026-06-30', 'present', 6, NULL),
(13, 3, '2026-06-30', 'present', 6, NULL),
(14, 3, '2026-06-30', 'present', 6, NULL),
(15, 3, '2026-06-30', 'present', 6, NULL),
(16, 1, '2026-06-30', 'absent',  6, '请假-陪同导师出差');


-- ============================================================
-- 5. 课表上传表 (student_schedules)
-- ============================================================
INSERT INTO `student_schedules` (`id`, `student_id`, `semester`, `source_file_name`, `source_file_url`, `file_type`, `parse_status`) VALUES
(1, 7,  '2026春季学期', '刘子轩_课表.docx', '/uploads/schedule_7_刘子轩_课表.docx',   'docx', 'success'),
(2, 8,  '2026春季学期', '孙雨桐_课表.docx', '/uploads/schedule_8_孙雨桐_课表.docx',   'docx', 'success'),
(3, 9,  '2026春季学期', '周一帆_课表.docx', '/uploads/schedule_9_周一帆_课表.docx',   'docx', 'success'),
(4, 13, '2026春季学期', '黄志强_课表.doc',  '/uploads/schedule_13_黄志强_课表.doc',   'doc',  'manually_fixed'),
(5, 15, '2026春季学期', '马晓东_课表.docx', '/uploads/schedule_15_马晓东_课表.docx',   'docx', 'pending');


-- ============================================================
-- 6. 课程明细表 (student_schedule_items)
-- ============================================================
INSERT INTO `student_schedule_items` (`schedule_id`, `student_id`, `weekday`, `section_label`, `section_no`, `start_time`, `end_time`, `course_name`, `class_name`, `weeks_text`, `teacher_name`, `location`) VALUES
-- 刘子轩 周一
(1, 7, 1, '上午1', 1, '08:00', '08:50', '高级机器学习', NULL, '1-16周', '陈教授', '教三楼301'),
(1, 7, 1, '上午2', 2, '08:55', '09:45', '高级机器学习', NULL, '1-16周', '陈教授', '教三楼301'),
(1, 7, 1, '下午5', 5, '14:00', '14:50', '计算机视觉专题', NULL, '1-12周', '张明远', '实验室A205'),
(1, 7, 1, '下午6', 6, '14:55', '15:45', '计算机视觉专题', NULL, '1-12周', '张明远', '实验室A205'),
-- 刘子轩 周三
(1, 7, 3, '上午3', 3, '10:00', '10:50', '学术英语写作', NULL, '1-16周', '王老师', '综合楼502'),
(1, 7, 3, '上午4', 4, '10:55', '11:45', '学术英语写作', NULL, '1-16周', '王老师', '综合楼502'),
-- 刘子轩 周五
(1, 7, 5, '晚上9', 9, '19:00', '19:50', '科研论文研讨', '研究生班', '3-14周', '张明远', '实验室A205'),

-- 孙雨桐 周二
(2, 8, 2, '上午1', 1, '08:00', '08:50', '多模态学习', NULL, '1-16周', '张明远', '教三楼405'),
(2, 8, 2, '上午2', 2, '08:55', '09:45', '多模态学习', NULL, '1-16周', '张明远', '教三楼405'),
(2, 8, 2, '下午7', 7, '16:00', '16:50', '深度学习实践', NULL, '1-8周', '刘教授', '计算中心B101'),
-- 孙雨桐 周四
(2, 8, 4, '上午3', 3, '10:00', '10:50', '统计学习方法', NULL, '1-16周', '周教授', '教一楼201'),
(2, 8, 4, '上午4', 4, '10:55', '11:45', '统计学习方法', NULL, '1-16周', '周教授', '教一楼201'),

-- 周一帆 周一
(3, 9, 1, '上午1', 1, '08:00', '08:50', '数据挖掘', NULL, '1-16周', '李教授', '教二楼101'),
(3, 9, 1, '上午2', 2, '08:55', '09:45', '数据挖掘', NULL, '1-16周', '李教授', '教二楼101'),

-- 黄志强 周三
(4, 13, 3, '上午1', 1, '08:00', '08:50', '机器人学导论', NULL, '1-16周', '赵教授', '机电楼301'),
(4, 13, 3, '上午2', 2, '08:55', '09:45', '机器人学导论', NULL, '1-16周', '赵教授', '机电楼301'),
(4, 13, 3, '下午5', 5, '14:00', '14:50', 'ROS编程实践', '小班', '5-16周', '赵思远', '实验室B102'),
(4, 13, 3, '下午6', 6, '14:55', '15:45', 'ROS编程实践', '小班', '5-16周', '赵思远', '实验室B102');


-- ============================================================
-- 7. 日报表 (daily_reports)
-- 最近5个工作日
-- ============================================================
INSERT INTO `daily_reports` (`id`, `student_id`, `project_group_id`, `report_date`, `completed_work`, `problems`, `next_plan`, `work_hours`, `tags`, `mentioned_users`, `status`, `submitted_at`) VALUES
-- === 刘子轩 (id=7) 多模态融合组 ===
(1,  7, 2, '2026-06-24',
 '1. 复现了DETR目标检测模型，在COCO子集上完成训练\n2. 阅读论文《DINO: DETR with Improved DeNoising Anchor Boxes》，整理阅读笔记\n3. 修复了数据预处理管线中图像尺寸不一致的bug',
 'DETR模型在小目标上的检测精度偏低，mAP@small仅23.4%，怀疑是特征金字塔层级设置问题',
 '1. 调整Backbone的多尺度特征输出配置\n2. 对比DINO论文中的去噪训练策略\n3. 准备组会PPT汇报本周进展',
 8.5, '["论文阅读","模型复现","代码调试"]', '[4]', 'submitted', '2026-06-24 18:30:00'),

(2,  7, 2, '2026-06-25',
 '1. 修改ResNet50 backbone的多尺度特征输出，增加P2层级\n2. 重新训练DETR模型，小目标mAP提升至27.8%\n3. 协助王博文学长处理实验数据标注质量问题',
 'P2层级的引入导致训练显存增加了约15%，batch_size被迫从8降到6',
 '1. 尝试使用混合精度训练（AMP）减少显存占用\n2. 实现DINO的去噪anchor模块\n3. 继续整理组会PPT',
 9.0, '["模型优化","实验","协助"]', '[4,8]', 'submitted', '2026-06-25 19:15:00'),

(3,  7, 2, '2026-06-26',
 '1. 成功在模型中加入AMP混合精度训练，显存占用降低约30%，batch_size恢复到8\n2. 开始实现DINO的CDN（Contrastive DeNoising）模块\n3. 完成组会PPT初稿',
 'CDN模块中正负样本匹配逻辑较复杂，参考代码存在版本兼容问题',
 '下周继续完成CDN模块实现，争取跑通DINO的baseline实验',
 9.5, '["模型优化","工程实现","汇报准备"]', '[4]', 'submitted', '2026-06-26 20:00:00'),

(4,  7, 2, '2026-06-29',
 '1. 基本完成CDN模块的代码实现，正在调试loss计算\n2. 组会汇报了本周进展，导师建议在COCO完整验证集上评估\n3. 阅读了导师推荐的《Detection Transformer》综述',
 'CDN模块loss下降不稳定，epoch间波动较大，可能需要调整学习率warmup策略',
 '1. 在完整COCO验证集上跑baseline评估\n2. 调试CDN训练稳定性\n3. 协助孙雨桐做大模型微调实验的评测方案',
 8.0, '["论文阅读","模型开发","组会"]', '[2,4,8]', 'submitted', '2026-06-29 18:45:00'),

(5,  7, 2, '2026-06-30',
 '1. COCO完整验证集baseline评估完成：AP=42.1%, AP50=63.5%, APs=28.2%\n2. 调整了CDN训练的学习率warmup从500iter增加到1000iter，loss趋于稳定\n3. 帮助孙雨桐设计了大模型微调的评测指标体系',
 '当前精度距离SOTA（DINO的AP=49.0%）还有较大差距，主要是query初始化策略需要改进',
 '1. 实现DINO的mixed query selection初始化\n2. 明天开始CDN+DINO完整训练，预计需要2-3天\n3. 处理周报',
 10.0, '["实验评估","模型开发","协作"]', '[4,8]', 'submitted', '2026-06-30 17:30:00'),

-- === 孙雨桐 (id=8) 多模态融合组 ===
(6,  8, 2, '2026-06-24',
 '1. 使用LoRA方法对LLaVA-1.5进行微调，在科学图表理解任务上训练1个epoch\n2. 收集了200张Nature/Cell期刊的图表数据作为训练集\n3. 搭建了基于GPT-4V的自动评测pipeline',
 'LoRA rank=8时微调效果不明显，可能需要增大rank到32或64；GPU资源紧张，训练速度偏慢',
 '1. 尝试LoRA rank=32重新训练\n2. 对比全量微调和LoRA微调的效果差异\n3. 扩充训练集到500张',
 8.0, '["模型微调","数据收集","评测搭建"]', '[4,7]', 'submitted', '2026-06-24 19:00:00'),

(7,  8, 2, '2026-06-25',
 '1. LoRA rank=32训练完成2个epoch，图表描述BLEU-4从22.3提升到25.1\n2. 训练集扩充至350张\n3. 开始评测全量微调的baseline（使用A100 80G）',
 'A100资源需要排队，全量微调仅跑了0.5个epoch就被抢占；图表中复杂数学公式的OCR识别错误较多',
 '1. 排队等A100资源继续全量微调实验\n2. 调研MathPix API做公式OCR预处理\n3. 写实验记录文档',
 9.0, '["模型微调","实验","数据工程"]', '[4]', 'submitted', '2026-06-25 20:30:00'),

(8,  8, 2, '2026-06-26',
 '1. 全量微调完成1个epoch，初步结果不如LoRA（疑似过拟合）\n2. 集成MathPix API做公式预处理，公式识别准确率从60%提升至89%\n3. 训练集扩充至480张',
 '全量微调过拟合问题需要进一步分析，可能与训练集较小有关；MathPix API调用有频率限制',
 '下周完成全量微调实验，并展开消融实验分析各组件贡献度',
 8.5, '["实验","工具集成","数据分析"]', '[4,7]', 'submitted', '2026-06-26 18:30:00'),

(9,  8, 2, '2026-06-29',
 '1. 完成全量微调2个epoch，确认小数据集场景下LoRA优于全量微调（BLEU 25.1 vs 23.8）\n2. 与刘子轩讨论后完善了评测指标体系（加入METEOR、CIDEr、人工评分）\n3. 开始撰写实验报告',
 '人工评测需要邀请其他同学参与，目前仅本人自评，结果可能biased',
 '1. 邀请3位同学进行盲评\n2. 完善实验报告初稿\n3. 准备下周的论文分享',
 7.5, '["实验分析","文档撰写","协作"]', '[7,11,12]', 'submitted', '2026-06-29 19:20:00'),

(10, 8, 2, '2026-06-30',
 '1. 收到3位同学的人工盲评结果，平均分4.2/5，主要扣分点在长图表的结构化描述\n2. 实验报告完成初稿（约3000字）\n3. 针对长图表问题，调研了分段描述+层级聚合的方案',
 '长图表（超过3个子图）的描述连贯性确实是当前模型短板，prompt engineering可能治标不治本',
 '1. 尝试chain-of-thought多轮对话式图表描述\n2. 润色实验报告\n3. 处理周报',
 9.0, '["实验分析","文档撰写","调研"]', '[4,7]', 'submitted', '2026-06-30 18:00:00'),

-- === 周一帆 (id=9) 数据组 ===
(11, 9, 1, '2026-06-29',
 '1. 调研了3种联邦学习框架（Flower、FedML、PySyft），完成对比分析文档\n2. 在Flower框架上搭建了基础的FedAvg训练脚本\n3. 使用MNIST数据集进行了2-client的模拟实验',
 'FedML文档不够完善，部分API已经deprecated但与教程不一致；模拟实验的Non-IID数据划分策略需要深入理解',
 '1. 在CIFAR-10上验证FedAvg\n2. 阅读《Advances and Open Problems in Federated Learning》综述\n3. 确定Non-IID划分方案',
 8.0, '["调研","框架搭建","实验"]', '[3,10]', 'submitted', '2026-06-29 17:45:00'),

-- === 吴思琪 (id=10) 数据组 ===
(12, 10, 1, '2026-06-29',
 '1. 使用GPT-4生成1000条中文科技领域NER标注数据\n2. 基于BERT-base-chinese训练了baseline NER模型，F1=78.3%\n3. 分析了模型在长实体和嵌套实体上的错误case',
 'GPT-4生成的数据存在标签不一致问题（同一实体在不同上下文中标签不同），需要人工review',
 '1. 随机抽样200条进行人工质检\n2. 尝试加入对抗训练提升鲁棒性\n3. 调研few-shot NER的最新方法',
 7.5, '["数据生成","模型训练","错误分析"]', '[9,16]', 'submitted', '2026-06-29 19:00:00'),

-- === 郑浩然 (id=11) 天基网络组 ===
(13, 11, 4, '2026-06-29',
 '1. 使用STK软件完成了低轨卫星星座（Walker Delta 80/8/1）的轨道仿真\n2. 计算了星座对北京地区的覆盖性能：平均可见卫星数12.3颗，覆盖重访时间约8.2分钟\n3. 搭建了基于NS-3的星地链路仿真环境',
 'STK许可证即将到期，需要申请续期；NS-3中星地链路的信道模型参数需要根据实际频段（Ka 30GHz）校准',
 '1. 申请STK许可证续期\n2. 校准NS-3信道模型参数\n3. 运行初步的端到端延迟仿真',
 8.5, '["仿真","星座设计","环境搭建"]', '[2,12]', 'submitted', '2026-06-29 20:10:00'),

-- === 黄志强 (id=13) 具身智能组 ===
(14, 13, 3, '2026-06-29',
 '1. 在Isaac Sim中搭建了UR5机械臂+RGBD相机的仿真环境\n2. 实现了基于PPO的reach任务baseline，成功率达到85%\n3. 开始尝试domain randomization以提高sim-to-real的泛化能力',
 'Isaac Sim在RTX 4090上运行偶尔崩溃（可能是驱动版本不兼容），domain randomization参数范围需要仔细调优',
 '1. 升级NVIDIA驱动到最新版本\n2. 完成domain randomization的消融实验\n3. 开始训练grasp任务',
 9.0, '["仿真搭建","强化学习","实验"]', '[5,14,15]', 'submitted', '2026-06-29 18:30:00'),

-- === 朱伟杰 (id=17) 已毕业, 但有历史日报 ===
(15, 17, 2, '2026-03-15',
 '1. 完成毕业论文第四章实验部分\n2. 修改了第三章的图神经网络架构设计\n3. 导师反馈了论文修改意见12条',
 '部分消融实验的可视化图表需要重新制作，matplotlib默认样式不满足期刊要求',
 '按照导师意见逐条修改论文',
 6.0, '["论文撰写","实验","修改"]', '[2,4]', 'submitted', '2026-03-15 21:00:00');


-- ============================================================
-- 8. 周报表 (weekly_reports)
-- ============================================================
INSERT INTO `weekly_reports` (`id`, `student_id`, `project_group_id`, `week_start`, `week_end`, `week_label`, `weekly_goal`, `completed_work`, `key_results`, `unfinished_work`, `reason_analysis`, `next_week_plan`, `help_needed`, `self_score`, `status`, `submitted_at`) VALUES
-- 刘子轩 第26周
(1, 7, 2, '2026-06-22', '2026-06-28', '第26周',
 '1. 完成DETR模型复现和baseline评估\n2. 实现DINO的CDN模块\n3. 完成组会汇报',
 '1. 成功复现DETR模型，COCO验证集AP=42.1%\n2. 完成CDN模块实现（代码量约800行）\n3. 通过引入AMP将训练显存降低30%\n4. 完成组会汇报并获导师肯定',
 '1. 多尺度特征优化后小目标mAP从23.4%提升至27.8%\n2. 混合精度训练使batch_size恢复到8，训练效率提升约25%\n3. CDN模块初步可用，正在调试训练稳定性',
 '混合query选择（mixed query selection）尚未实现，这是DINO相比DETR的核心改进之一',
 'CDN训练稳定性调试耗时超出预期，主要卡在正负样本匹配的超参选择上',
 '1. 实现mixed query selection初始化\n2. 完成CDN+DINO完整训练\n3. 整理实验结果撰写实验报告',
 '需要更多GPU资源进行消融实验（预计需要A100 80G x 200小时）',
 7, 'submitted', '2026-06-28 20:00:00'),

-- 孙雨桐 第26周
(2, 8, 2, '2026-06-22', '2026-06-28', '第26周',
 '1. 完成LLaVA-1.5的LoRA微调实验\n2. 建立科学图表理解评测体系\n3. 撰写实验报告初稿',
 '1. 完成LoRA微调（rank=8/32/64三组实验）\n2. 全量微调baseline完成\n3. 集成MathPix API，公式识别准确率89%\n4. 建立含BLEU/METEOR/CIDEr/人工评分的评测体系\n5. 训练集扩充至480张',
 '1. LoRA rank=32最优，BLEU-4=25.1，优于全量微调的23.8\n2. MathPix集成后公式识别端到端准确率提升约29个百分点\n3. 确认小数据集场景下LoRA优于全量微调',
 '长图表（>3子图）的结构化描述效果不理想，人工评分均分仅3.1/5',
 '长图表问题的根源在于当前prompt缺乏层次化描述能力，简单的prompt engineering可能不够',
 '1. 实现chain-of-thought多轮对话式图表描述\n2. 完善实验报告\n3. 准备论文分享PPT',
 '希望导师推荐相关层次化图像描述的最新论文',
 8, 'submitted', '2026-06-28 21:30:00'),

-- 黄志强 第26周
(3, 13, 3, '2026-06-22', '2026-06-28', '第26周',
 '1. 搭建UR5机械臂仿真环境\n2. 实现PPO-based reach任务baseline',
 '1. 在Isaac Sim中完成UR5+RGBD相机仿真环境搭建\n2. 实现PPO reach任务，成功率85%\n3. 开始domain randomization实验',
 '1. Isaac Sim仿真环境可用，渲染速度约120fps\n2. PPO baseline成功率85%，训练时间约4小时\n3. domain randomization初步结果显示泛化能力有提升（+5%未见场景成功率）',
 'domain randomization的随机化参数范围和分布需要更系统的调优',
 'Isaac Sim不稳定崩溃占用了约20%的调试时间（驱动兼容性问题），已升级驱动解决',
 '1. 完成domain randomization系统消融实验\n2. 开始训练grasp任务\n3. 撰写仿真环境搭建文档供组内复用',
 '需要申请一块额外的SSD（约500GB）存储仿真数据和checkpoint',
 6, 'submitted', '2026-06-28 19:00:00'),

-- 刘子轩 第27周 草稿
(4, 7, 2, '2026-06-29', '2026-07-05', '第27周',
 '本周目标：完成DINO完整实现并在COCO上达到AP>45%',
 '（进行中）CDN模块loss已稳定，COCO验证集baseline评估完成',
 NULL,
 NULL, NULL,
 '继续推进DINO完整训练',
 NULL, NULL, 'draft', NULL);


-- ============================================================
-- 9. 任务表 (tasks)
-- ============================================================
INSERT INTO `tasks` (`id`, `title`, `description`, `project_group_id`, `assignee_id`, `creator_id`, `priority`, `status`, `start_date`, `deadline`, `milestone`, `completed_at`) VALUES
-- 多模态融合组任务
(1, 'DINO目标检测模型完整复现',
 '基于PyTorch复现DINO: DETR with Improved DeNoising Anchor Boxes论文，要求在COCO2017验证集上达到AP>45%',
 2, 7, 4, 'high', 'doing', '2026-06-15', '2026-07-15 23:59:59', '中期检查: 2026-07-01', NULL),

(2, 'LLaVA-1.5科学图表理解微调',
 '使用LoRA方法对LLaVA-1.5进行微调，面向科学图表（Nature/Cell期刊）的理解和描述生成任务',
 2, 8, 4, 'high', 'doing', '2026-06-10', '2026-07-20 23:59:59', '实验报告: 2026-07-10', NULL),

(3, '多模态融合组组会PPT准备',
 '准备第27周组会PPT，汇报DINO复现进展和LLaVA微调实验',
 2, 7, 4, 'medium', 'done', '2026-06-25', '2026-06-28 12:00:00', NULL, '2026-06-27 16:00:00'),

(4, '图表数据收集与标注',
 '从Nature/Cell等顶刊收集科学图表，目标500张，并进行人工标注（图表类型、包含元素、公式等）',
 2, 8, 2, 'medium', 'review', '2026-06-01', '2026-07-05 23:59:59', '达到500张: 2026-07-01', NULL),

-- 具身智能组任务
(5, 'UR5机械臂仿真环境搭建',
 '在Isaac Sim中搭建UR5+RGBD相机+桌面的仿真环境，要求支持grasp和reach两类任务，渲染速度>100fps',
 3, 13, 5, 'high', 'doing', '2026-06-20', '2026-07-10 23:59:59', '环境验收: 2026-07-05', NULL),

(6, 'PPO强化学习baseline训练',
 '在UR5仿真环境中实现并训练PPO算法的reach和grasp任务baseline，要求reach成功率>90%',
 3, 13, 5, 'high', 'doing', '2026-06-22', '2026-07-18 23:59:59', 'reach>90%: 2026-07-10', NULL),

(7, 'Domain Randomization消融实验',
 '系统分析domain randomization各参数（光照、纹理、物理参数、相机位姿）对sim-to-real泛化的贡献',
 3, 13, 5, 'medium', 'todo', '2026-06-28', '2026-07-25 23:59:59', NULL, NULL),

(8, '机械臂实验平台搭建文档',
 '撰写Isaac Sim仿真环境搭建和使用的完整文档，供组内同学复用（目标：新人1小时内完成环境搭建）',
 3, 14, 5, 'low', 'todo', '2026-07-01', '2026-07-30 23:59:59', NULL, NULL),

-- 数据组任务
(9, '联邦学习FedAvg基线实现',
 '使用Flower框架实现FedAvg算法，在CIFAR-10上验证（Non-IID划分，至少5个client），baseline accuracy>85%',
 1, 9, 3, 'high', 'todo', '2026-06-25', '2026-07-20 23:59:59', NULL, NULL),

(10, 'NER数据质量评估',
 '对GPT-4生成的NER标注数据进行质量评估：随机抽样200条人工review，计算标注一致率和错误类型分布',
 1, 10, 3, 'medium', 'doing', '2026-06-28', '2026-07-05 23:59:59', NULL, NULL),

-- 天基网络组任务
(11, '低轨星座覆盖性能仿真',
 '使用STK对Walker Delta星座进行覆盖性能仿真，输出对北京地区的可见卫星数、覆盖重访时间、平均仰角等指标',
 4, 11, 2, 'high', 'doing', '2026-06-15', '2026-07-10 23:59:59', '中期报告: 2026-07-01', NULL),

(12, 'NS-3星地链路仿真',
 '基于NS-3搭建星地链路仿真模型，输出Ka频段（30GHz）的端到端延迟、丢包率、吞吐量等性能指标',
 4, 11, 2, 'medium', 'todo', '2026-07-01', '2026-07-31 23:59:59', NULL, NULL),

-- 逾期任务
(13, '多模态数据集论文文献综述',
 '完成近3年多模态数据集相关论文的文献综述（至少30篇），输出综述文档',
 2, 7, 2, 'medium', 'overdue', '2026-06-01', '2026-06-20 23:59:59', NULL, NULL),

-- 已完成任务
(14, '实验室服务器环境配置文档',
 '编写实验室GPU服务器（4×A100 80G）的使用文档，包括环境配置、作业调度、常见问题排查',
 2, 8, 4, 'low', 'done', '2026-05-01', '2026-06-15 23:59:59', NULL, '2026-06-10 14:00:00'),

-- 被阻塞任务
(15, 'Isaac Sim驱动兼容性修复',
 '升级NVIDIA驱动至545+版本以修复Isaac Sim在RTX 4090上的随机崩溃问题，需要root权限',
 3, 13, 5, 'urgent', 'blocked', '2026-06-28', '2026-07-01 23:59:59', NULL, NULL);


-- ============================================================
-- 10. 任务协作者表 (task_collaborators)
-- ============================================================
INSERT INTO `task_collaborators` (`task_id`, `user_id`) VALUES
(1, 8),   -- DINO复现: 孙雨桐协助
(2, 7),   -- LLaVA微调: 刘子轩协助（评测设计）
(4, 7),   -- 图表收集: 刘子轩协助
(6, 14),  -- PPO baseline: 杨雪琳协助
(6, 15),  -- PPO baseline: 马晓东协助
(11, 12); -- 星座仿真: 林小雨协助（数据可视化）


-- ============================================================
-- 11. 任务-报告关联表 (task_report_links)
-- ============================================================
INSERT INTO `task_report_links` (`task_id`, `report_type`, `report_id`) VALUES
(1, 'daily_report', 1),
(1, 'daily_report', 5),
(2, 'daily_report', 6),
(3, 'daily_report', 4),
(5, 'daily_report', 14),
(1, 'weekly_report', 1),
(2, 'weekly_report', 2);


-- ============================================================
-- 12. 评论反馈表 (comments)
-- ============================================================
INSERT INTO `comments` (`id`, `target_type`, `target_id`, `author_id`, `content`, `action_type`, `parent_id`, `resolved`) VALUES
-- 日报评论
(1, 'daily_report', 1, 4,
 'DETR复现进展不错。关于小目标精度低的问题，建议除了调整FPN层级外，也可以考虑使用可变形注意力（Deformable Attention）替代原始的自注意力，这在DETR的小目标改进上效果显著。', 'comment', NULL, 0),

(2, 'daily_report', 1, 7,
 '收到，我查一下Deformable DETR的论文，看看是否容易集成到当前的代码框架中。', 'comment', 1, 0),

(3, 'daily_report', 5, 2,
 '进展很好！AP=42.1%作为baseline已经不错了。CDN训练稳定后尽快开始正式训练。注意记录每次实验的完整超参配置，方便后续写论文时回溯。', 'comment', NULL, 0),

(4, 'daily_report', 10, 4,
 '长图表描述确实是个难题。除了chain-of-thought，建议也看看Qwen-VL在这方面的工作，他们在多图理解和长文档VQA上有些有趣的尝试。', 'comment', NULL, 0),

(5, 'daily_report', 12, 9,
 'GPT-4生成NER数据的一致性问题我之前也遇到过。建议设置一个简单的规则后处理（比如基于实体类型的白名单约束），可以有效减少标签不一致的情况。', 'comment', NULL, 0),

-- 周报评论
(6, 'weekly_report', 1, 2,
 '第26周工作总结到位。GPU资源的问题我去协调，下周尽量给你多分配一些A100机时。另外，文献综述（tasks#13）已经逾期了，需要尽快补上。', 'comment', NULL, 0),

(7, 'weekly_report', 1, 4,
 '关于混合query选择，可以参考DINO的官方实现（GitHub repo），我把代码链接发你。另外文献综述确实拖得有点久了，本周优先处理一下。', 'request_change', NULL, 0),

(8, 'weekly_report', 2, 2,
 'LoRA vs 全量微调的实验设计很扎实。实验报告完善后可以考虑投ML4Science workshop（deadline 8月底），这个工作的实验量足够了。', 'approve', NULL, 0),

(9, 'weekly_report', 3, 5,
 '仿真环境搭建辛苦了。Isaac Sim的驱动问题我去联系IT解决（已创建task#15）。domain randomization实验不急，先把环境稳定下来。', 'comment', NULL, 0),

-- 任务评论
(10, 'task', 13, 2,
 '文献综述的deadline已经过了10天，这周务必完成。先交一个初稿给我看，不需要完美，关键是覆盖面要够。', 'request_change', NULL, 0),

(11, 'task', 3, 4,
 '组会PPT做得不错，DETR和DINO的对比部分讲得很清楚。下次可以加一页关于后续计划的timeline。', 'approve', NULL, 0),

(12, 'task', 15, 5,
 '已经联系了IT部门，他们明天会来处理驱动升级。你先用CPU模式跑一下数据预处理的脚本，不要因为这个问题卡住进度。', 'comment', NULL, 0),

(13, 'task', 12, 2,
 'NS-3仿真中Ka频段的信道模型可以参考ITU-R P.618建议书，我让郑浩然把这部分资料发给你。', 'comment', NULL, 0);


-- ============================================================
-- 13. 附件表 (attachments)
-- ============================================================
INSERT INTO `attachments` (`id`, `target_type`, `target_id`, `file_name`, `file_url`, `file_type`, `file_size`, `uploader_id`) VALUES
(1, 'daily_report', 5, 'coco_baseline_results.csv',   '/uploads/attachments/coco_baseline_results.csv',   'csv',   245760, 7),
(2, 'daily_report', 5, 'detr_training_loss.png',       '/uploads/attachments/detr_training_loss.png',       'image', 102400, 7),
(3, 'daily_report', 10, 'human_eval_scores.xlsx',       '/uploads/attachments/human_eval_scores.xlsx',       'xlsx',  51200,  8),
(4, 'daily_report', 14, 'isaac_sim_setup_screenshot.png','/uploads/attachments/isaac_sim_setup.png',           'image', 320000, 13),
(5, 'weekly_report', 1, 'DINO_CDN_code_preview.zip',    '/uploads/attachments/DINO_CDN_code_preview.zip',    'code',  1536000,7),
(6, 'weekly_report', 2, 'LLaVA_finetune_report_v1.docx', '/uploads/attachments/LLaVA_finetune_report_v1.docx', 'docx', 204800, 8),
(7, 'task', 1, 'DINO_paper_annotated.pdf',              '/uploads/attachments/DINO_paper_annotated.pdf',     'pdf',   5120000,7);


-- ============================================================
-- 14. 报告版本表 (report_versions)
-- 部分日报编辑过，记录历史版本
-- ============================================================
INSERT INTO `report_versions` (`report_type`, `report_id`, `version_no`, `content_snapshot`, `editor_id`) VALUES
('daily',  1, 1, '{"student_id":7,"completed_work":"1. 复现了DETR目标检测模型\\n2. 阅读论文《DINO》","problems":"DETR模型在小目标上的检测精度偏低","next_plan":"调整Backbone的多尺度特征输出配置","work_hours":8.0}', 7),
('daily',  5, 1, '{"student_id":7,"completed_work":"1. COCO完整验证集baseline评估完成\\n2. 调整了CDN训练的学习率warmup","problems":"query初始化策略需要改进","next_plan":"实现mixed query selection","work_hours":9.0}', 7),
('daily',  5, 2, '{"student_id":7,"completed_work":"1. COCO验证集AP=42.1%\\n2. CDN loss趋于稳定\\n3. 帮助孙雨桐设计评测指标","problems":"query初始化策略需要改进","next_plan":"实现mixed query selection + CDN+DINO完整训练","work_hours":10.0}', 7),
('weekly', 1, 1, '{"student_id":7,"completed_work":"1. 复现DETR，AP=41.5%\\n2. CDN模块实现中","key_results":"多尺度特征优化后小目标mAP从23.4%提升至27.8%","next_week_plan":"完成CDN+DINO完整训练","self_score":6}', 7);


-- ============================================================
-- 15. 日历事件表 (calendar_events)
-- ============================================================
INSERT INTO `calendar_events` (`id`, `title`, `description`, `event_type`, `owner_id`, `project_group_id`, `student_id`, `related_type`, `related_id`, `start_at`, `end_at`, `all_day`, `priority`, `visibility`, `color`) VALUES
-- Deadlines
(1, '[Deadline] DINO目标检测模型完整复现', 'COCO AP>45%', 'task_deadline', 4, 2, 7, 'task', 1, '2026-07-15 23:59:00', '2026-07-15 23:59:00', 0, 'high', 'lab', '#e74c3c'),
(2, '[Deadline] 文献综述', '多模态数据集论文综述>=30篇', 'task_deadline', 2, 2, 7, 'task', 13, '2026-06-20 23:59:00', '2026-06-20 23:59:00', 0, 'urgent', 'lab', '#e74c3c'),
(3, '[Deadline] 图表收集达到500张', NULL, 'task_deadline', 2, 2, 8, 'task', 4, '2026-07-05 23:59:00', '2026-07-05 23:59:00', 0, 'medium', 'lab', '#f39c12'),
(4, '[Deadline] UR5仿真环境搭建', '验收标准：支持grasp+reach任务，>100fps', 'task_deadline', 5, 3, 13, 'task', 5, '2026-07-10 23:59:00', '2026-07-10 23:59:00', 0, 'high', 'lab', '#e74c3c'),

-- 会议
(5, '多模态融合组组会', '第27周组会：刘子轩汇报DINO进展，孙雨桐汇报LLaVA实验', 'meeting', 2, 2, NULL, NULL, NULL, '2026-07-03 14:00:00', '2026-07-03 16:00:00', 0, 'high', 'lab', '#3498db'),
(6, '具身智能组周会', '讨论仿真环境搭建和PPO baseline进展', 'meeting', 5, 3, NULL, NULL, NULL, '2026-07-02 10:00:00', '2026-07-02 11:30:00', 0, 'medium', 'lab', '#3498db'),
(7, '全实验室大会', '学期末总结大会，各项目组汇报本学期进展', 'meeting', 2, NULL, NULL, NULL, NULL, '2026-07-18 09:00:00', '2026-07-18 12:00:00', 0, 'high', 'lab', '#2ecc71'),

-- 论文相关
(8, 'CVPR 2027 摘要截止', 'CVPR 2027 paper abstract submission deadline', 'paper', 7, 2, NULL, NULL, NULL, '2026-11-15 23:59:00', '2026-11-15 23:59:00', 0, 'high', 'lab', '#9b59b6'),

-- 里程碑
(9, 'DINO中期检查', '检查DINO复现进度：baseline AP、CDN模块完成度、训练稳定性', 'milestone', 4, 2, 7, 'task', 1, '2026-07-01 09:00:00', '2026-07-01 10:00:00', 0, 'high', 'lab', '#e67e22'),

-- 日报提醒
(10, '日报提醒', '每日日报提交截止', 'report_due', 6, NULL, NULL, NULL, NULL, '2026-07-01 20:00:00', '2026-07-01 20:00:00', 0, 'low', 'lab', '#95a5a6');


-- ============================================================
-- 16. AI 对话表 (ai_conversations)
-- ============================================================
INSERT INTO `ai_conversations` (`id`, `user_id`, `title`, `model_name`, `adopted_count`) VALUES
(1, 7, 'DINO论文关键点解读', 'deepseek-chat', 2),
(2, 7, '科研进度风险评估', 'deepseek-chat', 1),
(3, 8, 'LLaVA微调参数调优咨询', 'deepseek-chat', 1),
(4, 2, '本周实验室进度概览', 'deepseek-chat', 0);


-- ============================================================
-- 17. AI 消息表 (ai_messages)
-- ============================================================
INSERT INTO `ai_messages` (`conversation_id`, `role`, `content`, `source_refs`) VALUES
-- 对话1: DINO论文解读
(1, 'user', 'DINO论文中的contrastive denoising training具体是怎么做的？和DETR的denoising有什么区别？', NULL),
(1, 'assistant',
 '结论：DINO的CDN（Contrastive DeNoising）相比DETR的denoising主要有三点改进：\n\n1. **对比式去噪**：DINO同时引入正样本（高质量anchor）和负样本（低质量anchor）进行对比学习，而DETR仅使用单一质量的噪声anchor。\n2. **混合查询选择**：DINO从encoder的输出中选择top-K特征作为decoder的初始查询（mixed query selection），而DETR使用零初始化的可学习查询。\n3. **前向两次**：CDN在训练时需要两次前向传播——一次带正噪声，一次带负噪声——通过对比loss拉大正负样本间的距离。\n\n详情：已完成CDN代码实现（约800行），当前loss下降趋于稳定。\n建议动作：继续监视训练稳定性，等CDN loss收敛后开始完整的DINO训练。\n\n数据来源: DR-2026-06-30-0005, WR-2026-06-22-0001',
 '[{"source_id":"DR-2026-06-30-0005","type":"daily_report"},{"source_id":"WR-2026-06-22-0001","type":"weekly_report"}]'),

-- 对话1 继续
(1, 'user', 'mixed query selection具体怎么实现？', NULL),
(1, 'assistant',
 '结论：Mixed Query Selection的核心思路是将encoder输出的位置信息与decoder的可学习内容查询相结合。\n\n实现步骤：\n1. 将encoder最后一层的输出经过检测头（class head + box head），得到每个位置的类别置信度和边界框预测。\n2. 选取置信度最高的top-K个位置（论文中K=300），提取这些位置对应的encoder特征。\n3. 将这些特征分别作为decoder的position queries（位置编码）和content queries（经过MLP映射的内容特征）的初始化。\n4. 在训练中，这些选中的queries也参与CDN的对比训练。\n\n建议动作：先参考DINO官方GitHub实现（GitHub - IDEA-Research/DINO），从其mixed_query_selection函数入手。\n\n数据来源: T-0001',
 '[{"source_id":"T-0001","type":"task"}]'),

-- 对话2: 进度风险评估
(2, 'user', '分析一下我目前的科研进度，有没有逾期风险？', NULL),
(2, 'assistant',
 '结论：你的科研进度整体正常，但存在1个逾期任务和1个即将到期的里程碑需要注意。\n\n已完成（本周）：\n- DETR baseline评估完成，COCO AP=42.1%\n- CDN模块训练loss趋于稳定\n- 组会汇报完成，获导师肯定\n\n进行中：\n- DINO完整复现（截止日期: 7月15日，剩余15天）\n- 明天（7月1日）是中期检查里程碑\n\n逾期：\n- 【严重】多模态数据集文献综述，原定6月20日截止，已逾期10天\n\n建议动作：\n1. 优先补文献综述（导师已催促，见评论）\n2. 为明天中期检查准备DINO当前进展的简要汇总\n3. DINO复现剩余时间充裕，但需要尽快开始完整训练（预计需2-3天）\n\n数据来源: T-0001, T-0013, DR-2026-06-30-0005, WR-2026-06-22-0001',
 '[{"source_id":"T-0001","type":"task"},{"source_id":"T-0013","type":"task"}]'),

-- 对话3: LLaVA微调
(3, 'user', 'LoRA微调LLaVA时rank参数怎么选？我现在用rank=32效果最好，还需要试更大的rank吗？', NULL),
(3, 'assistant',
 '结论：基于当前实验结果，rank=32已经足够，不建议继续增大。\n\n详情：\n1. 你已完成rank=8/32/64三组实验，rank=32时BLEU-4=25.1最优\n2. rank=64时BLEU-4=24.9，略低于rank=32，说明已出现过拟合趋势\n3. 全量微调仅得BLEU-4=23.8，进一步验证了在小数据集场景下LoRA的优越性\n\n建议动作：\n- 维持rank=32作为最终配置，将时间投入到其他更有效的改进（如chain-of-thought描述、数据质量提升）\n- 在实验报告中记录完整的超参搜索过程\n\n数据来源: DR-2026-06-29-0009, DR-2026-06-30-0010, WR-2026-06-22-0002',
 '[{"source_id":"DR-2026-06-29-0009","type":"daily_report"},{"source_id":"DR-2026-06-30-0010","type":"daily_report"}]'),

-- 对话4: 导师查看整体进度
(4, 'user', '多模态融合组这周整体进展如何？', NULL),
(4, 'assistant',
 '结论：多模态融合组（项目组ID=2）本周整体进展良好，4个任务中有2个在正常推进，1个已完成，1个逾期。\n\n已完成：\n- 组会PPT准备完成并汇报\n\n进行中（正常）：\n- 刘子轩（孙雨桐协助）：DINO目标检测模型复现，COCO AP=42.1%，CDN模块初步稳定\n- 孙雨桐：LLaVA-1.5科学图表理解微调，LoRA rank=32最优BLEU-4=25.1\n\n逾期：\n- 刘子轩：多模态数据集文献综述，逾期10天（已督促）\n\n本周亮点：\n- 刘子轩通过AMP混合精度训练将显存降低30%\n- 孙雨桐确认LoRA优于全量微调的关键结论\n\n风险提示：\n- DINO中期检查明天进行，需确认CDN训练状态\n- GPU资源紧张，导师已同意协调增加A100机时\n\n数据来源: T-0001, T-0002, T-0003, T-0013, WR-2026-06-22-0001, WR-2026-06-22-0002',
 '[{"source_id":"T-0001","type":"task"},{"source_id":"T-0002","type":"task"},{"source_id":"T-0013","type":"task"}]');


-- ============================================================
-- 18. 通知表 (notifications)
-- ============================================================
INSERT INTO `notifications` (`id`, `user_id`, `title`, `content`, `notification_type`, `related_type`, `related_id`, `is_read`, `sent_via`) VALUES
(1,  7, '任务逾期提醒', '你负责的任务"多模态数据集论文文献综述"已于2026-06-20逾期，请尽快完成或更新截止日期。', 'task_overdue', 'task', 13, 1, 'system'),
(2,  7, '新评论提醒', '张明远老师评论了你的日报(2026-06-30)', 'new_comment', 'daily_report', 5, 0, 'system'),
(3,  7, 'Deadline临近', 'DINO中期检查将于明天(2026-07-01)进行，请提前准备。', 'deadline_reminder', 'task', 1, 0, 'system'),
(4,  7, '周报提交提醒', '请于本周五(2026-07-03)前提交第27周周报。', 'weekly_report_reminder', 'weekly_report', NULL, 0, 'system'),
(5,  8, '新评论提醒', '王博文评论了你的日报(2026-06-30)', 'new_comment', 'daily_report', 10, 1, 'system'),
(6,  8, '周报审批通过', '你的第26周周报已被张明远老师审批通过。', 'weekly_approved', 'weekly_report', 2, 1, 'system'),
(7,  13, '任务被阻塞', '你负责的任务"Isaac Sim驱动兼容性修复"已被标记为阻塞状态（等待IT处理）。', 'task_blocked', 'task', 15, 0, 'system'),
(8,  13, '周五未签到提醒', '你在2026-06-26（周五）被标记为absent，如有请假请及时提交申请。', 'attendance_alert', 'attendance_records', NULL, 0, 'system'),
(9,  15, '今日未签到提醒', '你在2026-06-29（周一）未签到，请尽快到实验室签到。', 'attendance_alert', 'attendance_records', NULL, 1, 'system'),
(10, 2,  '逾期任务汇总', '项目组内有1个逾期任务待处理：文献综述（刘子轩，逾期10天）。', 'overdue_summary', 'task', 13, 0, 'system'),
(11, 4,  '日报待审批', '刘子轩和孙雨桐各提交了5份日报，其中有3份状态为submitted等待审批。', 'pending_review', 'daily_report', NULL, 0, 'system');


-- ============================================================
-- 19. 审计日志表 (audit_logs)
-- ============================================================
INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `target_type`, `target_id`, `detail`, `ip_address`, `user_agent`) VALUES
(1,  6, 'POST:/api/attendance/daily-records', 'attendance', NULL, '{"status":200,"records_count":10}', '192.168.1.100', 'Mozilla/5.0'),
(2,  7, 'POST:/api/daily-reports',            'daily-reports', NULL, '{"status":200}', '192.168.1.101', 'Mozilla/5.0'),
(3,  7, 'PUT:/api/daily-reports/1',           'daily-reports', NULL, '{"status":200}', '192.168.1.101', 'Mozilla/5.0'),
(4,  8, 'POST:/api/daily-reports',            'daily-reports', NULL, '{"status":200}', '192.168.1.102', 'Mozilla/5.0'),
(5,  4, 'POST:/api/comments',                  'comments', NULL, '{"status":200,"action_type":"comment"}', '192.168.1.103', 'Mozilla/5.0'),
(6,  7, 'POST:/api/weekly-reports/1/submit',  'weekly-reports', NULL, '{"status":200}', '192.168.1.101', 'Mozilla/5.0'),
(7,  2, 'POST:/api/comments',                  'comments', NULL, '{"status":200,"action_type":"comment"}', '192.168.1.104', 'Mozilla/5.0'),
(8,  13,'POST:/api/daily-reports',            'daily-reports', NULL, '{"status":200}', '192.168.1.105', 'Mozilla/5.0'),
(9,  4, 'POST:/api/tasks',                    'tasks', NULL, '{"status":200,"task_id":1}', '192.168.1.103', 'Mozilla/5.0'),
(10, 5, 'POST:/api/calendar/sync-task-deadlines','calendar', NULL, '{"status":200,"synced_count":4}', '192.168.1.106', 'Mozilla/5.0'),
(11, 6, 'POST:/api/attendance/daily-records', 'attendance', NULL, '{"status":200,"records_count":10}', '192.168.1.100', 'Mozilla/5.0'),
(12, 7, 'POST:/api/ai/chat',                  'ai', NULL, '{"status":200}', '192.168.1.101', 'Mozilla/5.0');


-- ============================================================
-- 执行完毕
-- ============================================================
SELECT 'Sample data inserted successfully!' AS result;
SELECT TABLE_NAME, TABLE_ROWS FROM information_schema.tables WHERE table_schema = 'lab_management' ORDER BY TABLE_NAME;
